import { create } from 'zustand';
import { getSocket, subscribeChannels, oeeApi, yieldApi } from '../api';

export type Page = 'overview' | 'semantic' | 'oee' | 'yield' | 'pdm' | 'quality' | 'energy' | 'supply' | 'twin' | 'safety';

interface Store {
  page: Page;
  rightPanel: 'insights' | 'chat';
  plant: string;
  setPage: (p: Page) => void;
  setRightPanel: (p: 'insights' | 'chat') => void;
  setPlant: (p: string) => void;

  machines: unknown[];
  plantOEE: number;
  fetchMachines: () => Promise<void>;

  yieldParams: unknown[];
  fetchYieldParams: () => Promise<void>;

  crossEvents: unknown[];
  addEvent: (e: unknown) => void;

  wsConnected: boolean;
  initWebSocket: () => void;
}

export const useStore = create<Store>((set) => ({
  page: 'overview',
  rightPanel: 'insights',
  plant: 'All Plants',
  setPage: (page) => set({ page }),
  setRightPanel: (rightPanel) => set({ rightPanel }),
  setPlant: (plant) => set({ plant }),

  machines: [],
  plantOEE: 0,
  fetchMachines: async () => {
    try {
      const data = await oeeApi.getLive();
      set({ machines: data.machines, plantOEE: data.plantOEE });
    } catch {}
  },

  yieldParams: [],
  fetchYieldParams: async () => {
    try {
      const data = await yieldApi.getParams();
      set({ yieldParams: data.params });
    } catch {}
  },

  crossEvents: [],
  addEvent: (e) => set(s => ({ crossEvents: [e, ...s.crossEvents].slice(0, 100) })),

  wsConnected: false,
  initWebSocket: () => {
    const socket = getSocket();
    subscribeChannels(['oee','yield','pdm','quality','energy','supply','twin','safety','semantic','alerts']);
    socket.on('connect', () => set({ wsConnected: true }));
    socket.on('disconnect', () => set({ wsConnected: false }));
    socket.on('cross_agent_event', (e: unknown) => set(s => ({ crossEvents: [e, ...s.crossEvents].slice(0, 100) })));
    // Live OEE updates from simulation engine every 4 seconds
    socket.on('oee', (data: any) => {
      if (data?.machines) set({ machines: data.machines, plantOEE: data.plantOEE ?? 0 });
    });
    // Live yield param updates
    socket.on('yield', (data: any) => {
      if (data?.params) set({ yieldParams: data.params });
    });
  },
}));
