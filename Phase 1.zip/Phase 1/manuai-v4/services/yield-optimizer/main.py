"""
ManuAI — Yield Optimiser Service  v2.0
FastAPI microservice that analyses process parameters and recommends
DCS set-point adjustments to maximise yield.

In MOCK mode (MOCK_DATA=true or AML_YIELD_ENDPOINT not set) it uses
physics-inspired rule logic.  To go live, set AML_YIELD_ENDPOINT and
AML_API_KEY — the live path is a drop-in replacement for _rule_predict().
"""

import os, math, random, logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional

logger = logging.getLogger(__name__)
app = FastAPI(title="ManuAI Yield Optimiser", version="2.0.0")

MOCK = not bool(os.getenv("AML_YIELD_ENDPOINT"))
if MOCK:
    logger.warning("AML_YIELD_ENDPOINT not set — yield optimiser running in mock/rule mode")


# ── Request / Response models ─────────────────────────────────────────────────

class ProcessParams(BaseModel):
    batch_id: str
    tic_101: float   # Reactor temperature °C
    pic_102: float   # Reactor pressure bar
    sic_204: float   # Mixing speed RPM
    fic_301: float   # Feed rate kg/hr
    tic_205: float   # Jacket temperature °C
    fic_401: float   # Coolant flow L/min
    run_minutes: float = 0.0
    current_yield_pct: Optional[float] = None

class SetPointRec(BaseModel):
    tag_id: str
    name: str
    current: float
    recommended: float
    unit: str
    delta_yield_pct: float
    confidence: float
    reason: str

class YieldPrediction(BaseModel):
    batch_id: str
    predicted_yield_pct: float
    yield_low: float        # 90% CI
    yield_high: float
    grade_probability: dict  # {"A": 0.78, "B": 0.19, "C": 0.03}
    recommendations: List[SetPointRec]
    bottleneck: str
    estimated_improvement_pct: float
    model_source: str       # "rule_engine" | "azure_ml"


# ── Target / safe range registry ──────────────────────────────────────────────

TARGETS = {
    "tic_101": {"name": "Reactor Temp",  "unit": "°C",    "target": 186, "min": 160, "max": 200, "tag": "TIC-101"},
    "pic_102": {"name": "Pressure",      "unit": "bar",   "target": 8.4, "min": 6.0, "max": 12.0,"tag": "PIC-102"},
    "sic_204": {"name": "Mixing Speed",  "unit": "RPM",   "target": 395, "min": 300, "max": 500, "tag": "SIC-204"},
    "fic_301": {"name": "Feed Rate",     "unit": "kg/hr", "target": 138, "min": 100, "max": 180, "tag": "FIC-301"},
    "tic_205": {"name": "Jacket Temp",   "unit": "°C",    "target": 47,  "min": 30,  "max": 80,  "tag": "TIC-205"},
    "fic_401": {"name": "Coolant Flow",  "unit": "L/min", "target": 28.6,"min": 20,  "max": 40,  "tag": "FIC-401"},
}

def _clamp(val, mn, mx):
    return max(mn, min(mx, val))

def _noise(scale=0.02):
    return (random.random() - 0.5) * scale


def _rule_predict(p: ProcessParams) -> YieldPrediction:
    """
    Physics-inspired rule engine.  Each parameter contributes a penalty
    proportional to its deviation from target.

    Sensitivity coefficients are illustrative — replace with real DoE data.
    """
    params = {
        "tic_101": p.tic_101,
        "pic_102": p.pic_102,
        "sic_204": p.sic_204,
        "fic_301": p.fic_301,
        "tic_205": p.tic_205,
        "fic_401": p.fic_401,
    }
    # Sensitivity: % yield lost per unit deviation from target
    sensitivity = {
        "tic_101": 0.35,   # 0.35 %/°C
        "pic_102": 1.20,   # 1.20 %/bar
        "sic_204": 0.008,  # 0.008 %/RPM
        "fic_301": 0.12,   # 0.12 %/kg/hr
        "tic_205": 0.18,   # 0.18 %/°C
        "fic_401": 0.40,   # 0.40 %/(L/min)
    }

    base_yield = 91.5
    penalties = {}
    for key, val in params.items():
        tgt = TARGETS[key]["target"]
        dev = abs(val - tgt)
        penalties[key] = dev * sensitivity[key]

    total_penalty = sum(penalties.values())
    predicted = _clamp(base_yield - total_penalty + _noise() * 2, 50, 98)
    uncertainty = 1.8

    # Build recommendations — only for parameters significantly off target
    recs = []
    for key, val in params.items():
        meta = TARGETS[key]
        tgt = meta["target"]
        dev = val - tgt
        if abs(dev) / (meta["max"] - meta["min"]) < 0.04:  # < 4% span → skip
            continue
        delta_yield = penalties[key]
        recs.append(SetPointRec(
            tag_id=meta["tag"],
            name=meta["name"],
            current=round(val, 2),
            recommended=round(tgt, 2),
            unit=meta["unit"],
            delta_yield_pct=round(delta_yield, 2),
            confidence=round(0.82 - abs(dev) / (meta["max"] - meta["min"]) * 0.15, 2),
            reason=f"{'Above' if dev > 0 else 'Below'} target by {abs(dev):.1f} {meta['unit']}; "
                   f"estimated +{delta_yield:.1f}% yield if corrected.",
        ))

    recs.sort(key=lambda r: -r.delta_yield_pct)

    # Determine bottleneck
    bottleneck_key = max(penalties, key=penalties.get)
    bottleneck = TARGETS[bottleneck_key]["name"]

    total_improvement = sum(r.delta_yield_pct for r in recs)

    grade_a = _clamp(0.78 + (predicted - 88) * 0.03 + _noise(0.04), 0, 1)
    grade_b = _clamp(0.19 - (predicted - 88) * 0.02 + _noise(0.02), 0, 1)
    grade_c = _clamp(1 - grade_a - grade_b, 0, 1)

    return YieldPrediction(
        batch_id=p.batch_id,
        predicted_yield_pct=round(predicted, 1),
        yield_low=round(predicted - uncertainty, 1),
        yield_high=round(predicted + uncertainty, 1),
        grade_probability={"A": round(grade_a, 3), "B": round(grade_b, 3), "C": round(grade_c, 3)},
        recommendations=recs,
        bottleneck=bottleneck,
        estimated_improvement_pct=round(total_improvement, 1),
        model_source="rule_engine",
    )


@app.post("/predict", response_model=YieldPrediction)
def predict(params: ProcessParams):
    if MOCK:
        return _rule_predict(params)
    # ── LIVE PATH — replace rule engine with Azure ML call ────────────────
    # import httpx
    # resp = httpx.post(os.getenv("AML_YIELD_ENDPOINT"), json=params.dict(),
    #                   headers={"Authorization": f"Bearer {os.getenv('AML_API_KEY')}"}, timeout=10)
    # resp.raise_for_status()
    # return YieldPrediction(**resp.json())
    raise HTTPException(503, "Live AML endpoint not yet wired — set AML_YIELD_ENDPOINT")


@app.get("/health")
def health():
    return {"status": "ok", "service": "yield-optimizer", "mode": "mock" if MOCK else "live"}
