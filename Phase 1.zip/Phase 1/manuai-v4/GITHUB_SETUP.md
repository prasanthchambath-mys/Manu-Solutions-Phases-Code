# ManuAI v4 — GitHub Setup & Team Distribution Guide

---

## YOUR JOB (one time, on your laptop)

### Step 1 — Create a GitHub account
Go to https://github.com and sign up if you don't have an account.
Your username will be something like `rajesh-kumar` or your company name.

### Step 2 — Create a new repository
1. Click the **+** button top right → **New repository**
2. Name it: `manuai`
3. Set to **Private** (so only people you invite can see it)
4. Click **Create repository**

### Step 3 — Install Git on your laptop
Download from: https://git-scm.com/download/win
Run the installer with default settings.

### Step 4 — Push the code to GitHub
Open Command Prompt inside your `manuai-v4` folder and run these commands
one by one:

```
git init
git add .
git commit -m "ManuAI v4 initial release"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/manuai.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your actual GitHub username.

### Step 5 — Watch GitHub build the images
1. Go to your repo on GitHub: https://github.com/YOUR_USERNAME/manuai
2. Click the **Actions** tab
3. You'll see a workflow called "Build & Publish Docker Images" running
4. Wait for all green ticks ✅ (takes about 10–15 minutes first time)

That's it. Your images are now published and ready for anyone to download.

### Step 6 — Make images publicly accessible
By default GitHub packages are private. To let your team pull without login:

1. Go to https://github.com/YOUR_USERNAME?tab=packages
2. Click each package (manuai-api, manuai-web, etc.)
3. Click **Package settings** → scroll to **Danger Zone**
4. Click **Change visibility** → **Public**

Do this for all 9 packages.

---

## THEIR JOB (your teammates — nothing to install except Docker)

### What to share with them
Send them **3 files**:
1. `docker-compose.ghcr.yml` (from the repo)
2. `.env.team` — rename this to `.env.local`
3. This instruction below 👇

---

### Instructions for teammates

**Step 1 — Install Docker Desktop**
Download from: https://www.docker.com/products/docker-desktop/
Click the Windows installer, run it, restart your PC.
After restart, open Docker Desktop from the Start menu.
Wait until it shows **Engine running**.

**Step 2 — Get the two files**
Ask your manager for:
- `docker-compose.ghcr.yml`
- `.env.local`

Put both files in the same folder, e.g. `C:\ManuAI\`

**Step 3 — Run it**
Open Command Prompt inside that folder (click address bar, type `cmd`, Enter).

Type this and press Enter:
```
docker compose -f docker-compose.ghcr.yml up
```

First time takes **5–10 minutes** — it's downloading the images.
After that it starts in **under 1 minute** every time.

**Step 4 — Open the dashboard**
Open any browser and go to:
```
http://localhost
```

Done. ✅

---

## To stop it
Press `Ctrl + C` in the terminal, then type:
```
docker compose -f docker-compose.ghcr.yml down
```

## To update when new version is released
```
docker compose -f docker-compose.ghcr.yml pull
docker compose -f docker-compose.ghcr.yml up
```

---

## When YOU make changes to the code

Just push to GitHub again:
```
git add .
git commit -m "describe what you changed"
git push
```

GitHub Actions automatically rebuilds all images.
Your teammates run `docker compose pull` to get the update.
No need to share new files — they always pull from the same URL.

---

## Quick troubleshooting

| Problem | Fix |
|---|---|
| Docker Desktop not starting | Restart PC, open Docker Desktop from Start menu, wait for Engine running |
| `docker: command not found` | Docker not installed or terminal needs restart after install |
| Page not loading | Wait 2 more minutes — services take time to start. Check terminal for errors |
| Port 80 already in use | Something else uses port 80. In docker-compose.ghcr.yml change `"80:80"` to `"8080:80"` then open http://localhost:8080 |
| Images not pulling | Make sure packages are set to Public on GitHub (Step 6 above) |
