/**
 * ManuAI — CSV Data Loader
 *
 * Reads all CSV files from data/csv/ and returns typed objects.
 * Every connector and route that needs seed data calls this loader.
 *
 * HOW TO SWAP TO REAL DATA:
 * --------------------------
 * Each function below has a comment: // REPLACE WITH: <connector>
 * When you're ready, delete the CSV read and replace with the connector call.
 * Nothing else in the codebase needs to change.
 *
 * EDITING MOCK DATA:
 * ------------------
 * Open any file in data/csv/ in Excel, edit values, save as CSV.
 * Restart the API — changes take effect immediately.
 */

import fs from 'fs';
import path from 'path';
import { logger } from '../middleware/logger';

// ── CSV path resolver ─────────────────────────────────────────────────────────
const CSV_DIR = process.env.CSV_DATA_DIR
  ?? path.resolve(__dirname, '../../../../data/csv');

function csvPath(filename: string): string {
  return path.join(CSV_DIR, filename);
}

// ── Generic CSV parser (no external dependency) ───────────────────────────────
function parseCSV(filename: string): Record<string, string>[] {
  const fullPath = csvPath(filename);
  if (!fs.existsSync(fullPath)) {
    logger.warn(`CSV not found: ${fullPath}`);
    return [];
  }
  const raw = fs.readFileSync(fullPath, 'utf-8');
  const lines = raw.trim().split('\n').filter(l => l.trim());
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map(h => h.trim());
  return lines.slice(1).map(line => {
    // Handle commas inside quoted fields
    const values: string[] = [];
    let current = '';
    let inQuotes = false;
    for (const ch of line) {
      if (ch === '"') { inQuotes = !inQuotes; continue; }
      if (ch === ',' && !inQuotes) { values.push(current.trim()); current = ''; continue; }
      current += ch;
    }
    values.push(current.trim());
    return Object.fromEntries(headers.map((h, i) => [h, values[i] ?? '']));
  });
}

function num(v: string | undefined, fallback = 0): number {
  const n = parseFloat(v ?? '');
  return isNaN(n) ? fallback : n;
}
function bool(v: string | undefined): boolean {
  return (v ?? '').toLowerCase() === 'true';
}

// ── Loaders ───────────────────────────────────────────────────────────────────

export function loadMachines() {
  // REPLACE WITH: PI Historian getTagsBatch() + SAP MES data
  return parseCSV('machines.csv').map(r => ({
    id:          r.id,
    name:        r.name,
    line:        r.line,
    plant:       r.plant,
    oee:         num(r.oee),
    avail:       num(r.avail),
    perf:        num(r.perf),
    qual:        num(r.qual),
    health:      num(r.health),
    rul:         num(r.rul),
    status:      r.status as 'good' | 'caution' | 'warning' | 'critical',
    loss:        r.loss,
    lossMin:     num(r.loss_min),
    vib:         num(r.vib),
    temp:        num(r.temp),
    _degradeRate:num(r.degrade_rate, 0.05),
    _inMaintenance: false,
    _maintenanceTicksLeft: 0,
  }));
}

export function loadUtilities() {
  // REPLACE WITH: PI Historian + IoT Hub sensor readings
  return parseCSV('utilities.csv').map(r => ({
    id:          r.id,
    name:        r.name,
    health:      num(r.health),
    rul:         num(r.rul),
    status:      r.status,
    vib:         num(r.vib),
    temp:        num(r.temp),
    press:       num(r.pressure),
    oeeLink:     r.oee_link || null,
    _degradeRate:num(r.degrade_rate, 0.05),
  }));
}

export function loadYieldParams() {
  // REPLACE WITH: PI Historian getTagsBatch() for process tags
  return parseCSV('yield_params.csv').map(r => ({
    id:           r.id,
    name:         r.name,
    unit:         r.unit,
    val:          num(r.value),
    tgt:          num(r.target),
    min:          num(r.min),
    max:          num(r.max),
    warn:         Math.abs(num(r.value) - num(r.target)) / (num(r.max) - num(r.min)) > 0.06,
    blocked:      false,
    _driftRate:   num(r.drift_rate, 0.05),
    _driftDir:    (num(r.drift_direction, 1) >= 0 ? 1 : -1) as 1 | -1,
  }));
}

export function loadProductionOrders() {
  // REPLACE WITH: SAP OData getProductionOrders()
  return parseCSV('production_orders.csv').map(r => ({
    id:       r.id,
    product:  r.product,
    qty:      `${r.qty_kg} kg`,
    plan:     num(r.plan_yield),
    actual:   r.actual_yield ? num(r.actual_yield) : null,
    status:   r.status,
    start:    r.start_date,
    end:      r.end_date,
  }));
}

export function loadLimsResults() {
  // REPLACE WITH: LIMS connector getTodayResults()
  return parseCSV('lims_results.csv').map(r => ({
    id:       r.id,
    batch:    r.batch,
    test:     r.test,
    result:   r.result,
    limit:    r.limit,
    status:   r.status as 'pass' | 'fail',
    analyst:  r.analyst,
    time:     r.time,
  }));
}

export function loadWorkOrders() {
  // REPLACE WITH: SAP PM getMaintenanceOrders()
  return parseCSV('work_orders.csv').map(r => ({
    id:          r.id,
    asset:       r.asset_id,
    name:        r.asset_name,
    type:        r.type,
    pri:         r.priority,
    desc:        r.description,
    status:      r.status,
    assigned:    r.assigned_to,
    oeeLink:     bool(r.oee_link),
  }));
}

export function loadSupplyRisks() {
  // REPLACE WITH: SAP MM getMaterialStock() + D&B API for financial scores
  return parseCSV('supply_risks.csv').map(r => ({
    supplier_id:                r.supplier_id,
    supplier_name:              r.supplier_name,
    sku:                        r.sku,
    description:                r.description,
    current_stock_days:         num(r.current_stock_days),
    reorder_point_days:         num(r.reorder_point_days),
    lead_time_contracted_days:  num(r.lead_time_contracted_days),
    lead_time_actual_days:      num(r.lead_time_actual_days),
    monthly_consumption:        num(r.monthly_consumption),
    unit_cost_inr:              num(r.unit_cost_inr),
    single_source:              bool(r.single_source),
    country_of_origin:          r.country_of_origin,
    financial_risk_score:       num(r.financial_risk_score),
  }));
}

export function loadEnergyAssets() {
  // REPLACE WITH: Smart meter API / Azure IoT Hub energy telemetry
  return parseCSV('energy_assets.csv').map(r => ({
    id:                     r.id,
    name:                   r.name,
    kw:                     num(r.current_kw),
    anomaly:                false,
    _baseKw:                num(r.rated_kw),
    shiftable:              bool(r.shiftable),
    critical:               bool(r.critical),
    anomalyThresholdPct:    num(r.anomaly_threshold_pct, 12),
  }));
}

export function loadEnergyHourly() {
  // REPLACE WITH: Smart meter historical data API
  return parseCSV('energy_hourly.csv').map(r => ({
    h:  r.hour,
    kw: num(r.kw_base),
  }));
}

export function loadSafetyZones() {
  // REPLACE WITH: IoT Hub gas sensor stream
  return parseCSV('safety_zones.csv').map(r => ({
    zone:        r.zone_id,
    h2s:         num(r.h2s_ppm_baseline),
    co:          num(r.co_ppm_baseline),
    ch4:         num(r.ch4_pct_lel_baseline),
    thresholds: {
      h2s: { alarm1: num(r.h2s_alarm1), alarm2: num(r.h2s_alarm2), evac: num(r.h2s_evac) },
      co:  { alarm1: num(r.co_alarm1),  alarm2: num(r.co_alarm2),  evac: num(r.co_evac)  },
      ch4: { alarm1: num(r.ch4_alarm1), alarm2: num(r.ch4_alarm2), evac: num(r.ch4_evac) },
    },
    personnelNormal: num(r.personnel_normal),
    amrEnabled:      bool(r.amr_enabled),
    _spiking:        false,
    _spikeTicks:     0,
  }));
}

export function loadSafetyPermits() {
  // REPLACE WITH: CMMS / PTW system API
  return parseCSV('safety_permits.csv').map(r => ({
    id:                 r.ptw_id,
    asset:              r.asset_id,
    type:               r.work_type,
    tech:               r.technician,
    status:             r.status,
    jha:                bool(r.jha_complete),
    isolation:          bool(r.isolation_verified),
    competency:         bool(r.competency_valid),
  }));
}

export function loadQualityDefects() {
  // REPLACE WITH: Vision AI service / MES quality module
  return parseCSV('quality_defects.csv').map(r => ({
    id:         r.id,
    time:       r.time,
    line:       r.line,
    component:  r.component,
    type:       r.defect_type,
    severity:   r.severity as 'major' | 'minor' | 'cosmetic',
    action:     r.action,
    confidence: num(r.confidence),
  }));
}

export function loadQualityLines() {
  // REPLACE WITH: Vision AI model status API
  return parseCSV('quality_lines.csv').map(r => ({
    line:     r.line,
    rate:     num(r.quality_rate_pct),
    defects:  num(r.defects_today),
    escapes:  num(r.escapes_today),
    model:    r.model_version,
  }));
}

export function loadTwinKPIs() {
  // REPLACE WITH: Azure Digital Twins API
  return parseCSV('twin_kpis.csv').map(r => ({
    kpi_id:               r.kpi_id,
    kpi_name:             r.kpi_name,
    unit:                 r.unit,
    actual:               num(r.actual),
    twin_predicted:       num(r.twin_predicted),
    threshold_pct:        num(r.divergence_threshold_pct),
    asset_id:             r.asset_id || null,
  }));
}

// ── Reload all (call on file-change watch if needed) ──────────────────────────
export function reloadAll() {
  logger.info('[CSV] Reloading all CSV data files');
  return {
    machines:         loadMachines(),
    utilities:        loadUtilities(),
    yieldParams:      loadYieldParams(),
    productionOrders: loadProductionOrders(),
    limsResults:      loadLimsResults(),
    workOrders:       loadWorkOrders(),
    supplyRisks:      loadSupplyRisks(),
    energyAssets:     loadEnergyAssets(),
    energyHourly:     loadEnergyHourly(),
    safetyZones:      loadSafetyZones(),
    safetyPermits:    loadSafetyPermits(),
    qualityDefects:   loadQualityDefects(),
    qualityLines:     loadQualityLines(),
    twinKPIs:         loadTwinKPIs(),
  };
}
