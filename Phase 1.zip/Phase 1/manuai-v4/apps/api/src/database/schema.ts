/**
 * ManuAI — Database Schema
 * Creates all tables on first startup if they don't exist.
 * Safe to run multiple times — uses IF NOT EXISTS.
 */

import { getDb } from './connection';
import { logger } from '../middleware/logger';

export function runMigrations(): void {
  const db = getDb();

  db.exec(`
    -- OEE readings — one row per machine per tick
    CREATE TABLE IF NOT EXISTS oee_readings (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      machine_id   TEXT    NOT NULL,
      machine_name TEXT    NOT NULL,
      line         TEXT    NOT NULL,
      ts           INTEGER NOT NULL,   -- Unix timestamp ms
      oee          REAL    NOT NULL,
      avail        REAL    NOT NULL,
      perf         REAL    NOT NULL,
      qual         REAL    NOT NULL,
      loss_type    TEXT,
      loss_min     INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_oee_machine_ts ON oee_readings(machine_id, ts);
    CREATE INDEX IF NOT EXISTS idx_oee_ts         ON oee_readings(ts);

    -- Machine health and sensor readings
    CREATE TABLE IF NOT EXISTS machine_health (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      machine_id   TEXT    NOT NULL,
      ts           INTEGER NOT NULL,
      health       REAL    NOT NULL,
      rul          REAL    NOT NULL,
      vib          REAL    NOT NULL,
      temp         REAL    NOT NULL,
      status       TEXT    NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_health_machine_ts ON machine_health(machine_id, ts);

    -- Alerts fired by the simulation engine
    CREATE TABLE IF NOT EXISTS alerts (
      id           TEXT    PRIMARY KEY,
      machine_id   TEXT    NOT NULL,
      machine_name TEXT,
      line         TEXT,
      type         TEXT    NOT NULL,
      severity     TEXT    NOT NULL,
      message      TEXT    NOT NULL,
      ts           INTEGER NOT NULL,
      acked        INTEGER DEFAULT 0,
      acked_by     TEXT,
      acked_at     INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_alerts_ts       ON alerts(ts);
    CREATE INDEX IF NOT EXISTS idx_alerts_machine  ON alerts(machine_id);
    CREATE INDEX IF NOT EXISTS idx_alerts_severity ON alerts(severity);

    -- Production batches
    CREATE TABLE IF NOT EXISTS batches (
      id           TEXT    PRIMARY KEY,
      product      TEXT    NOT NULL,
      qty_kg       INTEGER NOT NULL,
      plan_yield   REAL    NOT NULL,
      actual_yield REAL,
      status       TEXT    NOT NULL,
      started_at   INTEGER NOT NULL,
      completed_at INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_batches_ts ON batches(started_at);

    -- Yield parameter history
    CREATE TABLE IF NOT EXISTS yield_history (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      param_id     TEXT    NOT NULL,
      param_name   TEXT    NOT NULL,
      ts           INTEGER NOT NULL,
      value        REAL    NOT NULL,
      target       REAL    NOT NULL,
      warn         INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_yield_param_ts ON yield_history(param_id, ts);

    -- Energy readings per asset
    CREATE TABLE IF NOT EXISTS energy_readings (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      asset_id     TEXT    NOT NULL,
      asset_name   TEXT    NOT NULL,
      ts           INTEGER NOT NULL,
      kw           REAL    NOT NULL,
      anomaly      INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_energy_asset_ts ON energy_readings(asset_id, ts);

    -- Safety events
    CREATE TABLE IF NOT EXISTS safety_events (
      id           TEXT    PRIMARY KEY,
      zone         TEXT    NOT NULL,
      event_type   TEXT    NOT NULL,
      severity     TEXT    NOT NULL,
      h2s          REAL    DEFAULT 0,
      co           REAL    DEFAULT 0,
      ch4          REAL    DEFAULT 0,
      ts           INTEGER NOT NULL,
      resolved_at  INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_safety_ts ON safety_events(ts);

    -- Schema version tracking
    CREATE TABLE IF NOT EXISTS schema_version (
      version      INTEGER PRIMARY KEY,
      applied_at   INTEGER NOT NULL
    );
  `);

  // Mark schema version
  const existing = db.prepare('SELECT version FROM schema_version WHERE version = 1').get();
  if (!existing) {
    db.prepare('INSERT INTO schema_version (version, applied_at) VALUES (1, ?)').run(Date.now());
  }

  logger.info('[DB] Schema migrations complete');
}

export function isHistorySeeded(): boolean {
  const db = getDb();
  const row = db.prepare('SELECT COUNT(*) as cnt FROM oee_readings').get() as { cnt: number };
  return row.cnt > 1000; // If more than 1000 rows, history is already seeded
}
