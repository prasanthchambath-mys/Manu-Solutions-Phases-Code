/**
 * ManuAI — Database Connection
 *
 * Phase 1: SQLite (single file, zero installation)
 * Phase 2: Azure SQL (change DATABASE_URL in .env.local — no code changes)
 *
 * The same table names and queries work on both.
 * Switching is one line: DATABASE_URL=Server=your-azure-sql...
 */

import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { logger } from '../middleware/logger';

const DB_PATH = process.env.DATABASE_PATH
  ?? path.resolve(__dirname, '../../../../data/manuai.db');

// Ensure data directory exists
const dir = path.dirname(DB_PATH);
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

let _db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (!_db) {
    _db = new Database(DB_PATH);
    _db.pragma('journal_mode = WAL');   // Better concurrent read performance
    _db.pragma('foreign_keys = ON');
    logger.info(`[DB] SQLite connected: ${DB_PATH}`);
  }
  return _db;
}

export function closeDb(): void {
  _db?.close();
  _db = null;
}
