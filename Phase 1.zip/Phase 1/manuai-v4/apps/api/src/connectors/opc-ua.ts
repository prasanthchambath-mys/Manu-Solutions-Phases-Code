import { logger } from '../middleware/logger';

const MOCK_MODE = !process.env.OPC_UA_ENDPOINT;
if (MOCK_MODE) logger.warn('OPC_UA_ENDPOINT not set — OPC-UA running in mock mode');

// In-memory store of mock set-points so reads return what was last written
const mockSetPoints = new Map<string, number>();

// ── Live session (only loaded when OPC_UA_ENDPOINT is set) ───────────────────
let session: unknown = null;
let opcClient: unknown = null;

async function getSession() {
  if (session) return session;
  // Dynamic import so the module loads even without node-opcua installed
  const { OPCUAClient, MessageSecurityMode, SecurityPolicy } = await import('node-opcua');
  opcClient = OPCUAClient.create({
    applicationName: 'ManuAI-Platform',
    connectionStrategy: { initialDelay: 1000, maxRetry: 3 },
    securityMode: MessageSecurityMode.None,
    securityPolicy: SecurityPolicy.None,
  });
  await (opcClient as any).connect(process.env.OPC_UA_ENDPOINT!);
  session = await (opcClient as any).createSession();
  logger.info('OPC-UA session established');
  return session;
}

export async function writeSetPoint(nodeId: string, value: number): Promise<boolean> {
  if (MOCK_MODE) {
    mockSetPoints.set(nodeId, value);
    logger.info(`[MOCK] OPC-UA write OK — ${nodeId} = ${value}`);
    return true;
  }
  try {
    const { AttributeIds, StatusCodes } = await import('node-opcua');
    const s = await getSession() as any;
    const statusCodes = await s.write([{
      nodeId,
      attributeId: AttributeIds.Value,
      value: { value: { dataType: 'Double', value } },
    }]);
    const ok = statusCodes[0] === StatusCodes.Good;
    if (ok) logger.info('OPC-UA write OK', { nodeId, value });
    else     logger.error('OPC-UA write failed', { nodeId, status: String(statusCodes[0]) });
    return ok;
  } catch (err) {
    logger.error('OPC-UA write error', { nodeId, error: String(err) });
    return false;
  }
}

export async function readSetPoint(nodeId: string): Promise<number | null> {
  if (MOCK_MODE) return mockSetPoints.get(nodeId) ?? null;
  try {
    const { AttributeIds } = await import('node-opcua');
    const s = await getSession() as any;
    const result = await s.read([{ nodeId, attributeId: AttributeIds.Value }]);
    return result[0]?.value?.value ?? null;
  } catch {
    return null;
  }
}

export async function checkOPCUAHealth(): Promise<boolean> {
  if (MOCK_MODE) return true;
  try { await getSession(); return true; } catch { return false; }
}

export async function disconnect(): Promise<void> {
  if (MOCK_MODE) return;
  await (session as any)?.close();
  await (opcClient as any)?.disconnect();
  session = null; opcClient = null;
}
