import axios from 'axios';
import { logger } from '../middleware/logger';
import { loadLimsResults } from '../data/csv-loader';

const MOCK_MODE = !process.env.LIMS_BASE_URL;
if (MOCK_MODE) logger.warn('LIMS_BASE_URL not set — LIMS running in mock mode');

const lims = axios.create({
  baseURL: process.env.LIMS_BASE_URL,
  headers: { 'X-LIMS-API-Key': process.env.LIMS_API_KEY },
  timeout: 10_000,
});

export async function getTodayResults() {
  if (MOCK_MODE) return loadLimsResults();
  try { return (await lims.get('/batches/today/results')).data; }
  catch (err) { logger.warn('LIMS unavailable', { error: String(err) }); return loadLimsResults(); }
}

export async function getBatchResults(batchId: string) {
  if (MOCK_MODE) return loadLimsResults().filter((r: any) => r.batch === batchId);
  try { return (await lims.get(`/batches/${batchId}/results`)).data; }
  catch (err) { logger.warn('LIMS unavailable', { error: String(err) }); return []; }
}

export async function checkLIMSHealth(): Promise<boolean> {
  if (MOCK_MODE) return true;
  try { await lims.get('/health'); return true; } catch { return false; }
}
