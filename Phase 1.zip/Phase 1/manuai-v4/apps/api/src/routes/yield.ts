import { Router } from 'express';
import { getTagsBatch } from '../connectors/pi-historian';
import { getTodayResults } from '../connectors/lims';
import { getProductionOrders } from '../connectors/sap-odata';
import { writeSetPoint } from '../connectors/opc-ua';
import { semanticLayer } from '../semantic/service';
import { requireRole, ROLES } from '../middleware/auth';
import { broadcast } from '../websocket/broadcaster';
import { logger } from '../middleware/logger';
import { getPlantState } from '../simulation/engine';
import { z } from 'zod';

const router = Router();

const PARAMS_META = [
  { id:'TIC-101', name:'Reactor Temp',  piTag:'Plant.Reactor.TIC101.PV', nodeId:'ns=2;s=TIC101_SP', unit:'°C',    min:160, max:200, target:186 },
  { id:'PIC-102', name:'Pressure',      piTag:'Plant.Reactor.PIC102.PV', nodeId:'ns=2;s=PIC102_SP', unit:'bar',   min:6,   max:12,  target:8.4 },
  { id:'SIC-204', name:'Mixing Speed',  piTag:'Plant.Reactor.SIC204.PV', nodeId:'ns=2;s=SIC204_SP', unit:'RPM',   min:300, max:500, target:395 },
  { id:'FIC-301', name:'Feed Rate',     piTag:'Plant.Reactor.FIC301.PV', nodeId:'ns=2;s=FIC301_SP', unit:'kg/hr', min:100, max:180, target:138 },
  { id:'TIC-205', name:'Jacket Temp',   piTag:'Plant.Reactor.TIC205.PV', nodeId:'ns=2;s=TIC205_SP', unit:'°C',    min:30,  max:80,  target:47  },
  { id:'FIC-401', name:'Coolant Flow',  piTag:'Plant.Reactor.FIC401.PV', nodeId:'ns=2;s=FIC401_SP', unit:'L/min', min:20,  max:40,  target:28.6},
];

router.get('/params', async (_req, res) => {
  const piValues = await getTagsBatch(PARAMS_META.map(p => p.piTag)).catch(() => ({}));
  const simParams = getPlantState().yieldParams;

  const params = PARAMS_META.map(p => {
    const simVal = simParams.find(sp => sp.id === p.id);
    const val = piValues[p.piTag] ?? simVal?.val ?? p.target;
    const conflict = semanticLayer.checkConflict({ agent: 'yield', type: 'dcs_write', tagId: p.id });
    return {
      ...p, val: +val.toFixed(1),
      warn: Math.abs(val - p.target) / p.target > 0.05,
      blocked: conflict.blocked, blockedReason: conflict.reason,
    };
  });
  res.json({ params, timestamp: new Date().toISOString() });
});

const WriteSchema = z.object({ tagId: z.string(), value: z.number(), reason: z.string().min(5) });

router.post('/dcs-write', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const parsed = WriteSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.issues }); return; }
  const { tagId, value, reason } = parsed.data;

  const conflict = semanticLayer.checkConflict({ agent: 'yield', type: 'dcs_write', tagId });
  if (conflict.blocked) { res.status(409).json({ error: 'Semantic Layer block', reason: conflict.reason }); return; }

  const param = PARAMS_META.find(p => p.id === tagId);
  if (!param) { res.status(404).json({ error: `Unknown tag: ${tagId}` }); return; }
  if (value < param.min || value > param.max) { res.status(400).json({ error: `${value} out of safe range [${param.min}, ${param.max}]` }); return; }

  const ok = await writeSetPoint(param.nodeId, value);
  if (!ok) { res.status(502).json({ error: 'OPC-UA write failed' }); return; }

  logger.info('DCS write', { tagId, value, user: req.user?.name, reason });
  await semanticLayer.publishEvent({ id:`DCS-${Date.now()}`, from:'yield', to:'oee', type:'dcs_write', sev:'info',
    msg:`${param.name} → ${value} ${param.unit}: ${reason}`, impact:'Yield impact expected within 15 min', asset:tagId, ts:new Date().toISOString() });
  broadcast('yield', { type:'dcs_confirmed', tagId, value });
  res.json({ success: true, tagId, value, unit: param.unit });
});

router.get('/lims', async (_req, res) => {
  const results = await getTodayResults();
  res.json({ results });
});

router.get('/orders', async (_req, res) => {
  const state = getPlantState();
  const orders = await getProductionOrders().catch(() => []);
  const liveOrder = {
    id: state.batch.id, product: state.batch.product,
    qty: `${state.batch.qty} kg`, plan: state.batch.plan,
    actual: state.batch.actual, status: state.batch.status,
    start: new Date(state.batch.startedAt).toLocaleString('en-IN'),
    end: new Date(state.batch.startedAt + state.batch.durationMs).toLocaleString('en-IN'),
  };
  res.json({ orders: orders.length ? orders : [liveOrder] });
});

export default router;
