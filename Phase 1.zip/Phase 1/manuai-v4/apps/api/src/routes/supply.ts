import { supplyRouter } from './all-routes';
export default supplyRouter;
