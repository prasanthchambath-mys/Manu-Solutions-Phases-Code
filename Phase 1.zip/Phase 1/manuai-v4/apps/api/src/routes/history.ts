/**
 * ManuAI — History Routes
 * Serves all historical data from SQLite database.
 * These endpoints power the trend charts across all 9 agents.
 */

import { Router } from 'express';
import {
  getOeeTrend, getPlantOeeTrend, getOeeSummary,
  getHealthTrend, getAllHealthSummary,
  getAlertHistory, getAlertStats,
  getBatchHistory, getBatchStats,
  getYieldParamTrend,
  getEnergyTrend, getEnergyByAsset,
  getSafetyEventHistory, getSafetyStats,
} from '../database/queries';
import { ackAlertInDB } from '../database/writer';
import { logger } from '../middleware/logger';

const router = Router();

// ── OEE History ────────────────────────────────────────────────────────────────
router.get('/oee/trend/:machineId', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const data = getOeeTrend(req.params.machineId, days);
  res.json({ machineId: req.params.machineId, days, data });
});

router.get('/oee/plant-trend', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getPlantOeeTrend(days) });
});

router.get('/oee/summary', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getOeeSummary(days) });
});

// ── PdM Health History ─────────────────────────────────────────────────────────
router.get('/pdm/health/:machineId', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ machineId: req.params.machineId, days, data: getHealthTrend(req.params.machineId, days) });
});

router.get('/pdm/health-summary', (_req, res) => {
  res.json({ data: getAllHealthSummary() });
});

// ── Alerts History ─────────────────────────────────────────────────────────────
router.get('/alerts/history', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const severity = req.query.severity as string | undefined;
  const data = getAlertHistory(days, severity);
  res.json({ days, total: data.length, data });
});

router.get('/alerts/stats', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getAlertStats(days) });
});

router.post('/alerts/:id/ack', (req, res) => {
  const ackedBy = req.user?.name ?? 'Unknown';
  const ok = ackAlertInDB(req.params.id, ackedBy);
  if (!ok) { res.status(404).json({ error: 'Alert not found' }); return; }
  logger.info('Alert acknowledged', { id: req.params.id, by: ackedBy });
  res.json({ success: true, alertId: req.params.id, ackedBy });
});

// ── Batch / Yield History ──────────────────────────────────────────────────────
router.get('/yield/batches', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getBatchHistory(days) });
});

router.get('/yield/batch-stats', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getBatchStats(days) });
});

router.get('/yield/param-trend/:paramId', (req, res) => {
  const days = Number(req.query.days ?? 7);
  res.json({ paramId: req.params.paramId, days, data: getYieldParamTrend(req.params.paramId, days) });
});

// ── Energy History ─────────────────────────────────────────────────────────────
router.get('/energy/trend', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getEnergyTrend(days) });
});

router.get('/energy/by-asset', (req, res) => {
  const days = Number(req.query.days ?? 7);
  res.json({ days, data: getEnergyByAsset(days) });
});

// ── Safety History ─────────────────────────────────────────────────────────────
router.get('/safety/events', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getSafetyEventHistory(days) });
});

router.get('/safety/stats', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getSafetyStats(days) });
});

export default router;
