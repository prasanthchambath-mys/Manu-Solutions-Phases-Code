import { twinRouter } from './all-routes';
export default twinRouter;
