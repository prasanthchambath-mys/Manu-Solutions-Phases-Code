import { qualityRouter } from './all-routes';
export default qualityRouter;
