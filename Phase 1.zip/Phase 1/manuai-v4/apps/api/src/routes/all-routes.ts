import { Router } from 'express';
import { getPlantState } from '../simulation/engine';
import { loadWorkOrders, loadQualityDefects, loadQualityLines, loadSupplyRisks, loadTwinKPIs, loadSafetyPermits, loadProductionOrders } from '../data/csv-loader';
import { createMaintenanceNotification, createPurchaseRequisition } from '../connectors/sap-odata';
import { getHistory, getLatest } from '../connectors/iot-hub';
import { semanticLayer } from '../semantic/service';
import { requireRole, ROLES } from '../middleware/auth';
import { unifiedChat, agentRecommendation, semanticQuery } from '../ai/anthropic';
import { logger } from '../middleware/logger';
import { z } from 'zod';

// ══════════════════════════════════════════════════════════════
// PdM Agent
// ══════════════════════════════════════════════════════════════
export const pdmRouter = Router();

pdmRouter.get('/assets', (_req, res) => {
  const state = getPlantState();
  const assets = state.machines.map(m => ({
    id: m.id, name: m.name, health: Math.round(m.health), rul: Math.round(m.rul),
    status: m.status, vib: m.vib, temp: m.temp,
  }));
  const utilityAssets = state.utilities.map(u => ({
    id: u.id, name: u.name, health: Math.round(u.health), rul: Math.round(u.rul),
    status: u.status, oeeLink: u.oeeLink,
  }));
  res.json({ assets, utilityAssets });
});

pdmRouter.get('/sensors/:assetId', (req, res) => {
  const { assetId } = req.params;
  res.json({
    assetId,
    vibration: { latest: getLatest(assetId, 'vibration'), history: getHistory(assetId, 'vibration', 24) },
    temperature: { latest: getLatest(assetId, 'temperature'), history: getHistory(assetId, 'temperature', 24) },
  });
});

pdmRouter.get('/workorders', async (_req, res) => res.json({ orders: loadWorkOrders() }));

pdmRouter.post('/workorders', requireRole(ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { equipment, description, priority } = req.body as { equipment: string; description: string; priority?: string };
  try {
    const wo = await createMaintenanceNotification({ equipment, text: description, priority });
    await semanticLayer.publishEvent({ id: `WO-${Date.now()}`, from: 'pdm', to: 'oee', type: 'work_order_created', sev: 'info', msg: `WO ${wo.MaintenanceNotification}: ${description}`, impact: 'Maintenance scheduled', asset: equipment, ts: new Date().toISOString() });
    res.json({ success: true, workOrderId: wo.MaintenanceNotification });
  } catch { res.status(502).json({ error: 'SAP PM unavailable' }); }
});

pdmRouter.post('/parts-order', requireRole(ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { material, quantity, assetId, reason } = req.body as { material: string; quantity: number; assetId: string; reason: string };
  try {
    const pr = await createPurchaseRequisition({ material, plant: process.env.SAP_PLANT_CODE!, quantity, text: `[ManuAI PdM] ${assetId}: ${reason}`, deliveryDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0] });
    res.json({ success: true, prId: pr.PurchaseRequisition });
  } catch { res.status(502).json({ error: 'SAP MM unavailable' }); }
});

const PDM_ASSETS = [
  { id: 'MCH-01', name: 'Injection Moulding #1', health: 71, rul: 34, status: 'warning',  vib: 3.8,  temp: 74  },
  { id: 'MCH-02', name: 'Injection Moulding #2', health: 84, rul: 82, status: 'good',     vib: 1.9,  temp: 61  },
  { id: 'MCH-03', name: 'CNC Machining Centre',  health: 38, rul: 9,  status: 'critical', vib: 9.1,  temp: 92  },
  { id: 'MCH-04', name: 'Assembly Station 1',    health: 89, rul: 105,status: 'good',     vib: 1.2,  temp: 48  },
  { id: 'MCH-05', name: 'Welding Robot A',       health: 76, rul: 41, status: 'caution',  vib: 3.2,  temp: 68  },
  { id: 'MCH-06', name: 'Welding Robot B',       health: 32, rul: 7,  status: 'critical', vib: 10.2, temp: 97  },
  { id: 'MCH-07', name: 'Conveyor System X1',    health: 91, rul: 138,status: 'good',     vib: 0.8,  temp: 42  },
  { id: 'MCH-08', name: 'Packaging Line P1',     health: 78, rul: 58, status: 'caution',  vib: 2.6,  temp: 55  },
];
const UTIL_ASSETS = [
  { id: 'CMP-001', name: 'Air Compressor A1',    health: 34, rul: 12, status: 'critical', oeeLink: 'Line A pressure risk' },
  { id: 'CHP-002', name: 'Chiller Unit 1',        health: 67, rul: 48, status: 'warning',  oeeLink: '-2.8% MCH-01 perf'   },
  { id: 'HYD-003', name: 'Hydraulic Power Unit',  health: 81, rul: 74, status: 'good',     oeeLink: null },
  { id: 'PMP-005', name: 'Coolant Pump C7',       health: 78, rul: 72, status: 'caution',  oeeLink: null },
];
const PDM_WORKORDERS = [
  { id: 'WO-4841', name: 'MCH-06 Servo Drive J1 Replacement', asset: 'MCH-06', pri: 'P1', type: 'Corrective', status: 'open',        desc: 'Replace J1 servo drive. RUL 7 days critical.' },
  { id: 'WO-4840', name: 'MCH-03 Spindle Bearing Replacement', asset: 'MCH-03', pri: 'P1', type: 'Corrective', status: 'in_progress', desc: 'Spindle bearing degradation confirmed. RUL 9d.' },
  { id: 'WO-4839', name: 'CMP-001 Piston Ring Inspection',    asset: 'CMP-001',pri: 'P2', type: 'Condition',  status: 'scheduled',   desc: 'Piston rings showing wear. Schedule within 5 days.' },
];

// ══════════════════════════════════════════════════════════════
// Quality Vision Agent
// ══════════════════════════════════════════════════════════════
export const qualityRouter = Router();

qualityRouter.get('/defects', (_req, res) => {
  const defects = loadQualityDefects();
  const major = defects.filter(d => d.severity === 'major').length;
  const minor = defects.filter(d => d.severity === 'minor').length;
  res.json({ defects, summary: { total: defects.length, major, minor } });
});
qualityRouter.get('/lines', (_req, res) => res.json({ lines: loadQualityLines() }));

const QUALITY_DEFECTS = [
  { id: 'DEF-0441', time: '11:24', line: 'Line B', component: 'Housing MCH-03', type: 'Surface crack',         severity: 'major', action: 'Rejected',   confidence: 0.97 },
  { id: 'DEF-0440', time: '09:18', line: 'Line A', component: 'Bracket MCH-01', type: 'Dimensional tolerance', severity: 'minor', action: 'Re-inspect', confidence: 0.91 },
  { id: 'DEF-0439', time: '08:02', line: 'Line B', component: 'Weld joint',      type: 'Assembly misalignment', severity: 'major', action: 'Rejected',   confidence: 0.95 },
];
const QUALITY_LINES = [
  { line: 'Line A', rate: 99.2, defects: 4,  escapes: 0, model: 'v3.1' },
  { line: 'Line B', rate: 97.8, defects: 18, escapes: 2, model: 'v3.1' },
  { line: 'Line C', rate: 98.9, defects: 9,  escapes: 0, model: 'v3.0' },
  { line: 'Line D', rate: 99.6, defects: 2,  escapes: 0, model: 'v3.1' },
];

// ══════════════════════════════════════════════════════════════
// Energy Optimisation Agent
// ══════════════════════════════════════════════════════════════
export const energyRouter = Router();

energyRouter.get('/load', (_req, res) => {
  const state = getPlantState();
  res.json({ trend: state.energyTrend, assets: state.energyAssets, waste: ENERGY_WASTE, totalKw: state.energyKw });
});

energyRouter.post('/dispatch', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { assetId, action } = req.body as { assetId: string; action: string };
  logger.info('Energy dispatch', { assetId, action, user: req.user?.name });
  res.json({ success: true, assetId, action, dispatchedAt: new Date().toISOString() });
});

const ENERGY_TREND = [
  { h: '00:00', kw: 842 }, { h: '02:00', kw: 761 }, { h: '04:00', kw: 694 },
  { h: '06:00', kw: 1124 },{ h: '08:00', kw: 1482 },{ h: '10:00', kw: 1561 },
  { h: '12:00', kw: 1498 },{ h: '14:00', kw: 1547 },{ h: '16:00', kw: 1612 },
  { h: '18:00', kw: 1389 },{ h: '20:00', kw: 1102 },{ h: '22:00', kw: 921 },
];
const ENERGY_ASSETS = [
  { id: 'MCH-01', name: 'Injection Moulding #1', kw: 148, anomaly: false },
  { id: 'MCH-03', name: 'CNC Machining Centre',  kw: 92,  anomaly: true  },
  { id: 'MCH-06', name: 'Welding Robot B',        kw: 164, anomaly: true  },
  { id: 'CMP-001',name: 'Air Compressor A1',      kw: 112, anomaly: false },
  { id: 'HVAC-1', name: 'HVAC Zone A',             kw: 86,  anomaly: true  },
  { id: 'CHP-002',name: 'Chiller Unit 1',          kw: 74,  anomaly: false },
];
const ENERGY_WASTE = [
  { type: 'Idle phantom loads',   kwh: 142, cost: 1136, asset: 'MCH-06'  },
  { type: 'Peak demand spike',    kwh: 98,  cost: 2940, asset: 'Line C'  },
  { type: 'Compressed air leak',  kwh: 67,  cost: 536,  asset: 'CMP-001' },
  { type: 'HVAC overcooling',     kwh: 54,  cost: 432,  asset: 'HVAC-1'  },
  { type: 'Furnace heat cycling', kwh: 41,  cost: 328,  asset: 'MCH-03'  },
];

// ══════════════════════════════════════════════════════════════
// Supply Chain Resilience Agent
// ══════════════════════════════════════════════════════════════
export const supplyRouter = Router();

supplyRouter.get('/risks', (_req, res) => res.json({ risks: loadSupplyRisks() }));
supplyRouter.get('/forecast', (_req, res) => res.json({ forecast: [
  { w: 'W17', actual: 2400, forecast: 2380 }, { w: 'W18', actual: 2610, forecast: 2580 },
  { w: 'W19', actual: null, forecast: 2490 }, { w: 'W20', actual: null, forecast: 2650 },
  { w: 'W21', actual: null, forecast: 2710 }, { w: 'W22', actual: null, forecast: 2580 },
]}));

supplyRouter.post('/reorder', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { material, quantity } = req.body as { material: string; quantity: number };
  try {
    const pr = await createPurchaseRequisition({ material, plant: process.env.SAP_PLANT_CODE!, quantity, text: '[ManuAI Supply] Risk-triggered reorder', deliveryDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0] });
    res.json({ success: true, prId: pr.PurchaseRequisition });
  } catch { res.status(502).json({ error: 'SAP MM unavailable' }); }
});

const SUPPLY_RISKS = [
  { supplier: 'Siemens AG',      sku: 'SRV-750W',  risk: 'high',   reason: 'Financial distress flag',    leadDrift: 18, exposure: 'Rs 8.4L',  action: 'Alternate source'  },
  { supplier: 'Alfa Laval',      sku: 'HX-PLATES', risk: 'medium', reason: 'Port congestion Chennai',     leadDrift: 7,  exposure: 'Rs 2.1L',  action: 'Safety stock +20%' },
  { supplier: 'SKF India',       sku: 'BRG-6205',  risk: 'low',    reason: 'On track',                    leadDrift: 0,  exposure: 'Rs 0.9L',  action: 'No action'         },
  { supplier: 'BASF Chemicals',  sku: 'CMPD-X12',  risk: 'high',   reason: 'Geopolitical: EU export ban', leadDrift: 21, exposure: 'Rs 12L',   action: 'Dual-source now'   },
];

// ══════════════════════════════════════════════════════════════
// Digital Twin Operations Agent
// ══════════════════════════════════════════════════════════════
export const twinRouter = Router();

twinRouter.get('/status',     (_req, res) => res.json({ syncedAt: new Date().toISOString(), accuracy: 94.7, diverging: 4, scenarios: 3 }));
twinRouter.get('/divergence', (_req, res) => {
  const kpis = loadTwinKPIs();
  const divergence = kpis.map(k => {
    const delta = k.actual - k.twin_predicted;
    const pct = k.twin_predicted !== 0 ? Math.abs(delta / k.twin_predicted * 100) : 0;
    const status = pct > k.threshold_pct * 2 ? 'critical' : pct > k.threshold_pct ? 'diverging' : 'aligned';
    const sign = delta >= 0 ? '+' : '';
    return { kpi: k.kpi_name, actual: k.actual, twin: k.twin_predicted,
             delta: `${sign}${delta.toFixed(1)}${k.unit === '%' ? '%' : ''}`,
             status, time: 'live' };
  });
  res.json({ divergence });
});
twinRouter.get('/scenarios',  (_req, res) => res.json({ scenarios: TWIN_SCENARIOS }));

twinRouter.post('/scenarios/:id/run', requireRole(ROLES.ENGINEER, ROLES.ADMIN), (req, res) => {
  logger.info('Twin scenario run', { id: req.params.id, user: req.user?.name });
  res.json({ success: true, scenarioId: req.params.id, status: 'running', estimatedMinutes: 8 });
});

const TWIN_DIVERGENCE = [
  { kpi: 'Reactor Temp TIC-101', actual: 182,  twin: 186,  delta: '+4°C',   status: 'diverging', time: '4h ago' },
  { kpi: 'Conveyor Speed Line D',actual: 1.24,  twin: 1.24, delta: '0',      status: 'aligned',   time: 'now'    },
  { kpi: 'MCH-06 Vibration RMS', actual: 10.2,  twin: 8.1,  delta: '+2.1',   status: 'critical',  time: '1h ago' },
  { kpi: 'Plant OEE',            actual: 76.8,  twin: 79.4, delta: '-2.6%',  status: 'diverging', time: '2h ago' },
];
const TWIN_SCENARIOS = [
  { id: 'SCN-01', name: 'Maintenance window optimisation',  status: 'running',  impact: '+4.2% throughput',    confidence: 0.91 },
  { id: 'SCN-02', name: 'Grade change X-12 to Y-07',        status: 'complete', impact: '-18% transition loss', confidence: 0.87 },
  { id: 'SCN-03', name: 'Energy load shifting off-peak',    status: 'pending',  impact: '-11% peak demand',    confidence: 0.84 },
];

// ══════════════════════════════════════════════════════════════
// Safety & Compliance Agent
// ══════════════════════════════════════════════════════════════
export const safetyRouter = Router();

safetyRouter.get('/events', (_req, res) => res.json({ events: SAFETY_EVENTS, openCritical: 1 }));
safetyRouter.get('/ptw', (_req, res) => res.json({ permits: loadSafetyPermits() }));

safetyRouter.post('/ptw/:id/approve', requireRole(ROLES.ENGINEER, ROLES.SUPERVISOR, ROLES.ADMIN), (req, res) => {
  logger.info('PTW approval', { id: req.params.id, user: req.user?.name });
  res.json({ success: true, ptwId: req.params.id, approvedBy: req.user?.name, at: new Date().toISOString() });
});

const SAFETY_EVENTS = [
  { id: 'EVT-091', time: '09:30', zone: 'Zone C', type: 'Gas leak precursor', signal: 'Pressure anomaly H2S sensor 3', severity: 'critical', action: 'Evacuation alert issued', status: 'open'     },
  { id: 'EVT-090', time: '08:15', zone: 'Zone A', type: 'LOTO deviation',      signal: 'MCH-06 isolation incomplete',   severity: 'high',     action: 'WO suspended',           status: 'resolved' },
  { id: 'EVT-089', time: '07:45', zone: 'Zone B', type: 'Proximity alert',     signal: 'AMR entered human zone',         severity: 'medium',   action: 'AMR speed reduced',      status: 'resolved' },
];
const PTW_LIST = [
  { id: 'PTW-0341', asset: 'MCH-06',  type: 'Hot work',            tech: 'K. Patel', status: 'pending',  jha: 'Complete',  isolation: 'Verified', competency: 'Valid' },
  { id: 'PTW-0340', asset: 'CMP-001', type: 'Confined space',      tech: 'R. Singh', status: 'approved', jha: 'Complete',  isolation: 'Verified', competency: 'Valid' },
  { id: 'PTW-0339', asset: 'HYD-003', type: 'Electrical isolation', tech: 'M. Verma', status: 'rejected', jha: 'Incomplete',isolation: 'Pending',  competency: 'Valid' },
];

// ══════════════════════════════════════════════════════════════
// Semantic Layer Routes
// ══════════════════════════════════════════════════════════════
export const semanticRouter = Router();

semanticRouter.get('/kpis',   (_req, res) => res.json({ kpis: semanticLayer.getKPIDefinitions() }));
semanticRouter.get('/events', async (_req, res) => res.json({ events: await semanticLayer.getRecentEvents(50) }));

// ══════════════════════════════════════════════════════════════
// Unified AI Routes
// ══════════════════════════════════════════════════════════════
export const aiRouter = Router();

const ChatSchema = z.object({
  messages: z.array(z.object({ role: z.enum(['user', 'assistant']), content: z.string() })),
  liveContext: z.string().optional(),
});

aiRouter.post('/chat', async (req, res) => {
  const parsed = ChatSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.issues }); return; }
  try {
    const reply = await unifiedChat(parsed.data.messages, parsed.data.liveContext);
    res.json({ reply });
  } catch { res.status(503).json({ error: 'AI service unavailable' }); }
});

aiRouter.post('/recommend/:agent', async (req, res) => {
  const { context, question } = req.body as { context: string; question: string };
  try {
    const reply = await agentRecommendation(req.params.agent, context, question);
    res.json({ reply, agent: req.params.agent });
  } catch { res.status(503).json({ error: 'AI service unavailable' }); }
});

aiRouter.post('/semantic-query', async (req, res) => {
  const { question, kpiContext } = req.body as { question: string; kpiContext: string };
  try {
    const reply = await semanticQuery(question, kpiContext);
    res.json({ reply });
  } catch { res.status(503).json({ error: 'AI service unavailable' }); }
});
