import { safetyRouter } from './all-routes';
export default safetyRouter;
