import { energyRouter } from './all-routes';
export default energyRouter;
