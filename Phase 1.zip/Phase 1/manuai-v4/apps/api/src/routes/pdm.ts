import { pdmRouter } from './all-routes';
export default pdmRouter;
