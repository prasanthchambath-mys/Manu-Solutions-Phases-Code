import { aiRouter } from './all-routes';
export default aiRouter;
