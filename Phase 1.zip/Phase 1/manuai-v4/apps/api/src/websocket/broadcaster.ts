import { Server } from 'socket.io';
import { Server as HttpServer } from 'http';
import { logger } from '../middleware/logger';

let io: Server;

export type AgentChannel = 'oee' | 'yield' | 'pdm' | 'quality' | 'energy' | 'supply' | 'twin' | 'safety' | 'semantic' | 'alerts';

export function initWebSocket(httpServer: HttpServer): void {
  io = new Server(httpServer, {
    cors: { origin: process.env.CORS_ORIGINS?.split(',') ?? ['http://localhost:5173'], methods: ['GET', 'POST'] },
    transports: ['websocket', 'polling'],
  });
  io.on('connection', (socket) => {
    socket.on('subscribe', (channels: AgentChannel[]) => channels.forEach(ch => socket.join(ch)));
    socket.on('disconnect', () => logger.debug('WS disconnect', { id: socket.id }));
  });
  logger.info('WebSocket server ready');
}

export function broadcast(channel: AgentChannel, data: unknown): void {
  io?.to(channel).emit('update', { channel, ts: Date.now(), data });
}

export function broadcastEvent(event: Record<string, unknown>): void {
  io?.emit('cross_agent_event', event);
}
