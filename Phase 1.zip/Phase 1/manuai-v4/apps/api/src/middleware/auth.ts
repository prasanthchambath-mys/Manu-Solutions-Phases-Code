import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { logger } from './logger';

declare global {
  namespace Express {
    interface Request {
      user?: { oid: string; name: string; roles: string[] };
    }
  }
}

export const ROLES = {
  OPERATOR: 'operator', SUPERVISOR: 'supervisor', MAINTENANCE: 'maintenance',
  ENGINEER: 'engineer', EXECUTIVE: 'executive', ADMIN: 'admin',
} as const;
export type Role = typeof ROLES[keyof typeof ROLES];

export const authMiddleware = (req: Request, res: Response, next: NextFunction): void => {
  // Dev bypass — set MOCK_AUTH=true in .env.local
  if (process.env.MOCK_AUTH === 'true') {
    req.user = { oid: 'dev-user', name: 'Dev User', roles: [ROLES.ADMIN] };
    return next();
  }
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) { res.status(401).json({ error: 'Unauthorized' }); return; }
  try {
    const decoded = jwt.decode(header.slice(7)) as Record<string, unknown>;
    if (!decoded) throw new Error('Invalid token');
    req.user = {
      oid: decoded.oid as string ?? 'unknown',
      name: decoded.name as string ?? 'User',
      roles: (decoded.roles as string[]) ?? [ROLES.OPERATOR],
    };
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
};

export const requireRole = (...allowed: Role[]) =>
  (req: Request, res: Response, next: NextFunction): void => {
    const roles = req.user?.roles ?? [];
    if (allowed.some(r => roles.includes(r)) || roles.includes(ROLES.ADMIN)) return next();
    res.status(403).json({ error: `Requires role: ${allowed.join(' or ')}` });
  };
