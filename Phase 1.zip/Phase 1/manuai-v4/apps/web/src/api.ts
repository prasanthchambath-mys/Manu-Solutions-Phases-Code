import axios from 'axios';
import { io, Socket } from 'socket.io-client';

// ── HTTP client ────────────────────────────────────────────────
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL ?? '',
  timeout: 12_000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach Bearer token (set by auth hook after Azure AD login)
api.interceptors.request.use((config) => {
  const token = sessionStorage.getItem('manuai_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401) {
      sessionStorage.removeItem('manuai_token');
      // window.location.href = '/login'; // Uncomment in production
    }
    return Promise.reject(err instanceof Error ? err : new Error(String(err)));
  },
);

// ── Agent API methods ──────────────────────────────────────────
export const oeeApi = {
  getLive:   () => api.get('/api/oee/live').then(r => r.data),
  getLosses: () => api.get('/api/oee/losses').then(r => r.data),
  getAlerts: () => api.get('/api/oee/alerts').then(r => r.data),
  ackAlert:  (id: string) => api.post(`/api/oee/alerts/${id}/ack`).then(r => r.data),
};

export const yieldApi = {
  getParams: () => api.get('/api/yield/params').then(r => r.data),
  dcsWrite:  (tagId: string, value: number, reason: string) =>
    api.post('/api/yield/dcs-write', { tagId, value, reason }).then(r => r.data),
  getLims:   () => api.get('/api/yield/lims').then(r => r.data),
  getOrders: () => api.get('/api/yield/orders').then(r => r.data),
};

export const pdmApi = {
  getAssets:    () => api.get('/api/pdm/assets').then(r => r.data),
  getSensors:   (id: string) => api.get(`/api/pdm/sensors/${id}`).then(r => r.data),
  getWorkOrders:() => api.get('/api/pdm/workorders').then(r => r.data),
  createWO:     (body: { equipment: string; description: string; priority?: string }) =>
    api.post('/api/pdm/workorders', body).then(r => r.data),
  partsOrder:   (body: { material: string; quantity: number; assetId: string; reason: string }) =>
    api.post('/api/pdm/parts-order', body).then(r => r.data),
};

export const qualityApi = {
  getDefects: () => api.get('/api/quality/defects').then(r => r.data),
  getLines:   () => api.get('/api/quality/lines').then(r => r.data),
};

export const energyApi = {
  getLoad:    () => api.get('/api/energy/load').then(r => r.data),
  dispatch:   (body: { assetId: string; action: string }) => api.post('/api/energy/dispatch', body).then(r => r.data),
};

export const supplyApi = {
  getRisks:    () => api.get('/api/supply/risks').then(r => r.data),
  getForecast: () => api.get('/api/supply/forecast').then(r => r.data),
  reorder:     (body: { material: string; quantity: number }) => api.post('/api/supply/reorder', body).then(r => r.data),
};

export const twinApi = {
  getStatus:    () => api.get('/api/twin/status').then(r => r.data),
  getDivergence:() => api.get('/api/twin/divergence').then(r => r.data),
  getScenarios: () => api.get('/api/twin/scenarios').then(r => r.data),
  runScenario:  (id: string) => api.post(`/api/twin/scenarios/${id}/run`).then(r => r.data),
};

export const safetyApi = {
  getEvents:  () => api.get('/api/safety/events').then(r => r.data),
  getPTW:     () => api.get('/api/safety/ptw').then(r => r.data),
  approvePTW: (id: string) => api.post(`/api/safety/ptw/${id}/approve`).then(r => r.data),
};

export const semanticApi = {
  getKPIs:   () => api.get('/api/semantic/kpis').then(r => r.data),
  getEvents: () => api.get('/api/semantic/events').then(r => r.data),
};

export const aiApi = {
  chat: (messages: Array<{ role: 'user' | 'assistant'; content: string }>, liveContext?: string) =>
    api.post<{ reply: string }>('/api/ai/chat', { messages, liveContext }).then(r => r.data),
  recommend: (agent: string, context: string, question: string) =>
    api.post<{ reply: string }>(`/api/ai/recommend/${agent}`, { context, question }).then(r => r.data),
};

// ── WebSocket ──────────────────────────────────────────────────
let socket: Socket | null = null;

export function getSocket(): Socket {
  if (!socket) {
    socket = io(import.meta.env.VITE_WS_URL ?? '', {
      transports: ['websocket', 'polling'],
      reconnectionAttempts: 10,
      reconnectionDelay: 2000,
    });
  }
  return socket;
}

export function subscribeChannels(channels: string[]): void {
  getSocket().emit('subscribe', channels);
}

export default api;
