import { useEffect, useRef, useCallback, useState } from 'react';
import { useStore } from '../store';

export function useInterval(fn: () => void, ms: number | null): void {
  const ref = useRef(fn);
  useEffect(() => { ref.current = fn; }, [fn]);
  useEffect(() => {
    if (ms === null) return;
    const id = setInterval(() => ref.current(), ms);
    return () => clearInterval(id);
  }, [ms]);
}

export function useLiveOEE() {
  const { machines, plantOEE, fetchMachines } = useStore();
  useEffect(() => { void fetchMachines(); }, []);
  useInterval(fetchMachines, 3500);
  return { machines, plantOEE };
}

export function useAsync<T>(fetcher: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try { setData(await fetcher()); }
    catch (e) { setError(e instanceof Error ? e.message : 'Error'); }
    finally { setLoading(false); }
  }, deps);
  useEffect(() => { void load(); }, [load]);
  return { data, loading, error, refetch: load };
}

// Sets a dev mock token so the axios interceptor passes auth headers
export function useDevAuth(): void {
  useEffect(() => {
    if (import.meta.env.VITE_MOCK_DATA === 'true') {
      sessionStorage.setItem('manuai_token', 'dev-mock-token');
    }
  }, []);
}
