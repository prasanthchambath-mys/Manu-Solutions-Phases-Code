// ── White-background light theme ──────────────────────────────
export const T = {
  // Backgrounds
  bg:      '#f8f9fc',
  surface: '#ffffff',
  s2:      '#f1f4f9',
  s3:      '#e8edf5',
  s4:      '#dde4ef',
  border:  '#d1d9e6',
  borderHi:'#b8c4d8',

  // Agent accent colours (vivid on white)
  yield:   '#7c3aed', yDim:'rgba(124,58,237,.1)',  y2:'#6d28d9',
  pdm:     '#d97706', pDim:'rgba(217,119,6,.1)',    p2:'#b45309',
  parts:   '#2563eb', ptDim:'rgba(37,99,235,.1)',   pt2:'#1d4ed8',
  oee:     '#0891b2', oDim:'rgba(8,145,178,.1)',    o2:'#0e7490',
  sem:     '#0d9488', sDim:'rgba(13,148,136,.1)',   s2c:'#0f766e',

  // New agents
  energy:  '#ea580c', enDim:'rgba(234,88,12,.1)',   en2:'#c2410c',
  supply:  '#16a34a', suDim:'rgba(22,163,74,.1)',   su2:'#15803d',
  twin:    '#7c3aed', twDim:'rgba(124,58,237,.1)',  tw2:'#6d28d9',
  safety:  '#dc2626', sfDim:'rgba(220,38,38,.1)',   sf2:'#b91c1c',
  quality: '#0369a1', quDim:'rgba(3,105,161,.1)',   qu2:'#075985',

  // Status
  green:  '#16a34a', gDim:'rgba(22,163,74,.1)',
  red:    '#dc2626', rDim:'rgba(220,38,38,.1)',
  amber:  '#d97706', aDim:'rgba(217,119,6,.1)',
  orange: '#ea580c', orDim:'rgba(234,88,12,.1)',
  blue:   '#2563eb', bDim:'rgba(37,99,235,.1)',

  // Text
  txt:  '#0f172a',
  txt2: '#1e293b',
  m2:   '#64748b',
  m3:   '#94a3b8',
};

export const tt = {
  contentStyle:{background:'#ffffff',border:'1px solid #d1d9e6',borderRadius:8,fontSize:11,color:'#0f172a',boxShadow:'0 4px 12px rgba(0,0,0,.08)'},
  labelStyle:{color:'#64748b'},
};

export const hc = h => h<40?T.red:h<60?T.orange:h<80?T.amber:T.green;
export const sc = s => ({
  critical:T.red, warning:T.amber, caution:'#ca8a04', good:T.green,
  pass:T.green, fail:T.red, open:T.amber, in_progress:T.blue,
  completed:T.green, scheduled:T.m2, blocked:T.red, active:T.green,
  upcoming:T.amber, planned:T.m2,
}[s]||T.m2);
