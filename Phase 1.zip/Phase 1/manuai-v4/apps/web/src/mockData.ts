import { T } from './tokens';

export const MACHINES = [
  {id:'MCH-01',name:'Injection Moulding #1',line:'Line A',plant:'P1',oee:71.2,avail:88.4,perf:83.6,qual:96.3,health:71,rul:34,status:'warning', loss:'Speed Loss',         lossMin:42, vib:3.8,temp:74},
  {id:'MCH-02',name:'Injection Moulding #2',line:'Line A',plant:'P1',oee:84.6,avail:94.1,perf:91.2,qual:98.5,health:84,rul:82,status:'good',    loss:'Minor Stops',        lossMin:18, vib:1.9,temp:61},
  {id:'MCH-03',name:'CNC Machining Centre', line:'Line B',plant:'P1',oee:62.1,avail:78.3,perf:82.4,qual:96.1,health:38,rul:9, status:'critical',loss:'Unplanned Breakdown',lossMin:94, vib:9.1,temp:92},
  {id:'MCH-04',name:'Assembly Station 1',   line:'Line B',plant:'P1',oee:89.3,avail:96.2,perf:94.1,qual:98.8,health:89,rul:105,status:'good',   loss:'Changeover & Setup', lossMin:11, vib:1.2,temp:48},
  {id:'MCH-05',name:'Welding Robot A',      line:'Line C',plant:'P2',oee:76.4,avail:91.3,perf:86.2,qual:97.4,health:76,rul:41,status:'caution', loss:'Minor Stops',        lossMin:31, vib:3.2,temp:68},
  {id:'MCH-06',name:'Welding Robot B',      line:'Line C',plant:'P2',oee:55.8,avail:72.1,perf:80.3,qual:96.8,health:32,rul:7, status:'critical',loss:'Unplanned Breakdown',lossMin:128,vib:10.2,temp:97},
  {id:'MCH-07',name:'Conveyor System X1',   line:'Line D',plant:'P2',oee:91.2,avail:97.4,perf:95.3,qual:98.3,health:91,rul:138,status:'good',   loss:'Startup Defects',    lossMin:8,  vib:0.8,temp:42},
  {id:'MCH-08',name:'Packaging Line P1',    line:'Line D',plant:'P2',oee:78.9,avail:89.7,perf:90.4,qual:97.5,health:78,rul:58,status:'caution', loss:'Speed Loss',         lossMin:27, vib:2.6,temp:55},
];
export const UTIL = [
  {id:'CMP-001',name:'Air Compressor A1',   type:'Utility',health:34,rul:12,status:'critical',vib:8.7,temp:94,press:12.1,oeeLink:'Line A pressure risk'},
  {id:'CHP-002',name:'Chiller Unit 1',      type:'Utility',health:67,rul:48,status:'warning', vib:2.4,temp:18,press:3.2, oeeLink:'−2.8% perf MCH-01'},
  {id:'HYD-003',name:'Hydraulic Power Unit',type:'Utility',health:81,rul:74,status:'good',    vib:1.6,temp:58,press:180, oeeLink:null},
  {id:'PMP-005',name:'Coolant Pump C7',     type:'Utility',health:78,rul:72,status:'caution', vib:2.1,temp:58,press:8.3, oeeLink:null},
];
export const DT_COMPS = {
  'MCH-03':[{c:'Spindle Bearing',h:28,t:92,v:9.1,a:true},{c:'Ball Screw X',h:61,t:64,v:2.8,a:false},{c:'Servo Drive',h:74,t:71,v:1.9,a:false},{c:'Coolant Pump',h:55,t:78,v:3.4,a:true},{c:'Spindle Motor',h:82,t:69,v:2.1,a:false},{c:'Linear Guide',h:79,t:54,v:1.4,a:false}],
  'MCH-06':[{c:'Servo Drive J1',h:24,t:97,v:10.2,a:true},{c:'Servo Drive J2',h:61,t:72,v:3.1,a:false},{c:'Wrist Assembly',h:48,t:84,v:6.2,a:true},{c:'Power Supply',h:71,t:68,v:1.2,a:false},{c:'Base Bearing',h:55,t:74,v:4.1,a:false},{c:'Teach Pendant',h:88,t:42,v:0.4,a:false}],
  'CMP-001':[{c:'Bearing (DE)',h:31,t:94,v:8.7,a:true},{c:'Bearing (NDE)',h:68,t:71,v:3.1,a:false},{c:'Piston Rings',h:55,t:82,v:5.2,a:true},{c:'Valve Assembly',h:72,t:68,v:2.4,a:false},{c:'Motor Winding',h:84,t:58,v:1.2,a:false},{c:'Coupling',h:77,t:64,v:2.8,a:false}],
};
export const SIX_LOSSES = [
  {name:'Unplanned Breakdown',min:222,pct:37.0,col:T.red,   cnt:4, machines:['MCH-03','MCH-06']},
  {name:'Changeover & Setup', min:142,pct:23.7,col:T.amber, cnt:18,machines:['MCH-01','MCH-04']},
  {name:'Minor Stops',        min:98, pct:16.3,col:'#fbbf24',cnt:47,machines:['MCH-02','MCH-05']},
  {name:'Speed Loss',         min:82, pct:13.7,col:T.orange,cnt:12,machines:['MCH-01','MCH-08']},
  {name:'Startup Defects',    min:31, pct:5.2, col:T.yield, cnt:6, machines:['MCH-07']},
  {name:'In-process Defects', min:24, pct:4.0, col:T.parts, cnt:9, machines:['MCH-03']},
];
export const OEE_TREND=[
  {day:'Mon',oee:74.2,yld:87.2,health:72,target:85},{day:'Tue',oee:76.8,yld:88.1,health:70,target:85},
  {day:'Wed',oee:75.1,yld:89.4,health:68,target:85},{day:'Thu',oee:78.3,yld:90.2,health:68,target:85},
  {day:'Fri',oee:79.1,yld:90.8,health:65,target:85},{day:'Sat',oee:72.4,yld:88.4,health:52,target:85,event:'MCH-06'},
  {day:'Sun',oee:76.8,yld:91.3,health:68,target:85},
];
export const LOSS_TREND=[
  {w:'W13',brk:320,chg:180,mst:140,spd:110,def:60},{w:'W14',brk:290,chg:175,mst:128,spd:102,def:54},
  {w:'W15',brk:260,chg:168,mst:115,spd:94, def:48},{w:'W16',brk:222,chg:142,mst:98, spd:82, def:55},
];
export const RUL_TREND=[
  {d:'Apr 10',m3:28,m6:22,cmp:48},{d:'Apr 11',m3:24,m6:18,cmp:44},{d:'Apr 12',m3:20,m6:15,cmp:41},
  {d:'Apr 13',m3:16,m6:12,cmp:38},{d:'Apr 14',m3:13,m6:10,cmp:35},{d:'Apr 15',m3:11,m6:8,cmp:32},
  {d:'Apr 16',m3:9, m6:7, cmp:12},
];
export const SENSOR_H = Array.from({length:24},(_,i)=>({
  t:`${String(i).padStart(2,'0')}:00`,
  vib:+(5.8+Math.sin(i/3)*2.2+(i>18?3.1:0)+Math.random()*0.4).toFixed(2),
  tmp:+(84+Math.sin(i/4)*7+(i>18?10:0)+Math.random()*1.2).toFixed(1),
}));
export const YIELD_PARAMS=[
  {id:'TIC-101',name:'Reactor Temp',  val:182,tgt:186,unit:'°C',   min:160,max:200,warn:true, blocked:true},
  {id:'PIC-102',name:'Pressure',      val:8.4,tgt:8.4,unit:'bar',  min:6,  max:12, warn:false,blocked:false},
  {id:'SIC-204',name:'Mixing Speed',  val:420,tgt:395,unit:'RPM',  min:300,max:500,warn:true, blocked:false},
  {id:'FIC-301',name:'Feed Rate',     val:142,tgt:138,unit:'kg/hr',min:100,max:180,warn:true, blocked:false},
  {id:'TIC-205',name:'Jacket Temp',   val:45.2,tgt:47,unit:'°C',   min:30, max:80, warn:false,blocked:false},
  {id:'FIC-401',name:'Coolant Flow',  val:28.6,tgt:28.6,unit:'L/min',min:20,max:40,warn:false,blocked:false},
];
export const LIMS=[
  {id:'LIMS-0441',time:'09:14',batch:'RM-4421',test:'Moisture Content',  result:'4.2%',  limit:'≤5%',       status:'pass',analyst:'S. Mehta'},
  {id:'LIMS-0440',time:'07:30',batch:'RM-4421',test:'Particle Size D90', result:'182 µm',limit:'150–200 µm',status:'pass',analyst:'R. Sharma'},
  {id:'LIMS-0439',time:'06:00',batch:'RM-4420',test:'Assay Purity',      result:'98.1%', limit:'≥97%',      status:'pass',analyst:'S. Mehta'},
  {id:'LIMS-0438',time:'04:15',batch:'RM-4420',test:'Heavy Metals',      result:'0.8 ppm',limit:'≤1 ppm',   status:'pass',analyst:'T. Nair'},
  {id:'LIMS-0436',time:'00:30',batch:'RM-4419',test:'pH (10% solution)', result:'8.9',   limit:'7.5–8.5',   status:'fail',analyst:'T. Nair'},
];
export const DCS_INIT=[
  {tag:'TIC-101',desc:'Reactor Temperature',cur:182,  rec:186,  unit:'°C',   status:'blocked',  delta:'+4',   impact:'+2.1% yield',blockedBy:'WO-4839'},
  {tag:'SIC-204',desc:'Agitator Speed',      cur:420,  rec:395,  unit:'RPM',  status:'pending',  delta:'−25',  impact:'+0.9% yield',blockedBy:null},
  {tag:'FIC-301',desc:'Feed Rate',           cur:142,  rec:138,  unit:'kg/hr',status:'accepted', delta:'−4',   impact:'+0.5% yield',blockedBy:null},
  {tag:'TIC-205',desc:'Jacket Temperature',  cur:45.2, rec:47.0, unit:'°C',   status:'pending',  delta:'+1.8', impact:'+0.4% yield',blockedBy:null},
  {tag:'PIC-102',desc:'Reactor Pressure',    cur:8.4,  rec:8.4,  unit:'bar',  status:'ok',       delta:'0',    impact:'—',           blockedBy:null},
];
export const SAP_ORDERS=[
  {id:'PO-88441',product:'Compound X-12',qty:'2,400 kg',start:'Apr 14',end:'Apr 16',status:'running',  actual:91.3,plan:88.0},
  {id:'PO-88389',product:'Compound Y-07',qty:'1,800 kg',start:'Apr 12',end:'Apr 14',status:'completed',actual:90.1,plan:88.0},
  {id:'PO-88302',product:'Compound X-12',qty:'2,200 kg',start:'Apr 10',end:'Apr 12',status:'completed',actual:87.4,plan:88.0},
  {id:'PO-88501',product:'Compound Z-03',qty:'900 kg',  start:'Apr 17',end:'Apr 18',status:'planned',  actual:null,plan:88.5},
];
export const BENCHMARK=[
  {day:'Mon',a:88.4,b:85.1,c:87.0},{day:'Tue',a:89.2,b:86.3,c:88.1},{day:'Wed',a:90.1,b:87.0,c:88.8},
  {day:'Thu',a:90.8,b:87.4,c:89.2},{day:'Fri',a:91.1,b:87.6,c:89.0},{day:'Sat',a:90.9,b:87.5,c:88.9},{day:'Sun',a:91.3,b:87.6,c:89.1},
];
export const YIELD_FEATS=[{f:'Reactor Temp',v:31},{f:'Feed Rate',v:22},{f:'Mixing Speed',v:18},{f:'Moisture',v:14},{f:'Jacket Temp',v:9},{f:'Pressure',v:6}];
export const PDM_FEATS=[{f:'Vibration RMS',v:32},{f:'Thermal Delta',v:26},{f:'Pressure Var.',v:16},{f:'Run Hours',v:11},{f:'Ambient Temp',v:9},{f:'Load Factor',v:6}];
export const MODEL_YIELD=[
  {date:'Apr 12',r2:0.961,mse:0.0031,samples:2840,status:'deployed'},
  {date:'Apr 05',r2:0.954,mse:0.0038,samples:2710,status:'archived'},
  {date:'Mar 29',r2:0.948,mse:0.0042,samples:2650,status:'archived'},
];
export const MODEL_PDM=[
  {date:'Apr 12',f1:0.934,prec:0.941,rec:0.928,samples:24840,status:'deployed'},
  {date:'Mar 29',f1:0.918,prec:0.926,rec:0.910,samples:23200,status:'archived'},
  {date:'Mar 15',f1:0.901,prec:0.908,rec:0.894,samples:21800,status:'archived'},
];
export const WO_INIT=[
  {id:'WO-4841',asset:'MCH-06',name:'Welding Robot B',  type:'Corrective',pri:'P1',desc:'Servo drive J1 overtemp F-041. OEE −14.2% Line C.',status:'open',       assigned:'K. Patel', oeeLink:true},
  {id:'WO-4840',asset:'MCH-03',name:'CNC Machining Ctr',type:'Corrective',pri:'P1',desc:'Spindle alarm A-102. Availability 78.3%.', status:'in_progress',assigned:'R. Singh',  oeeLink:true},
  {id:'WO-4839',asset:'CMP-001',name:'Air Compressor A1',type:'Predictive',pri:'P2',desc:'Bearing RUL 12d. Blocks TIC-101 Yield rec.',status:'open',       assigned:'Unassigned',oeeLink:false},
  {id:'WO-4838',asset:'MCH-01',name:'Injection Moulding #1',type:'Predictive',pri:'P2',desc:'Speed loss via CHP-002 coolant variance.',status:'scheduled',  assigned:'M. Verma',  oeeLink:true},
];
export const PARTS_INIT=[
  {id:'ORD-2041',sku:'SRV-750W',part:'Servo Drive 750W',      asset:'MCH-06',qty:1, cost:28000,status:'escalated',       rules:'R3+R5+R6',rul:7, lead:5},
  {id:'ORD-2042',sku:'BRG-6205',part:'SKF 6205-2RS Bearing',  asset:'MCH-03',qty:6, cost:5100, status:'pending_approval',rules:'R1+R4',   rul:9, lead:2},
  {id:'ORD-2043',sku:'TCK-001', part:'Tube Cleaning Kit',      asset:'CHP-002',qty:3,cost:1350, status:'ordered',         rules:'R2',     rul:48,lead:2},
  {id:'ORD-2044',sku:'GRS-EP2', part:'Grease Cartridge EP2',   asset:'CMP-001',qty:12,cost:1440,status:'ordered',         rules:'R1',     rul:12,lead:1},
];
export const PARTS_INV=[
  {sku:'SRV-750W',name:'Servo Drive 750W',       asset:'MCH-06',stock:0, reorder:1,lead:5,cost:28000,autoOrder:false},
  {sku:'BRG-6205',name:'SKF 6205-2RS Bearing',   asset:'MCH-03',stock:2, reorder:4,lead:2,cost:850,  autoOrder:true},
  {sku:'BRG-CMP1',name:'Compressor Drive Bearing',asset:'CMP-001',stock:1,reorder:2,lead:3,cost:1200, autoOrder:true},
  {sku:'SLK-MK07',name:'Mechanical Seal Kit',    asset:'PMP-005',stock:5, reorder:3,lead:5,cost:2100, autoOrder:true},
  {sku:'GRS-EP2', name:'Grease Cartridge EP2',   asset:'CMP-001',stock:12,reorder:5,lead:1,cost:120,  autoOrder:true},
];
export const SPEND_TREND=[
  {m:'Nov',planned:142000,unplanned:88000},{m:'Dec',planned:155000,unplanned:94000},
  {m:'Jan',planned:148000,unplanned:76000},{m:'Feb',planned:163000,unplanned:61000},
  {m:'Mar',planned:171000,unplanned:48000},{m:'Apr',planned:180000,unplanned:22000},
];
export const SUPPLIER_PERF=[
  {s:'SKF India',      onTime:96,defects:0.4,avgLead:2.8,orders:24},
  {s:'Siemens Spares', onTime:88,defects:0.8,avgLead:6.5,orders:11},
  {s:'Alfa Laval',     onTime:94,defects:0.2,avgLead:1.9,orders:18},
  {s:'Shell Lubes',    onTime:99,defects:0.1,avgLead:0.9,orders:42},
];
export const SHIFTS=[
  {shift:'Morning A',  tech:'K. Patel', role:'Mech Tech',assets:5,wos:2,status:'active',   start:'06:00',end:'14:00'},
  {shift:'Morning B',  tech:'R. Singh', role:'Mech Tech',assets:4,wos:2,status:'active',   start:'06:00',end:'14:00'},
  {shift:'Afternoon A',tech:'M. Verma', role:'Elec Tech',assets:5,wos:1,status:'upcoming', start:'14:00',end:'22:00'},
  {shift:'Night A',    tech:'S. Joshi', role:'Mech Tech',assets:3,wos:0,status:'scheduled',start:'22:00',end:'06:00'},
];
export const CROSS_EVENTS=[
  {id:'XEV-031',ts:'09:42',from:'pdm',  to:'oee',   type:'BREAKDOWN_CAUSED_OEE_LOSS',   asset:'MCH-06', msg:'Servo fault F-041. OEE Unplanned Breakdown 128 min Line C. WO-4841 raised.', impact:'−14.2% OEE Line C',sev:'critical'},
  {id:'XEV-030',ts:'08:17',from:'pdm',  to:'oee',   type:'BREAKDOWN_CAUSED_OEE_LOSS',   asset:'MCH-03', msg:'Spindle alarm A-102. Availability 78.3%, 94 min lost.',                      impact:'−8.4% OEE Line B', sev:'critical'},
  {id:'XEV-029',ts:'08:15',from:'pdm',  to:'yield', type:'ASSET_HEALTH_DEGRADED',        asset:'CMP-001',msg:'Bearing fault. TIC-101 rec BLOCKED — unsafe at 186°C on degraded bearing.', impact:'Yield rec blocked', sev:'critical'},
  {id:'XEV-028',ts:'07:55',from:'pdm',  to:'oee',   type:'UTILITY_CAUSING_SPEED_LOSS',  asset:'CHP-002',msg:'Chiller coolant +4°C drift → MCH-01 mould temp instability. Speed loss.',   impact:'−2.8% perf MCH-01',sev:'warning'},
  {id:'XEV-027',ts:'07:30',from:'oee',  to:'yield', type:'OEE_QUALITY_AFFECTS_YIELD',   asset:'MCH-03', msg:'In-process defect 1.6% Line B. Same root cause as PdM spindle alert.',       impact:'−0.9% yield',      sev:'warning'},
  {id:'XEV-026',ts:'06:30',from:'parts',to:'pdm',   type:'ORDER_RAISED_PRE_FAILURE',    asset:'MCH-06', msg:'ORD-2041 Servo Drive raised. RUL 7d + 0 stock + lead 5d → escalated.',       impact:'WO parts secured',  sev:'info'},
  {id:'XEV-025',ts:'05:10',from:'yield',to:'oee',   type:'SETPOINT_WRITTEN_TO_DCS',     asset:'FIC-301',msg:'Feed rate 142→138 kg/hr accepted. DCS write confirmed via OPC-UA.',          impact:'+0.5% yield',       sev:'info'},
];
export const ALERT_INIT=[
  {id:'ALT-091',ts:'09:42',machine:'MCH-06',line:'Line C',type:'Unplanned Breakdown',msg:'Servo drive overtemp F-041. 128 min lost. PdM root cause: RUL 7d, bearing fault. WO-4841 open.',sev:'critical',routed:'Maintenance — S. Rao',  ack:false},
  {id:'ALT-090',ts:'08:17',machine:'MCH-03',line:'Line B',type:'Unplanned Breakdown',msg:'Spindle alarm A-102. 94 min lost. PdM: vibration 9.1 mm/s (173% of ISO limit).',               sev:'critical',routed:'Maintenance — K. Patel',ack:false},
  {id:'ALT-089',ts:'07:55',machine:'MCH-01',line:'Line A',type:'Speed Loss',          msg:'Performance 83.6% (target 95%). Root: CHP-002 coolant variance (XEV-028).',                    sev:'warning', routed:'Operator — M. Verma',   ack:false},
  {id:'ALT-088',ts:'06:30',machine:'MCH-05',line:'Line C',type:'Minor Stops',         msg:'31 micro-stops. Fixture clamping intermittent — WO-4837 raised.',                              sev:'warning', routed:'Supervisor — D. Kumar',  ack:true},
];
export const OEE_SCORECARD=[
  {m:'Nov',p1:68.2,p2:67.4,target:85},{m:'Dec',p1:70.1,p2:69.8,target:85},
  {m:'Jan',p1:72.4,p2:71.9,target:85},{m:'Feb',p1:74.8,p2:74.1,target:85},
  {m:'Mar',p1:75.9,p2:75.3,target:85},{m:'Apr',p1:76.8,p2:76.1,target:85},
];
export const ADOPTION_TREND=[
  {day:'Mon',accepted:6,rejected:1},{day:'Tue',accepted:8,rejected:0},{day:'Wed',accepted:5,rejected:1},
  {day:'Thu',accepted:7,rejected:1},{day:'Fri',accepted:6,rejected:0},{day:'Sat',accepted:4,rejected:1},{day:'Sun',accepted:2,rejected:0},
];
export const SCATTER_DATA = [
  {name:'MCH-01',health:71,oee:71.2,rul:34,size:34},{name:'MCH-02',health:84,oee:84.6,rul:82,size:82},
  {name:'MCH-03',health:38,oee:62.1,rul:9, size:9}, {name:'MCH-04',health:89,oee:89.3,rul:105,size:105},
  {name:'MCH-05',health:76,oee:76.4,rul:41,size:41},{name:'MCH-06',health:32,oee:55.8,rul:7, size:7},
  {name:'MCH-07',health:91,oee:91.2,rul:138,size:138},{name:'MCH-08',health:78,oee:78.9,rul:58,size:58},
];
export const SEMANTIC_KPI = {
  oee:         {name:'OEE',               formula:'Availability × Performance × Quality',          unit:'%',    agents:['oee','pdm','yield'], src:'MES+SCADA+PLC'},
  availability:{name:'Availability',      formula:'(Planned Time − Downtime) / Planned Time',       unit:'%',    agents:['oee','pdm'],         src:'SCADA/PLC'},
  performance: {name:'Performance',       formula:'(Ideal Cycle × Count) / Run Time',               unit:'%',    agents:['oee','pdm'],         src:'MES'},
  quality:     {name:'Quality Rate',      formula:'Good Count / Total Count',                        unit:'%',    agents:['oee','yield'],       src:'MES+QC'},
  yield_pct:   {name:'Production Yield',  formula:'confirmed_qty / planned_qty × 100',              unit:'%',    agents:['yield','pdm'],       src:'SAP PP + PI'},
  scrap_rate:  {name:'Scrap Rate',        formula:'(input − output) / input × 100',                 unit:'%',    agents:['yield','oee'],       src:'PI + SAP PP'},
  rm_waste:    {name:'RM Waste',          formula:'(rm_issued − rm_consumed) / rm_issued × 100',    unit:'%',    agents:['yield'],             src:'SAP MM + PI'},
  asset_health:{name:'Asset Health',      formula:'avg(component_health_score) — ML model',         unit:'%',    agents:['pdm'],               src:'IoT Hub + PI'},
  rul_days:    {name:'RUL (Days)',         formula:'ML: f(vibration, temp, pressure, run_hours)',    unit:'days', agents:['pdm','parts'],       src:'IoT Hub'},
  loss_min:    {name:'Loss Minutes',      formula:'Σ Six Big Loss event durations',                  unit:'min',  agents:['oee','pdm'],         src:'PLC event log'},
  oee_gap:     {name:'OEE Gap',           formula:'Target OEE − Actual OEE',                        unit:'%',    agents:['oee','yield'],       src:'Platform'},
  rec_adoption:{name:'Rec Adoption',      formula:'accepted / total × 100',                          unit:'%',    agents:['yield','pdm','oee'], src:'Platform'},
};
