import React, { useState } from 'react';
import { T, hc, sc } from '../tokens';

export const Bdg = ({label,color,sm}) => (
  <span style={{fontSize:sm?9:10,fontWeight:700,padding:sm?'1px 6px':'2px 8px',borderRadius:4,background:color+'18',color,border:`1px solid ${color}30`,letterSpacing:'0.4px',textTransform:'uppercase',whiteSpace:'nowrap'}}>{label}</span>
);
export const AgChip = ({agent}) => {
  const M={yield:{l:'YIELD',c:T.yield},pdm:{l:'PdM',c:T.pdm},parts:{l:'PARTS',c:T.parts},oee:{l:'OEE',c:T.oee},semantic:{l:'SEMANTIC',c:T.sem},energy:{l:'ENERGY',c:T.energy},supply:{l:'SUPPLY',c:T.supply},twin:{l:'D-TWIN',c:T.twin},safety:{l:'SAFETY',c:T.safety},quality:{l:'QUALITY',c:T.quality}};
  const x=M[agent]||M.semantic; return <Bdg label={x.l} color={x.c} sm/>;
};
export const Kpi = ({label,value,delta,up,color,sub,accent}) => (
  <div style={{background:T.surface,border:`1px solid ${T.border}`,borderTop:`3px solid ${accent||T.border}`,borderRadius:12,padding:'14px 16px',boxShadow:'0 1px 4px rgba(0,0,0,.06)'}}>
    <div style={{fontSize:10,color:T.m2,fontWeight:700,letterSpacing:'0.6px',textTransform:'uppercase',marginBottom:6}}>{label}</div>
    <div style={{fontSize:24,fontWeight:800,color:color||T.txt,letterSpacing:'-0.5px'}}>{value}</div>
    {delta&&<div style={{fontSize:11,color:up?T.green:T.red,fontWeight:600,marginTop:3}}>{up?'▲':'▼'} {delta}</div>}
    {sub&&<div style={{fontSize:10,color:T.m2,marginTop:3}}>{sub}</div>}
  </div>
);
export const Card = ({children,style={}}) => (
  <div style={{background:T.surface,border:`1px solid ${T.border}`,borderRadius:12,padding:16,boxShadow:'0 1px 4px rgba(0,0,0,.05)',...style}}>{children}</div>
);
export const CH = ({title,sub,right}) => (
  <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:14}}>
    <div><div style={{fontSize:13,fontWeight:700,color:T.txt}}>{title}</div>{sub&&<div style={{fontSize:10,color:T.m2,marginTop:2}}>{sub}</div>}</div>
    {right&&<div style={{display:'flex',gap:6,alignItems:'center'}}>{right}</div>}
  </div>
);
export const Btn = ({children,v='ghost',onClick,sm}) => {
  const M={
    primary:{background:T.y2,color:'#fff',border:'none',boxShadow:'0 1px 4px rgba(109,40,217,.3)'},
    teal:   {background:T.sDim,color:T.sem,border:`1px solid ${T.sem}40`},
    accept: {background:T.gDim,color:T.green,border:`1px solid ${T.green}40`},
    danger: {background:T.rDim,color:T.red,border:`1px solid ${T.red}40`},
    amber:  {background:T.pDim,color:T.pdm,border:`1px solid ${T.pdm}40`},
    blue:   {background:T.ptDim,color:T.parts,border:`1px solid ${T.parts}40`},
    ghost:  {background:T.s2,color:T.m2,border:`1px solid ${T.border}`},
  };
  return <button onClick={onClick} style={{...(M[v]||M.ghost),fontSize:sm?10:11,fontWeight:700,padding:sm?'4px 9px':'6px 12px',borderRadius:7,cursor:'pointer',transition:'all 0.15s'}}>{children}</button>;
};
export const HR = ({value,size=52}) => {
  const col=hc(value),r=(size-8)/2,circ=2*Math.PI*r,dash=(value/100)*circ;
  return (<svg width={size} height={size} style={{flexShrink:0}}>
    <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={T.border} strokeWidth={5}/>
    <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={col} strokeWidth={5}
      strokeDasharray={`${dash} ${circ-dash}`} strokeLinecap="round" transform={`rotate(-90 ${size/2} ${size/2})`}/>
    <text x={size/2} y={size/2+4} textAnchor="middle" fill={col} fontSize={11} fontWeight={800}>{value}</text>
  </svg>);
};
export const MTag = ({text,color=T.oee}) => (
  <span style={{fontFamily:'monospace',fontSize:11,color,background:color+'12',border:`1px solid ${color}30`,padding:'2px 7px',borderRadius:4,whiteSpace:'nowrap',fontWeight:600}}>{text}</span>
);
export const OeeGauge = ({value,size=88,target=85}) => {
  const col=value>=target?T.green:value>=target-10?T.amber:T.red;
  const r=size/2-7,circ=2*Math.PI*r,arc=(value/100)*circ*0.75;
  return (<svg width={size} height={size*0.75} viewBox={`0 0 ${size} ${size*0.75}`} style={{overflow:'visible'}}>
    <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={T.border} strokeWidth={6} strokeDasharray={`${circ*0.75} ${circ*0.25}`} strokeLinecap="round" transform={`rotate(135 ${size/2} ${size/2})`}/>
    <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={col} strokeWidth={6} strokeDasharray={`${arc} ${circ-arc}`} strokeLinecap="round" transform={`rotate(135 ${size/2} ${size/2})`}/>
    <text x={size/2} y={size/2+4}  textAnchor="middle" fill={col} fontSize={size*0.19} fontWeight={800}>{value}%</text>
    <text x={size/2} y={size/2+14} textAnchor="middle" fill={T.m2}  fontSize={size*0.1}>OEE</text>
  </svg>);
};
export const FeatBar = ({label,pct,col}) => (
  <div style={{marginBottom:10}}>
    <div style={{display:'flex',justifyContent:'space-between',fontSize:11,marginBottom:4}}>
      <span style={{fontWeight:600,color:T.txt}}>{label}</span><span style={{color:col||T.yield,fontWeight:700}}>{pct}%</span>
    </div>
    <div style={{height:6,background:T.s3,borderRadius:3}}><div style={{height:6,width:`${pct}%`,background:col||T.yield,borderRadius:3}}/></div>
  </div>
);
export const LayerBar = ({layers}) => (
  <div style={{display:'flex',gap:0,alignItems:'stretch',marginBottom:14}}>
    {layers.map((l,i)=>(
      <div key={l.label} style={{flex:1,background:l.col+'10',border:`1px solid ${l.col}30`,borderRadius:i===0?'8px 0 0 8px':i===layers.length-1?'0 8px 8px 0':'0',padding:'10px 12px'}}>
        <div style={{fontSize:10,fontWeight:800,color:l.col,marginBottom:4,letterSpacing:'0.4px',textTransform:'uppercase'}}>{l.label}</div>
        {l.items.map(it=><div key={it} style={{fontSize:10,color:T.m2,marginBottom:3}}>· {it}</div>)}
      </div>
    ))}
  </div>
);
export const Divider = ({label,col}) => (
  <div style={{display:'flex',alignItems:'center',gap:8,margin:'6px 0 8px'}}>
    <div style={{height:1,flex:1,background:T.border}}/>
    <span style={{fontSize:9,fontWeight:800,color:col||T.m2,letterSpacing:1.5,textTransform:'uppercase'}}>{label}</span>
    <div style={{height:1,flex:1,background:T.border}}/>
  </div>
);
export const RetBtn = ({phases,col,label}) => {
  const [running,setRunning]=useState(false),[prog,setProg]=useState(0),[phase,setPhase]=useState(''),[done,setDone]=useState(false);
  const start=()=>{
    setRunning(true);setProg(0);setDone(false);setPhase(phases[0]);
    let p=0,pi=0;
    const iv=setInterval(()=>{p+=1.1;if(p>=100){clearInterval(iv);setRunning(false);setProg(100);setDone(true);return;}
      setProg(p);const npi=Math.min(phases.length-1,Math.floor(p/(100/phases.length)));if(npi!==pi){pi=npi;setPhase(phases[npi]);}},90);
  };
  return (running||done)?(
    <div>
      <div style={{display:'flex',justifyContent:'space-between',fontSize:11,marginBottom:5}}>
        <span style={{color:done?T.green:col}}>{done?`✓ ${label||'Deployed'}`:phase}</span>
        <span style={{fontWeight:700,color:done?T.green:col}}>{Math.round(prog)}%</span>
      </div>
      <div style={{height:8,background:T.s3,borderRadius:4}}><div style={{height:8,width:`${prog}%`,background:col,borderRadius:4,transition:'width 0.1s'}}/></div>
    </div>
  ):<Btn v="primary" onClick={start}>▶ Start Retraining</Btn>;
};
export const SpecHeader = ({quarter,title,tags,target,accentCol}) => (
  <div style={{background:T.surface,borderBottom:`1px solid ${T.border}`,padding:'10px 18px',flexShrink:0,borderTop:`3px solid ${accentCol}`}}>
    <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}>
      <span style={{fontSize:11,fontWeight:800,color:accentCol,letterSpacing:1}}>{quarter}</span>
      <span style={{fontSize:14,fontWeight:800,color:T.txt}}>{title}</span>
      {tags.map(t=><Bdg key={t} label={t} color={accentCol}/>)}
      <span style={{marginLeft:'auto'}}><Bdg label={target} color={T.sem}/></span>
    </div>
  </div>
);
export const TabBar = ({tabs,active,onSelect,col}) => (
  <div style={{display:'flex',background:T.s2,borderBottom:`1px solid ${T.border}`,padding:'0 18px',overflowX:'auto'}}>
    {tabs.map(([id,label])=>(
      <div key={id} onClick={()=>onSelect(id)} style={{padding:'9px 14px',fontSize:11,fontWeight:700,cursor:'pointer',color:active===id?col:T.m2,borderBottom:`2px solid ${active===id?col:'transparent'}`,background:'transparent',transition:'all 0.15s',whiteSpace:'nowrap'}}>{label}</div>
    ))}
  </div>
);
