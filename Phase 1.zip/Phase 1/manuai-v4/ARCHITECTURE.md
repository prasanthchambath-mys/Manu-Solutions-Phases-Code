
# ManuAI v4 — Architecture & Roadmap
## Current State → Target State by Phase

---

# CURRENT ARCHITECTURE (As Built Today)

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER'S BROWSER                           │
│                   React Frontend (Vite)                         │
│         9 Agent Dashboards + WebSocket live updates             │
└─────────────────────────┬───────────────────────────────────────┘
                          │ HTTP + WebSocket
┌─────────────────────────▼───────────────────────────────────────┐
│                    NODE.JS API (Express)                        │
│                                                                 │
│  ┌─────────────┐  ┌──────────────┐  ┌───────────────────────┐  │
│  │  9 Route    │  │  Semantic    │  │   Simulation Engine   │  │
│  │  Handlers   │  │  Layer       │  │   (runs every 4s)     │  │
│  │  OEE/PdM/   │  │  Cross-agent │  │   Degrades machines   │  │
│  │  Yield etc  │  │  conflict    │  │   Fires events        │  │
│  └──────┬──────┘  │  rules       │  │   Cycles batches      │  │
│         │         └──────────────┘  └───────────────────────┘  │
│  ┌──────▼──────────────────────────────────────────────────┐    │
│  │              CONNECTOR LAYER                            │    │
│  │  PI Historian │ SAP OData │ IoT Hub │ LIMS │ OPC-UA     │    │
│  │  (all in MOCK mode — reading from CSV files)            │    │
│  └──────────────────────────────────────────────────────┘  │    │
│                                                             │    │
│  ┌──────────────────────────────────────────────────────┐  │    │
│  │              CSV DATA LOADER                         │  │    │
│  │  data/csv/machines.csv                               │  │    │
│  │  data/csv/yield_params.csv  (14 CSV files total)     │  │    │
│  │  data/csv/supply_risks.csv  etc.                     │  │    │
│  └──────────────────────────────────────────────────────┘  │    │
└─────────────────────────┬───────────────────────────────────────┘
                          │ HTTP
┌─────────────────────────▼───────────────────────────────────────┐
│              7 PYTHON MICROSERVICES (FastAPI)                   │
│                                                                 │
│  PdM Inference  │  Yield Optimiser  │  Energy Optimiser        │
│  Quality Vision │  Supply Intel     │  Digital Twin Sync       │
│  Safety Monitor                                                 │
│                                                                 │
│  ALL running rule-based logic (no real ML models)              │
│  ALL in mock mode                                               │
└─────────────────────────────────────────────────────────────────┘

INFRASTRUCTURE TODAY:
┌─────────────────────────────────────────┐
│  Your Laptop / Linux Server             │
│  Docker Compose (10 containers)         │
│  Redis (in-memory only, no persistence) │
│  NO DATABASE                            │
│  NO HTTPS                               │
│  NO REAL LOGIN                          │
└─────────────────────────────────────────┘

DATA FLOW TODAY:
CSV Files → Memory → Synthetic Engine → API → Browser
Everything resets on restart. Nothing stored. No history.
```

---

# PHASE 1 — DEMO READY
## "Show customers a convincing live platform"

### What changes
- Add SQLite database
- Generate 30 days of historical data
- Add HTTPS via Let's Encrypt
- Add Google OAuth login
- Add audit trail
- Smarter rule engine explanations

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER'S BROWSER                           │
│              React Frontend + Google Login button               │
│         Trends, History, 30-day charts now visible              │
└─────────────────────────┬───────────────────────────────────────┘
                          │ HTTPS + WebSocket
┌─────────────────────────▼───────────────────────────────────────┐
│                    NODE.JS API                                  │
│                                                                 │
│  Same 9 routes BUT now reading from SQLite                      │
│  Simulation engine writes every tick to SQLite                  │
│  Google OAuth validates every request                           │
│  Every action written to audit log                              │
└──────────┬──────────────────────────────────┬───────────────────┘
           │                                  │
┌──────────▼──────────┐          ┌────────────▼────────────────┐
│   SQLite Database   │          │  7 Python Services          │
│   manuai.db         │          │  (same rule engines)        │
│                     │          │  Now return reasoning       │
│   oee_readings      │          │  not just scores            │
│   alerts            │          └─────────────────────────────┘
│   batches           │
│   yield_history     │
│   energy_readings   │
│   audit_log         │
└─────────────────────┘

INFRASTRUCTURE:
┌─────────────────────────────────────────┐
│  Linux Server from IT                   │
│  Docker Compose (same 10 containers)    │
│  Redis (unchanged)                      │
│  SQLite file (new — single file)        │
│  Let's Encrypt SSL (free)               │
│  Google OAuth (free)                    │
└─────────────────────────────────────────┘
```

### Effort and Cost

| Item | Effort | Cost |
|---|---|---|
| SQLite + historical generator | 3 days | Free |
| Google OAuth login | 1 day | Free |
| HTTPS / Let's Encrypt | 2 hours | Free |
| Audit trail | 1 day | Free |
| Smarter rule explanations | 2 days | Free |
| **Total** | **~8 days** | **Free** |

### What customer sees
- 30 days of OEE trends per machine
- Batch yield history and comparisons
- Who logged in, who acknowledged what alert
- Secure HTTPS URL
- Proper login screen

---

# PHASE 2 — PILOT READY
## "One real customer, real data, limited scope"

### What changes
- Connect first real source system (SAP or PI — whichever customer has)
- Replace SQLite with PostgreSQL (handles concurrent users)
- Basic monitoring and alerting
- Connection test screen
- UptimeRobot monitoring

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER'S BROWSER                           │
│         Same frontend + connection status indicator             │
└─────────────────────────┬───────────────────────────────────────┘
                          │ HTTPS
┌─────────────────────────▼───────────────────────────────────────┐
│                    NODE.JS API                                  │
│                                                                 │
│  Connector layer now LIVE for 1-2 systems                       │
│  Others still on CSV/mock                                       │
│  PostgreSQL replacing SQLite                                    │
└──────────┬──────────────────────────────────┬───────────────────┘
           │                                  │
┌──────────▼──────────┐          ┌────────────▼────────────────┐
│   PostgreSQL        │          │  REAL DATA SOURCES          │
│   (same tables      │          │                             │
│    as SQLite)       │          │  SAP OData (live)           │
│                     │          │  OR                         │
│   Now handles       │          │  PI Historian (live)        │
│   concurrent users  │          │                             │
│   Proper backups    │          │  Others still CSV/mock      │
└─────────────────────┘          └─────────────────────────────┘

INFRASTRUCTURE:
┌─────────────────────────────────────────┐
│  Linux Server from IT (same)            │
│  OR moved to Azure Container Apps       │
│  PostgreSQL container added             │
│  UptimeRobot monitoring (free)          │
└─────────────────────────────────────────┘
```

### Effort and Cost

| Item | Effort | Cost |
|---|---|---|
| SQLite → PostgreSQL migration | 1 day | Free (self-hosted) |
| First real connector testing (SAP or PI) | 2–3 weeks | Free |
| UptimeRobot monitoring | 30 min | Free |
| Connection test screen | 1 day | Free |
| Basic error alerting | 1 day | Free |
| IT coordination for credentials | 1–2 weeks | — |
| **Total development** | **~6 weeks** | **Free if Linux server** |
| **If moving to Azure** | **+1 week** | **~₹1,500/month** |

### What customer sees
- Real SAP production orders appearing
- OR real machine OEE from PI tags
- Historical trends growing daily with real data
- Platform stays up 24/7

---

# PHASE 3 — PRODUCTION READY (SINGLE PLANT)
## "Full plant, all sources connected, trusted by operators"

### What changes
- All source systems connected and tested
- Azure AD enterprise login
- IoT Hub for real sensor streaming
- Real ML models for PdM and Yield (requires historical data collected in Phase 2)
- Full monitoring stack
- Move to Azure

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER'S BROWSER                           │
│         Azure AD login (company email)                          │
└─────────────────────────┬───────────────────────────────────────┘
                          │ HTTPS
┌─────────────────────────▼───────────────────────────────────────┐
│              AZURE CONTAINER APPS                               │
│                                                                 │
│  Node.js API  │  7 Python Services (now with real ML models)   │
└───┬───────────────────────────────────────────┬────────────────┘
    │                                           │
┌───▼───────────┐    ┌───────────────────────── ▼──────────────┐
│ Azure Cache   │    │       REAL SOURCE SYSTEMS               │
│ for Redis     │    │                                         │
│               │    │  PI Historian    → OEE, sensor readings │
│ Azure SQL     │    │  SAP PP/MM/PM/QM → orders, WOs, PRs     │
│ Database      │    │  Azure IoT Hub   → live sensor stream   │
│               │    │  LIMS            → lab results          │
│ Azure Blob    │    │  OPC-UA / MES    → set-point writes     │
│ (image store) │    │  Azure ML        → PdM + Yield models   │
└───────────────┘    │  Azure Dig Twins → plant model sync     │
                     └─────────────────────────────────────────┘

MONITORING:
┌─────────────────────────────────────────┐
│  Azure Monitor                          │
│  Application Insights                  │
│  Alert rules → email/Teams             │
└─────────────────────────────────────────┘
```

### Effort and Cost

| Item | Effort | Cost/month |
|---|---|---|
| Azure Container Apps | 1 week migration | ~₹1,000 |
| Azure Cache for Redis | 1 day | ~₹1,100 |
| Azure SQL Database | 1 day migration from PostgreSQL | ~₹1,500 |
| Azure Container Registry | 1 day | ~₹135 |
| Azure IoT Hub (S1) | 2–3 weeks + OT team | ~₹1,400 |
| Azure AD integration | 2 weeks | Free up to 50k users |
| Real ML models (PdM + Yield) | 8–12 weeks data science | ~₹2,000 (AML) |
| All connector testing | 2–3 weeks per system | — |
| Azure Monitor | 1 day | ~₹500 |
| Azure Digital Twins | 3–4 weeks | ~₹500 |
| **Total development** | **~6–9 months** | **~₹8,000–10,000/month** |

---

# PHASE 4 — ENTERPRISE (MULTI-PLANT)
## "Multiple customers, multiple plants, SLA guaranteed"

### What changes
- Multi-tenancy (each customer sees only their plant)
- Each customer gets isolated database
- White-labelling option
- 99.9% uptime SLA
- Disaster recovery
- Compliance and security audit

```
┌──────────────────────────────────────────────────────────────┐
│                    AZURE FRONT DOOR                          │
│              (routes traffic to right plant)                 │
└──────┬────────────────────────┬────────────────────┬─────────┘
       │                        │                    │
┌──────▼──────┐          ┌──────▼──────┐     ┌──────▼──────┐
│  Customer A │          │  Customer B │     │  Customer C │
│  Plant 1    │          │  Plant 1    │     │  Plant 1    │
│  Container  │          │  Container  │     │  Container  │
│  Apps env   │          │  Apps env   │     │  Apps env   │
│             │          │             │     │             │
│  Azure SQL  │          │  Azure SQL  │     │  Azure SQL  │
│  (isolated) │          │  (isolated) │     │  (isolated) │
└─────────────┘          └─────────────┘     └─────────────┘

SHARED SERVICES:
┌──────────────────────────────────────────┐
│  Azure AD B2C (all customers login here) │
│  Azure Monitor (centralised)             │
│  Azure Container Registry (shared)       │
│  Azure ML (shared models)                │
└──────────────────────────────────────────┘
```

### Effort and Cost

| Item | Effort | Cost/month |
|---|---|---|
| Multi-tenancy architecture | 4–6 weeks | — |
| Azure Front Door | 1 week | ~₹1,500 |
| Per-customer isolation | 2–3 weeks | ~₹8,000–10,000 per customer |
| Security audit | 4–6 weeks external | One-time ₹5–10 lakh |
| SLA and DR setup | 2–3 weeks | ~₹3,000 |
| **Total development** | **4–6 months** | **Scales with customers** |

---

# SUMMARY — ALL PHASES

```
PHASE       WHAT IT IS           DURATION    COST/MONTH    KEY MILESTONE
─────────────────────────────────────────────────────────────────────────
Current     Demo scaffold        Done        Free          Platform exists

Phase 1     Demo ready           8 days      Free          Win first meeting
            SQLite + login
            30 day history

Phase 2     Pilot ready          6 weeks     Free–₹1,500   First paying pilot
            Real data (1 system)
            PostgreSQL

Phase 3     Single plant prod    6–9 months  ₹8,000–10,000 Production contract
            All systems live
            Real ML models
            Azure hosted

Phase 4     Multi-plant SaaS     4–6 months  Per customer  Scale the business
            Enterprise grade     additional
```

---

# THE CODE GAP ANALYSIS

```
WHAT IS BUILT AND READY          WHAT NEEDS BUILDING
──────────────────────────────   ──────────────────────────────────
✅ All 9 agent UIs               ❌ Database (SQLite → PostgreSQL)
✅ All 7 Python services         ❌ Historical data generator
✅ All 5 connectors (mock mode)  ❌ Real login (Google OAuth → Azure AD)
✅ Semantic layer                ❌ HTTPS configuration
✅ WebSocket live updates        ❌ Audit trail
✅ Synthetic data engine         ❌ Real ML models (needs plant data)
✅ CSV data layer                ❌ Multi-tenancy
✅ Docker + deployment scripts   ❌ Monitoring stack
✅ Mock-to-live swap pattern     ❌ Historical trend API endpoints
✅ Cross-agent events            ❌ Load testing
```

---

# WHAT TO DO RIGHT NOW

Given where you are — **build Phase 1 first.**

8 days of work, zero cost, transforms the platform from
a moving demo into something a customer would trust enough
to agree to a pilot.

Priority order:
1. SQLite + 30 day historical data generator  (3 days)
2. HTTPS on Linux server                      (2 hours)
3. Google OAuth login                         (1 day)
4. Audit trail                                (1 day)
5. Smarter rule engine explanations           (2 days)

After Phase 1 — go demo to customers.
Use pilot revenue to fund Phase 2 and 3.
