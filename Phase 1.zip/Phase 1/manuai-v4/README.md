# ManuAI — Unified Manufacturing Intelligence Platform v4.0

9 AI Agents | Azure + On-Premise | React + Node.js + FastAPI

---

## Quick Start (3 minutes)

```bash
# 1. Install dependencies
npm install --prefix apps/api
npm install --prefix apps/web

# 2. Configure environment
cp .env.example .env.local
# VITE_MOCK_DATA=true is already set — runs without real PI/SAP

# 3a. Start with Docker Compose (recommended)
docker compose up --build
# Frontend → http://localhost:5173
# API      → http://localhost:4000
# Redis    → localhost:6379

# 3b. Or start manually (two terminals)
npm run dev --prefix apps/api    # Terminal 1
npm run dev --prefix apps/web    # Terminal 2
```

---

## Project Structure

```
manuai-v4/
├── apps/
│   ├── api/src/
│   │   ├── index.ts                 Express + Socket.io server
│   │   ├── connectors/
│   │   │   ├── pi-historian.ts      OSIsoft PI Web API
│   │   │   ├── sap-odata.ts         SAP PP / MM / PM / QM (OAuth2)
│   │   │   ├── iot-hub.ts           Azure IoT Hub event stream
│   │   │   ├── opc-ua.ts            OPC-UA DCS set-point writes
│   │   │   └── lims.ts              LIMS REST API
│   │   ├── semantic/service.ts      KPI governance + conflict rules
│   │   ├── ai/anthropic.ts          Anthropic API (chat + per-agent)
│   │   ├── websocket/broadcaster.ts Socket.io live push
│   │   ├── middleware/auth.ts        Azure AD JWT + RBAC
│   │   └── routes/
│   │       ├── oee.ts               OEE Visibility Agent
│   │       ├── yield.ts             Yield Optimisation Agent
│   │       ├── all-routes.ts        PdM, Quality, Energy, Supply,
│   │       │                        Twin, Safety, Semantic, AI routes
│   │       └── health.ts            /api/health
│   └── web/src/
│       ├── App.tsx                  Full 9-agent UI (1,742 lines)
│       ├── api.ts                   Typed API + WebSocket client
│       ├── store/index.ts           Zustand state management
│       ├── hooks/index.ts           useLiveOEE, useAsync
│       ├── components/ui.tsx        Shared UI components
│       ├── tokens.ts                White-theme design tokens
│       └── mockData.ts              Dev mock data (used when VITE_MOCK_DATA=true)
├── services/
│   ├── pdm-inference/main.py        FastAPI: failure prediction + RUL
│   ├── yield-optimizer/main.py      FastAPI: XGBoost DCS recommendations
│   ├── quality-vision/main.py       FastAPI: ONNX defect model management
│   ├── energy-optimizer/main.py     FastAPI: load dispatch engine
│   ├── supply-intelligence/main.py  FastAPI: shortfall prediction
│   ├── twin-sync/main.py            FastAPI: ADT divergence detection
│   └── safety-monitor/main.py       FastAPI: LSTM precursor detection
├── infra/docker/
│   ├── Dockerfile.api               Multi-stage Node.js API build
│   ├── Dockerfile.web               Vite dev server
│   └── Dockerfile.python            Python FastAPI services
├── .github/workflows/ci.yml         CI: lint → build → staging → prod
├── docker-compose.yml               Full local dev stack
├── .env.example                     All 30+ env vars documented
└── README.md
```

---

## Source System Wiring

Each connector reads from your existing infrastructure. No source systems need to change.

| File | Source System | Protocol | Agents |
|---|---|---|---|
| `connectors/pi-historian.ts` | OSIsoft PI historian | PI Web API (REST/HTTPS) | Yield, Energy, PdM, Twin |
| `connectors/sap-odata.ts` | SAP PP/MM/PM/QM | OData v4 (OAuth2) | Yield, PdM, Parts, Quality, Supply |
| `connectors/iot-hub.ts` | Azure IoT Hub | MQTT / Event Hubs | PdM, Safety |
| `connectors/opc-ua.ts` | AVEVA MES / SCADA | OPC-UA TCP | OEE (read), Yield & Energy (write) |
| `connectors/lims.ts` | LabVantage / STARLIMS | REST API | Yield, Quality |

**Write-back operations** (all require engineer role + Semantic Layer conflict check):
- Yield: DCS set-point via OPC-UA → `POST /api/yield/dcs-write`
- PdM: SAP PM work order → `POST /api/pdm/workorders`
- Parts: SAP MM purchase requisition → `POST /api/pdm/parts-order`
- Energy: SCADA load dispatch → `POST /api/energy/dispatch`
- Quality: SAP QM non-conformance → auto via Quality Vision agent

---

## Adding a Real PI Tag (Example)

1. Open `apps/api/src/routes/yield.ts`
2. Find the `PARAMS` array
3. Update `piTag` to match the full PI tag path from PI System Explorer
4. Update `nodeId` to the OPC-UA node ID of the corresponding set-point
5. Restart the API — the Semantic Layer automatically governs the new tag

```typescript
{ id: 'TIC-101', name: 'Reactor Temp',
  piTag: 'YourSite.YourUnit.TIC101.PV',     // ← your actual PI tag path
  nodeId: 'ns=2;s=TIC101_SP',               // ← your OPC-UA set-point node
  unit: '°C', min: 160, max: 200, target: 186 },
```

---

## Switching from Mock to Live Data

1. Set `VITE_MOCK_DATA=false` and `MOCK_AUTH=false` in `.env.local`
2. Configure `PI_*`, `SAP_*`, `IOT_HUB_*`, `LIMS_*` environment variables
3. In each route file, remove the `MOCK_*` constant fallbacks — the connector will be called directly
4. Each route has a `// TODO: replace with real connector call` comment marking the swap point

---

## Environment Variables (key ones)

| Variable | Purpose |
|---|---|
| `MOCK_AUTH=true` | Skip JWT validation in dev |
| `VITE_MOCK_DATA=true` | Use mock data in frontend (no real PI/SAP needed) |
| `PI_WEB_API_URL` | e.g. `https://pi-server.plant.local/piwebapi` |
| `SAP_ODATA_BASE_URL` | e.g. `https://sap-gateway.plant.local:8080/sap/opu/odata/sap` |
| `IOT_HUB_CONNECTION_STRING` | Azure IoT Hub connection string |
| `ANTHROPIC_API_KEY` | Your Anthropic API key |
| `REDIS_URL` | e.g. `redis://localhost:6379` |

See `.env.example` for the complete list with descriptions.

---

## RBAC Roles

| Role | Can do |
|---|---|
| `operator` | Read all dashboards |
| `supervisor` | + Acknowledge OEE alerts |
| `maintenance` | + Create SAP PM work orders, approve PTWs |
| `engineer` | + Write DCS set-points, dispatch energy loads |
| `executive` | Read-only all agents + export reports |
| `admin` | Everything |

Set `MOCK_AUTH=true` in dev — all requests run as `admin`.
