import { loadTwinComponents,
 twinRouter } from './all-routes';
export default twinRouter;

router.get('/components', (_req, res) => {
  res.json({ components: loadTwinComponents() });
});

router.get('/scenarios', (_req, res) => {
  res.json({ scenarios: loadTwinScenarios() });
});

router.get('/divergence', (_req, res) => {
  // Build divergence from twin_kpis.csv
  const kpis = loadTwinKPIs ? loadTwinKPIs() : [];
  const divergence = (kpis as any[])
    .filter((k: any) => k.diverging)
    .map((k: any) => ({
      kpi: k.name,
      actual: k.actual,
      twin: k.predicted,
      delta: ((k.actual - k.predicted) >= 0 ? '+' : '') + (k.actual - k.predicted).toFixed(2),
      status: k.diverging ? 'diverging' : 'aligned',
      time: 'live',
    }));
  res.json({ data: divergence });
});
