import { pdmRouter } from './all-routes';
export default pdmRouter;

router.get('/parts', (_req, res) => {
  const { orders, inventory } = loadParts();
  res.json({ orders, inventory });
});

router.get('/rules', (_req, res) => {
  res.json({ rules: loadPdmRules() });
});
