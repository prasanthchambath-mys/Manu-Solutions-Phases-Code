import { Router } from 'express';
import { getPlantState } from '../simulation/engine';
import { getTagsBatch } from '../connectors/pi-historian';
import { semanticLayer } from '../semantic/service';
import { logger } from '../middleware/logger';
import { loadMachines } from '../data/csv-loader';

const router = Router();

// getMachineTags() built from machines.csv — pi_tag column
// REPLACE WITH: PI Web API tag registry in Phase 3
function getMachineTags(): Record<string, { avail: string; perf: string; qual: string }> {
  const machines = loadMachines();
  const result: Record<string, { avail: string; perf: string; qual: string }> = {};
  for (const m of machines) {
    const line = (m.line ?? 'LineA').replace(/\s/g, '');
    const id   = m.id.replace('-', '');
    result[m.id] = {
      avail: `Plant.${line}.${id}.Availability`,
      perf:  `Plant.${line}.${id}.Performance`,
      qual:  `Plant.${line}.${id}.Quality`,
    };
  }
  return result;


router.get('/live', async (_req, res) => {
  try {
    const allTags = Object.values(getMachineTags()).flatMap(t => [t.avail, t.perf, t.qual]);
    const piValues = await getTagsBatch(allTags).catch(() => ({}));
    const state = getPlantState();

    const machines = state.machines.map(m => {
      const tags = getMachineTags()[m.id];
      if (tags && Object.keys(piValues).length > 0) {
        const avail = piValues[tags.avail] ?? m.avail;
        const perf  = piValues[tags.perf]  ?? m.perf;
        const qual  = piValues[tags.qual]  ?? m.qual;
        return { ...m, avail:+avail.toFixed(1), perf:+perf.toFixed(1), qual:+qual.toFixed(1),
                 oee:+(avail * perf * qual / 10000).toFixed(1) };
      }
      return m;
    });

    res.json({ machines, plantOEE: state.plantOEE, timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error('OEE live error', { error: String(err) });
    const state = getPlantState();
    res.json({ machines: state.machines, plantOEE: state.plantOEE, timestamp: new Date().toISOString() });
  }
});

router.get('/losses', (_req, res) => {
  const state = getPlantState();
  const machines = state.machines;
  const breakdowns = machines.filter(m => m.loss === 'Unplanned Breakdown');
  const speedLoss  = machines.filter(m => m.loss === 'Speed Loss');
  const minorStops = machines.filter(m => m.loss === 'Minor Stops');
  const totalMin   = machines.reduce((a,m)=>a+m.lossMin,0);

  const losses = [
    { name:'Unplanned Breakdown', min:breakdowns.reduce((a,m)=>a+m.lossMin,0), pct:0, cnt:breakdowns.length, machines:breakdowns.map(m=>m.id) },
    { name:'Speed Loss',          min:speedLoss.reduce((a,m)=>a+m.lossMin,0),  pct:0, cnt:speedLoss.length,  machines:speedLoss.map(m=>m.id)  },
    { name:'Minor Stops',         min:minorStops.reduce((a,m)=>a+m.lossMin,0), pct:0, cnt:minorStops.length, machines:minorStops.map(m=>m.id) },
    { name:'Changeover & Setup',  min:Math.floor(totalMin*0.15), pct:0, cnt:8,  machines:machines.filter(m=>m.status==='caution').map(m=>m.id) },
    { name:'Startup Defects',     min:Math.floor(totalMin*0.05), pct:0, cnt:3,  machines:machines.filter(m=>m.status==='good').slice(0,1).map(m=>m.id) },
    { name:'In-process Defects',  min:Math.floor(totalMin*0.04), pct:0, cnt:4,  machines:machines.filter(m=>m.status==='critical').slice(0,1).map(m=>m.id) },
  ].map(l => ({ ...l, pct:totalMin>0 ? +(l.min/totalMin*100).toFixed(1) : 0 }));

  res.json({ losses, totalMinutes: totalMin, date: new Date().toISOString().split('T')[0] });
});

router.get('/alerts', (_req, res) => {
  const state = getPlantState();
  const alerts = state.machines
    .filter(m => m.status === 'critical' || m.status === 'warning')
    .map(m => ({
      id: `ALT-${m.id}`, sev: m.status === 'critical' ? 'critical' : 'warning',
      type: m.loss, machine: m.id, line: m.line,
      ts: new Date().toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' }),
      ack: false,
      msg: `${m.name}: ${m.loss}. OEE ${m.oee}%, Health ${m.health.toFixed(0)}%, Vib ${m.vib} mm/s, Temp ${m.temp}°C. RUL: ${m.rul.toFixed(0)}d.`,
      routed: m.status === 'critical' ? 'Maintenance team notified' : 'Supervisor notified',
    }));
  res.json({ alerts });
});

router.post('/alerts/:id/ack', (req, res) => {
  logger.info('Alert acked', { id: req.params.id, user: req.user?.name });
  res.json({ success: true, alertId: req.params.id, ackedBy: req.user?.name, at: new Date().toISOString() });
});

export default router;
