import { Router } from 'express';
import { getPlantState } from '../simulation/engine';
import { loadWorkOrders, loadQualityDefects, loadQualityLines, loadSupplyRisks, loadTwinKPIs, loadSafetyPermits, loadProductionOrders, loadSafetyZones, loadTechnicians, loadMachines, loadUtilities, loadEnergyAssets, loadEnergyWaste, loadEnergyDispatch } from '../data/csv-loader';
// Legacy import cleaned:
} from '../data/csv-loader';
import { createMaintenanceNotification, createPurchaseRequisition } from '../connectors/sap-odata';
import { getHistory, getLatest } from '../connectors/iot-hub';
import { semanticLayer } from '../semantic/service';
import { requireRole, ROLES } from '../middleware/auth';
import { unifiedChat, agentRecommendation, semanticQuery } from '../ai/anthropic';
import { logger } from '../middleware/logger';
import { z } from 'zod';

// ══════════════════════════════════════════════════════════════
// PdM Agent
// ══════════════════════════════════════════════════════════════
export const pdmRouter = Router();

pdmRouter.get('/assets', (_req, res) => {
  const state = getPlantState();
  const assets = state.machines.map(m => ({
    id: m.id, name: m.name, health: Math.round(m.health), rul: Math.round(m.rul),
    status: m.status, vib: m.vib, temp: m.temp,
  }));
  const utilityAssets = state.utilities.map(u => ({
    id: u.id, name: u.name, health: Math.round(u.health), rul: Math.round(u.rul),
    status: u.status, oeeLink: u.oeeLink,
  }));
  res.json({ assets, utilityAssets });
});

pdmRouter.get('/sensors/:assetId', (req, res) => {
  const { assetId } = req.params;
  res.json({
    assetId,
    vibration: { latest: getLatest(assetId, 'vibration'), history: getHistory(assetId, 'vibration', 24) },
    temperature: { latest: getLatest(assetId, 'temperature'), history: getHistory(assetId, 'temperature', 24) },
  });
});

pdmRouter.get('/workorders', async (_req, res) => res.json({ orders: loadWorkOrders() }));

pdmRouter.post('/workorders', requireRole(ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { equipment, description, priority } = req.body as { equipment: string; description: string; priority?: string };
  try {
    const wo = await createMaintenanceNotification({ equipment, text: description, priority });
    await semanticLayer.publishEvent({ id: `WO-${Date.now()}`, from: 'pdm', to: 'oee', type: 'work_order_created', sev: 'info', msg: `WO ${wo.MaintenanceNotification}: ${description}`, impact: 'Maintenance scheduled', asset: equipment, ts: new Date().toISOString() });
    res.json({ success: true, workOrderId: wo.MaintenanceNotification });
  } catch { res.status(502).json({ error: 'SAP PM unavailable' }); }
});

pdmRouter.post('/parts-order', requireRole(ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { material, quantity, assetId, reason } = req.body as { material: string; quantity: number; assetId: string; reason: string };
  try {
    const pr = await createPurchaseRequisition({ material, plant: process.env.SAP_PLANT_CODE!, quantity, text: `[ManuAI PdM] ${assetId}: ${reason}`, deliveryDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0] });
    res.json({ success: true, prId: pr.PurchaseRequisition });
  } catch { res.status(502).json({ error: 'SAP MM unavailable' }); }
});

// PDM assets, utilities and work orders — all from CSV files
// REPLACE WITH: IoT Hub + SAP PM in Phase 3
const getPdmAssets = () => loadMachines();
const getUtilAssets = () => loadUtilities();
const getPdmWorkorders = () => loadWorkOrders();

// ══════════════════════════════════════════════════════════════
// Quality Vision Agent
// ══════════════════════════════════════════════════════════════
export const qualityRouter = Router();

qualityRouter.get('/defects', (_req, res) => {
  const defects = loadQualityDefects();
  const major = defects.filter(d => d.severity === 'major').length;
  const minor = defects.filter(d => d.severity === 'minor').length;
  res.json({ defects, summary: { total: defects.length, major, minor } });
});
qualityRouter.get('/lines', (_req, res) => res.json({ lines: loadQualityLines() }));

// Quality defects and lines — from CSV files (REPLACE WITH Vision AI + MES in Phase 3)
const getQualityDefects = () => loadQualityDefects();
const getQualityLines   = () => loadQualityLines();

// ══════════════════════════════════════════════════════════════
// Energy Optimisation Agent
// ══════════════════════════════════════════════════════════════
export const energyRouter = Router();

energyRouter.get('/load', (_req, res) => {
  const state = getPlantState();
  res.json({ trend: state.energyTrend, assets: state.energyAssets, waste: getEnergyWasteList(), totalKw: state.energyKw });
});

energyRouter.post('/dispatch', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { assetId, action } = req.body as { assetId: string; action: string };
  logger.info('Energy dispatch', { assetId, action, user: req.user?.name });
  res.json({ success: true, assetId, action, dispatchedAt: new Date().toISOString() });
});

// Energy assets and waste — from CSV files (REPLACE WITH smart meters + IoT Hub in Phase 3)
const getEnergyAssetsList = () => loadEnergyAssets();
const getEnergyWasteList  = () => loadEnergyWaste();

// ══════════════════════════════════════════════════════════════
// Supply Chain Resilience Agent
// ══════════════════════════════════════════════════════════════
export const supplyRouter = Router();

supplyRouter.get('/risks', (_req, res) => res.json({ risks: loadSupplyRisks() }));
supplyRouter.get('/forecast', (_req, res) => res.json({ forecast: loadDemandForecast() }));

supplyRouter.post('/reorder', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { material, quantity } = req.body as { material: string; quantity: number };
  try {
    const pr = await createPurchaseRequisition({ material, plant: process.env.SAP_PLANT_CODE!, quantity, text: '[ManuAI Supply] Risk-triggered reorder', deliveryDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0] });
    res.json({ success: true, prId: pr.PurchaseRequisition });
  } catch { res.status(502).json({ error: 'SAP MM unavailable' }); }
});

// SUPPLY_RISKS loaded from supply_risks.csv — no hardcoded suppliers
const SUPPLY_RISKS = loadSupplyRisks().map((r: any) => ({
  supplier:  r.supplier_name,
  sku:       r.sku,
  risk:      Number(r.current_stock_days??30) < 14 ? 'critical' : Number(r.current_stock_days??30) < 30 ? 'high' : 'medium',
  reason:    Number(r.financial_risk_score??0) > 6 ? 'Financial distress flag' : r.single_source === 'true' ? 'Single source' : 'Lead time drift',
  leadDrift: Number(r.lead_time_actual_days??0) - Number(r.lead_time_contracted_days??0),
  exposure:  r.monthly_consumption ? 'Rs '+(Number(r.monthly_consumption)*Number(r.unit_cost_inr??0)/100000).toFixed(1)+'L' : '—',
  action:    Number(r.current_stock_days??30) < 14 ? 'Alternate source' : 'Monitor',
}));

// ══════════════════════════════════════════════════════════════
// Digital Twin Operations Agent
// ══════════════════════════════════════════════════════════════
export const twinRouter = Router();

twinRouter.get('/status', (_req, res) => {
  const kpis = loadTwinKPIs() as any[];
  const divergingCount = kpis.filter(k => {
    const delta = Math.abs(k.actual - k.twin_predicted);
    const pct = k.twin_predicted !== 0 ? delta / Math.abs(k.twin_predicted) * 100 : 0;
    return pct > k.threshold_pct;
  }).length;
  res.json({ syncedAt: new Date().toISOString(), accuracy: +(100 - divergingCount * 1.2).toFixed(1), diverging: divergingCount, scenarios: loadTwinScenarios().length });
});
twinRouter.get('/divergence', (_req, res) => {
  const kpis = loadTwinKPIs();
  const divergence = kpis.map(k => {
    const delta = k.actual - k.twin_predicted;
    const pct = k.twin_predicted !== 0 ? Math.abs(delta / k.twin_predicted * 100) : 0;
    const status = pct > k.threshold_pct * 2 ? 'critical' : pct > k.threshold_pct ? 'diverging' : 'aligned';
    const sign = delta >= 0 ? '+' : '';
    return { kpi: k.kpi_name, actual: k.actual, twin: k.twin_predicted,
             delta: `${sign}${delta.toFixed(1)}${k.unit === '%' ? '%' : ''}`,
             status, time: 'live' };
  });
  res.json({ divergence });
});
twinRouter.get('/scenarios',  (_req, res) => res.json({ scenarios: loadTwinScenarios() }));

twinRouter.post('/scenarios/:id/run', requireRole(ROLES.ENGINEER, ROLES.ADMIN), (req, res) => {
  logger.info('Twin scenario run', { id: req.params.id, user: req.user?.name });
  res.json({ success: true, scenarioId: req.params.id, status: 'running', estimatedMinutes: 8 });
});

// TWIN_DIVERGENCE removed — served from twin_kpis.csv via /api/twin/divergence
// TWIN_SCENARIOS removed — served from twin_scenarios.csv via /api/twin/scenarios

// ══════════════════════════════════════════════════════════════
// Safety & Compliance Agent
// ══════════════════════════════════════════════════════════════
export const safetyRouter = Router();

safetyRouter.get('/events', (_req, res) => {
  try {
    const db = require('../database/connection').getDb();
    const events = db.prepare('SELECT * FROM safety_events WHERE resolved_at IS NULL ORDER BY ts DESC LIMIT 20').all();
    const openCritical = events.filter((e:any) => e.severity === 'critical').length;
    res.json({ events, openCritical });
  } catch { res.json({ events: [], openCritical: 0 }); }
});
safetyRouter.get('/ptw', (_req, res) => res.json({ permits: loadSafetyPermits() }));

safetyRouter.post('/ptw/:id/approve', requireRole(ROLES.ENGINEER, ROLES.SUPERVISOR, ROLES.ADMIN), (req, res) => {
  logger.info('PTW approval', { id: req.params.id, user: req.user?.name });
  res.json({ success: true, ptwId: req.params.id, approvedBy: req.user?.name, at: new Date().toISOString() });
});

// SAFETY_EVENTS now served from SQLite via /api/history/safety/events
// PTW_LIST now served from safety_permits.csv via /api/safety/permits

// ══════════════════════════════════════════════════════════════
// Semantic Layer Routes
// ══════════════════════════════════════════════════════════════
export const semanticRouter = Router();

semanticRouter.get('/kpis',   (_req, res) => res.json({ kpis: semanticLayer.getKPIDefinitions() }));
semanticRouter.get('/events', async (_req, res) => res.json({ events: await semanticLayer.getRecentEvents(50) }));

// ══════════════════════════════════════════════════════════════
// Unified AI Routes
// ══════════════════════════════════════════════════════════════
export const aiRouter = Router();

const ChatSchema = z.object({
  messages: z.array(z.object({ role: z.enum(['user', 'assistant']), content: z.string() })),
  liveContext: z.string().optional(),
});

aiRouter.post('/chat', async (req, res) => {
  const parsed = ChatSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.issues }); return; }
  try {
    const reply = await unifiedChat(parsed.data.messages, parsed.data.liveContext);
    res.json({ reply });
  } catch { res.status(503).json({ error: 'AI service unavailable' }); }
});

aiRouter.post('/recommend/:agent', async (req, res) => {
  const { context, question } = req.body as { context: string; question: string };
  try {
    const reply = await agentRecommendation(req.params.agent, context, question);
    res.json({ reply, agent: req.params.agent });
  } catch { res.status(503).json({ error: 'AI service unavailable' }); }
});

aiRouter.post('/semantic-query', async (req, res) => {
  const { question, kpiContext } = req.body as { question: string; kpiContext: string };
  try {
    const reply = await semanticQuery(question, kpiContext);
    res.json({ reply });
  } catch { res.status(503).json({ error: 'AI service unavailable' }); }
});
