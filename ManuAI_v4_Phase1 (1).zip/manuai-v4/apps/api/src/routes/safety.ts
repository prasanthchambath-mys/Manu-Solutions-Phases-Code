import { safetyRouter } from './all-routes';
export default safetyRouter;

import { loadSafetyPermits, loadSafetyZones } from '../data/csv-loader';

router.get('/permits', (_req, res) => {
  res.json({ permits: loadSafetyPermits() });
});

router.get('/zones', (_req, res) => {
  res.json({ zones: loadSafetyZones() });
});
