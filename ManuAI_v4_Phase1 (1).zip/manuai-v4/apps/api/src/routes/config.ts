/**
 * ManuAI — Platform Configuration Route
 *
 * Serves all customer-configurable values from platform_config.csv.
 * Edit platform_config.csv in Excel → restart → values update in UI.
 * No code change, no rebuild needed.
 */

import { Router } from 'express';
import { loadPlatformConfig, loadTechStack, loadSemanticKpiDefs, loadPersonas, loadBaselines } from '../data/csv-loader';

const router = Router();

router.get('/', (_req, res) => {
  try {
    res.json(loadPlatformConfig());
  } catch (err) {
    res.status(500).json({ error: 'Failed to load platform config' });
  }
});

router.get('/tech-stack', (_req, res) => {
  try { res.json({ stacks: loadTechStack() }); }
  catch (err) { res.status(500).json({ error: 'Failed to load tech stack' }); }
});

router.get('/semantic-kpis', (_req, res) => {
  try { res.json({ definitions: loadSemanticKpiDefs() }); }
  catch (err) { res.status(500).json({ error: 'Failed to load semantic KPI definitions' }); }
});

router.get('/personas', (_req, res) => {
  try { res.json({ personas: loadPersonas() }); }
  catch (err) { res.status(500).json({ error: 'Failed to load personas' }); }
});

router.get('/baselines', (_req, res) => {
  try { res.json({ baselines: loadBaselines() }); }
  catch (err) { res.status(500).json({ error: 'Failed to load baselines' }); }
});

export default router;
