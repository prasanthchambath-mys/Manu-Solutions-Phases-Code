import { qualityRouter } from './all-routes';
export default qualityRouter;

router.get('/defects', (_req, res) => {
  const defects = loadQualityDefects();
  // Build hourly trend from defect timestamps
  const hourly: Record<string, number> = {};
  for (let h = 6; h <= 18; h++) {
    const key = `${String(h).padStart(2,'0')}:00`;
    hourly[key] = 0;
  }
  for (const d of (defects as any[])) {
    const h = d.time?.slice(0,5) ?? '06:00';
    const bucket = h.slice(0,2) + ':00';
    if (hourly[bucket] !== undefined) hourly[bucket]++;
  }
  const trend = Object.entries(hourly).map(([h, count]) => ({ h, defects: count }));
  res.json({ log: defects, trend });
});

router.get('/lines', (_req, res) => {
  res.json({ lines: loadQualityLines() });
});
