import { energyRouter } from './all-routes';
export default energyRouter;

router.get('/spend', (req, res) => {
  const days = Number(req.query.days ?? 180);
  const trend = getEnergyTrend(days);
  // Compute monthly planned vs unplanned spend
  const monthly: Record<string, {planned:number, unplanned:number}> = {};
  for (const row of trend) {
    const m = row.day.slice(0, 7); // YYYY-MM
    if (!monthly[m]) monthly[m] = { planned: 0, unplanned: 0 };
    const kwhCost = 7.5; // Rs per kWh
    monthly[m].planned += Math.round(row.avg_kw * 16 * kwhCost); // 16h planned
    monthly[m].unplanned += Math.round(row.avg_kw * 8 * kwhCost * (row.anomalies > 0 ? 0.3 : 0.05));
  }
  const data = Object.entries(monthly).slice(-6).map(([m, v]) => ({
    m: new Date(m + '-01').toLocaleString('default', { month: 'short' }),
    planned: v.planned,
    unplanned: v.unplanned,
  }));
  res.json({ data });
});

router.get('/waste', (_req, res) => {
  res.json({ waste: loadEnergyWaste() });
});

router.get('/carbon', (_req, res) => {
  res.json({ data: loadCarbonTrend() });
});

router.get('/demand-forecast', (_req, res) => {
  res.json({ data: loadDemandForecast() });
});

router.get('/dispatch', (_req, res) => {
  res.json({ actions: loadEnergyDispatch() });
});
