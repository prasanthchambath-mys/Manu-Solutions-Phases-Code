/**
 * ManuAI — Database Schema
 * Creates all tables on first startup if they don't exist.
 * Safe to run multiple times — uses IF NOT EXISTS.
 */

import { getDb } from './connection';
import { logger } from '../middleware/logger';

export function runMigrations(): void {
  const db = getDb();

  db.exec(`
    -- OEE readings — one row per machine per tick
    CREATE TABLE IF NOT EXISTS oee_readings (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      machine_id   TEXT    NOT NULL,
      machine_name TEXT    NOT NULL,
      line         TEXT    NOT NULL,
      ts           INTEGER NOT NULL,   -- Unix timestamp ms
      oee          REAL    NOT NULL,
      avail        REAL    NOT NULL,
      perf         REAL    NOT NULL,
      qual         REAL    NOT NULL,
      loss_type    TEXT,
      loss_min     INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_oee_machine_ts ON oee_readings(machine_id, ts);
    CREATE INDEX IF NOT EXISTS idx_oee_ts         ON oee_readings(ts);

    -- Machine health and sensor readings
    CREATE TABLE IF NOT EXISTS machine_health (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      machine_id   TEXT    NOT NULL,
      ts           INTEGER NOT NULL,
      health       REAL    NOT NULL,
      rul          REAL    NOT NULL,
      vib          REAL    NOT NULL,
      temp         REAL    NOT NULL,
      status       TEXT    NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_health_machine_ts ON machine_health(machine_id, ts);

    -- Alerts fired by the simulation engine
    CREATE TABLE IF NOT EXISTS alerts (
      id           TEXT    PRIMARY KEY,
      machine_id   TEXT    NOT NULL,
      machine_name TEXT,
      line         TEXT,
      type         TEXT    NOT NULL,
      severity     TEXT    NOT NULL,
      message      TEXT    NOT NULL,
      ts           INTEGER NOT NULL,
      acked        INTEGER DEFAULT 0,
      acked_by     TEXT,
      acked_at     INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_alerts_ts       ON alerts(ts);
    CREATE INDEX IF NOT EXISTS idx_alerts_machine  ON alerts(machine_id);
    CREATE INDEX IF NOT EXISTS idx_alerts_severity ON alerts(severity);

    -- Production batches
    CREATE TABLE IF NOT EXISTS batches (
      id           TEXT    PRIMARY KEY,
      product      TEXT    NOT NULL,
      qty_kg       INTEGER NOT NULL,
      plan_yield   REAL    NOT NULL,
      actual_yield REAL,
      status       TEXT    NOT NULL,
      started_at   INTEGER NOT NULL,
      completed_at INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_batches_ts ON batches(started_at);

    -- Yield parameter history
    CREATE TABLE IF NOT EXISTS yield_history (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      param_id     TEXT    NOT NULL,
      param_name   TEXT    NOT NULL,
      ts           INTEGER NOT NULL,
      value        REAL    NOT NULL,
      target       REAL    NOT NULL,
      warn         INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_yield_param_ts ON yield_history(param_id, ts);

    -- Energy readings per asset
    CREATE TABLE IF NOT EXISTS energy_readings (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      asset_id     TEXT    NOT NULL,
      asset_name   TEXT    NOT NULL,
      ts           INTEGER NOT NULL,
      kw           REAL    NOT NULL,
      anomaly      INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_energy_asset_ts ON energy_readings(asset_id, ts);

    -- Safety events
    CREATE TABLE IF NOT EXISTS safety_events (
      id           TEXT    PRIMARY KEY,
      zone         TEXT    NOT NULL,
      event_type   TEXT    NOT NULL,
      severity     TEXT    NOT NULL,
      h2s          REAL    DEFAULT 0,
      co           REAL    DEFAULT 0,
      ch4          REAL    DEFAULT 0,
      ts           INTEGER NOT NULL,
      resolved_at  INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_safety_ts ON safety_events(ts);


  -- ══════════════════════════════════════════════════════════════
  -- SEMANTIC CORE — Dimension tables (enterprise data model)
  -- ══════════════════════════════════════════════════════════════

  CREATE TABLE IF NOT EXISTS dim_plant (
    plant_id     TEXT PRIMARY KEY,
    plant_name   TEXT NOT NULL,
    location     TEXT,
    timezone     TEXT DEFAULT 'Asia/Kolkata',
    currency     TEXT DEFAULT 'INR',
    created_at   INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS dim_line (
    line_id      TEXT PRIMARY KEY,
    line_name    TEXT NOT NULL,
    plant_id     TEXT NOT NULL REFERENCES dim_plant(plant_id),
    line_type    TEXT,
    capacity_pct REAL DEFAULT 100,
    created_at   INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS dim_asset (
    asset_id     TEXT PRIMARY KEY,
    asset_name   TEXT NOT NULL,
    asset_type   TEXT NOT NULL,
    line_id      TEXT REFERENCES dim_line(line_id),
    plant_id     TEXT NOT NULL,
    rated_kw     REAL,
    source_system TEXT DEFAULT 'PI_HISTORIAN',
    created_at   INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_dim_asset_line ON dim_asset(line_id);

  CREATE TABLE IF NOT EXISTS dim_supplier (
    supplier_id   TEXT PRIMARY KEY,
    supplier_name TEXT NOT NULL,
    country       TEXT,
    risk_category TEXT DEFAULT 'medium',
    single_source INTEGER DEFAULT 0,
    created_at    INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS dim_material (
    material_id   TEXT PRIMARY KEY,
    material_name TEXT NOT NULL,
    unit          TEXT NOT NULL,
    category      TEXT,
    lead_days     INTEGER DEFAULT 14,
    created_at    INTEGER NOT NULL
  );

  -- ══════════════════════════════════════════════════════════════
  -- SEMANTIC CORE — Fact tables (enterprise event/reading model)
  -- ══════════════════════════════════════════════════════════════

  CREATE TABLE IF NOT EXISTS fact_sensor_reading (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id     TEXT NOT NULL REFERENCES dim_asset(asset_id),
    ts           INTEGER NOT NULL,
    reading_type TEXT NOT NULL,  -- vibration|temperature|pressure|current
    value        REAL NOT NULL,
    unit         TEXT NOT NULL,
    source_system TEXT DEFAULT 'PI_HISTORIAN',
    quality_flag  TEXT DEFAULT 'GOOD'
  );
  CREATE INDEX IF NOT EXISTS idx_fact_sensor_asset_ts ON fact_sensor_reading(asset_id, ts);
  CREATE INDEX IF NOT EXISTS idx_fact_sensor_type     ON fact_sensor_reading(reading_type, ts);

  CREATE TABLE IF NOT EXISTS fact_production_order (
    order_id     TEXT PRIMARY KEY,
    material_id  TEXT REFERENCES dim_material(material_id),
    line_id      TEXT REFERENCES dim_line(line_id),
    planned_qty  REAL NOT NULL,
    actual_qty   REAL,
    planned_yield REAL,
    actual_yield  REAL,
    status       TEXT NOT NULL,
    source_system TEXT DEFAULT 'SAP_PP',
    started_at   INTEGER,
    completed_at INTEGER,
    created_at   INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS fact_work_order (
    wo_id        TEXT PRIMARY KEY,
    asset_id     TEXT REFERENCES dim_asset(asset_id),
    wo_type      TEXT NOT NULL,  -- corrective|preventive|predictive
    priority     TEXT NOT NULL,
    description  TEXT,
    status       TEXT NOT NULL,
    assigned_to  TEXT,
    source_system TEXT DEFAULT 'SAP_PM',
    triggered_by  TEXT,  -- semantic_event_id that triggered this WO
    created_at   INTEGER NOT NULL,
    completed_at INTEGER
  );
  CREATE INDEX IF NOT EXISTS idx_fact_wo_asset ON fact_work_order(asset_id);

  CREATE TABLE IF NOT EXISTS fact_quality_event (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id     TEXT REFERENCES dim_asset(asset_id),
    line_id      TEXT REFERENCES dim_line(line_id),
    ts           INTEGER NOT NULL,
    defect_type  TEXT NOT NULL,
    severity     TEXT NOT NULL,
    confidence   REAL,
    action_taken TEXT,
    source_system TEXT DEFAULT 'VISION_AI',
    ncr_id       TEXT  -- SAP QM NCR reference
  );
  CREATE INDEX IF NOT EXISTS idx_fact_quality_ts ON fact_quality_event(ts);

  CREATE TABLE IF NOT EXISTS fact_energy_reading (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id     TEXT REFERENCES dim_asset(asset_id),
    ts           INTEGER NOT NULL,
    kw           REAL NOT NULL,
    kwh_cumulative REAL,
    tariff_zone  TEXT DEFAULT 'peak',
    anomaly      INTEGER DEFAULT 0,
    source_system TEXT DEFAULT 'SMART_METER'
  );
  CREATE INDEX IF NOT EXISTS idx_fact_energy_asset_ts ON fact_energy_reading(asset_id, ts);

  CREATE TABLE IF NOT EXISTS fact_safety_event (
    event_id     TEXT PRIMARY KEY,
    zone         TEXT NOT NULL,
    asset_id     TEXT,
    event_type   TEXT NOT NULL,
    severity     TEXT NOT NULL,
    h2s_ppm      REAL DEFAULT 0,
    co_ppm       REAL DEFAULT 0,
    ch4_lel_pct  REAL DEFAULT 0,
    source_system TEXT DEFAULT 'EHS_SYSTEM',
    ts           INTEGER NOT NULL,
    resolved_at  INTEGER,
    ptw_id       TEXT  -- linked PTW if any
  );
  CREATE INDEX IF NOT EXISTS idx_fact_safety_ts ON fact_safety_event(ts);

  -- ══════════════════════════════════════════════════════════════
  -- SEMANTIC CORE — KPI Engine tables
  -- ══════════════════════════════════════════════════════════════

  CREATE TABLE IF NOT EXISTS semantic_kpi_definition (
    kpi_id       TEXT PRIMARY KEY,
    kpi_name     TEXT NOT NULL,
    formula      TEXT NOT NULL,
    unit         TEXT NOT NULL,
    agents       TEXT NOT NULL,  -- comma-separated agent IDs
    source_system TEXT NOT NULL,
    governance   TEXT DEFAULT 'Semantic Layer',
    created_at   INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS semantic_kpi_value (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    kpi_id       TEXT NOT NULL REFERENCES semantic_kpi_definition(kpi_id),
    asset_id     TEXT,
    scope        TEXT DEFAULT 'plant',  -- plant|line|asset
    ts           INTEGER NOT NULL,
    value        REAL NOT NULL,
    target       REAL,
    status       TEXT DEFAULT 'ok'  -- ok|warn|critical
  );
  CREATE INDEX IF NOT EXISTS idx_kpi_value_kpi_ts ON semantic_kpi_value(kpi_id, ts);
  CREATE INDEX IF NOT EXISTS idx_kpi_value_asset   ON semantic_kpi_value(asset_id, ts);

  -- ══════════════════════════════════════════════════════════════
  -- SEMANTIC CORE — Event orchestration tables
  -- ══════════════════════════════════════════════════════════════

  CREATE TABLE IF NOT EXISTS semantic_event (
    event_id     TEXT PRIMARY KEY,
    event_type   TEXT NOT NULL,
    from_agent   TEXT NOT NULL,
    asset_id     TEXT,
    severity     TEXT NOT NULL,
    message      TEXT NOT NULL,
    payload      TEXT,           -- JSON blob with full event data
    ts           INTEGER NOT NULL,
    resolved_at  INTEGER,
    scenario_id  TEXT            -- links to orchestration scenario
  );
  CREATE INDEX IF NOT EXISTS idx_sem_event_ts       ON semantic_event(ts);
  CREATE INDEX IF NOT EXISTS idx_sem_event_asset    ON semantic_event(asset_id);
  CREATE INDEX IF NOT EXISTS idx_sem_event_type     ON semantic_event(event_type);

  CREATE TABLE IF NOT EXISTS semantic_event_impact (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id     TEXT NOT NULL REFERENCES semantic_event(event_id),
    target_agent TEXT NOT NULL,
    impact_type  TEXT NOT NULL,  -- oee_loss|yield_risk|supply_risk|safety_risk|energy_impact|twin_divergence
    impact_value REAL,
    impact_unit  TEXT,
    description  TEXT NOT NULL,
    action_taken TEXT,
    action_ref   TEXT,           -- WO ID, PTW ID, PO ID etc
    ts           INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_sem_impact_event ON semantic_event_impact(event_id);
  CREATE INDEX IF NOT EXISTS idx_sem_impact_agent ON semantic_event_impact(target_agent, ts);

  CREATE TABLE IF NOT EXISTS orchestration_scenario (
    scenario_id  TEXT PRIMARY KEY,
    scenario_name TEXT NOT NULL,
    trigger_event TEXT NOT NULL,
    asset_id     TEXT,
    status       TEXT DEFAULT 'running',  -- running|complete|paused
    started_at   INTEGER NOT NULL,
    completed_at INTEGER,
    steps_total  INTEGER DEFAULT 0,
    steps_done   INTEGER DEFAULT 0,
    summary      TEXT
  );

    -- Schema version tracking
    CREATE TABLE IF NOT EXISTS schema_version (
      version      INTEGER PRIMARY KEY,
      applied_at   INTEGER NOT NULL
    );
  `);

  // Mark schema version
  const existing = db.prepare('SELECT version FROM schema_version WHERE version = 2').get();
  if (!existing) {
    db.prepare('INSERT OR IGNORE INTO schema_version (version, applied_at) VALUES (2, ?)').run(Date.now());
  }

  logger.info('[DB] Schema migrations complete');
}

export function isHistorySeeded(): boolean {
  const db = getDb();
  const row = db.prepare('SELECT COUNT(*) as cnt FROM oee_readings').get() as { cnt: number };
  return row.cnt > 1000; // If more than 1000 rows, history is already seeded
}
