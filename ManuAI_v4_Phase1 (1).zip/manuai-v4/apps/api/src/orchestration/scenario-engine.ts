/**
 * ManuAI — Orchestration Scenario Engine
 *
 * Demonstrates the full enterprise cross-agent cascade.
 * When MCH-06 / any asset degrades below critical threshold,
 * the scenario engine fires in sequence:
 *
 * 1. PdM predicts RUL — publishes semantic_event MAINTENANCE_REQUIRED
 * 2. Digital Twin simulates failure impact on OEE
 * 3. OEE Agent shows current + projected loss
 * 4. Parts/Supply: PO raised for required spares, lead time checked
 * 5. Safety: PTW pre-created for maintenance window
 * 6. Yield: Parameters adjusted to compensate for reduced capacity
 * 7. Quality: Defect rate monitoring heightened
 * 8. Energy: Load redistributed away from degrading asset
 *
 * All steps persist to semantic_event_impact.
 * The frontend receives each step via WebSocket cross_agent_event — no frontend change.
 */

import { getDb } from '../database/connection';
import { semanticLayer } from '../semantic/service';
import { persistSemanticEvent, persistEventImpact, resolveEvent } from '../database/event-store';
import { broadcastEvent } from '../websocket/broadcaster';
import { logger } from '../middleware/logger';
import { getPlantState } from '../simulation/engine';
import { loadParts, loadSupplyRisks } from '../data/csv-loader';

// Track active scenarios to avoid duplicate runs
const activeScenarios = new Map<string, number>(); // assetId → startedAt

export interface ScenarioStep {
  step:   number;
  agent:  string;
  action: string;
  result: string;
  ref?:   string;
}

/**
 * Main orchestration trigger.
 * Called by simulation engine when an asset degrades to critical.
 * Fires the full cross-agent cascade in sequence with realistic delays.
 */
export async function triggerDegradationScenario(
  assetId: string,
  assetName: string,
  rul: number,
  health: number
): Promise<void> {
  // Avoid running duplicate scenario for same asset
  const lastRun = activeScenarios.get(assetId) ?? 0;
  if (Date.now() - lastRun < 20 * 60 * 1000) return; // 20 min cooldown
  activeScenarios.set(assetId, Date.now());

  const scenarioId = `SCN-${assetId}-${Date.now()}`;
  const eventId    = `EVT-${assetId}-${Date.now()}`;
  const now        = Date.now();

  logger.info(`[Orchestration] Scenario triggered — ${assetId} RUL=${rul}d`, { scenarioId });

  // Persist root scenario event
  persistSemanticEvent({
    id: eventId, type: 'ASSET_DEGRADATION_SCENARIO',
    from: 'pdm', to: 'all',
    sev: rul < 10 ? 'critical' : 'warning',
    msg: `${assetName}: RUL ${rul} days. Full cross-agent orchestration initiated.`,
    impact: `OEE risk, yield risk, supply lead time check, PTW pre-creation`,
    asset: assetId, ts: new Date().toISOString(),
  });

  // Register scenario in DB
  try {
    getDb().prepare(`
      INSERT OR IGNORE INTO orchestration_scenario
        (scenario_id, scenario_name, trigger_event, asset_id, status, started_at, steps_total)
      VALUES (?, ?, ?, ?, 'running', ?, 8)
    `).run(scenarioId, `${assetName} Degradation Response`, eventId, assetId, now);
  } catch { /* non-fatal */ }

  const steps: ScenarioStep[] = [];

  // ── Step 1: PdM — RUL prediction published ──────────────────────────────
  await delay(500);
  steps.push({ step:1, agent:'pdm', action:'RUL_PREDICTION', result:`RUL=${rul} days computed from vibration+thermal+run_hours`, ref:eventId });
  persistEventImpact(eventId, 'pdm', 'rul_prediction', rul, 'days',
    `Bearing degradation detected. RUL ${rul} days. Maintenance window required before ${new Date(Date.now()+rul*86400000).toDateString()}.`,
    'Work order pre-created', `WO-${assetId}-AUTO`);
  await broadcastStep(assetId, 'pdm', 'oee', 'MAINTENANCE_REQUIRED',
    `${assetName}: RUL ${rul} days — maintenance window required`, rul < 10 ? 'critical' : 'warning');

  // ── Step 2: Digital Twin — failure simulation ───────────────────────────
  await delay(800);
  const oeeProjectedLoss = +(health < 30 ? 18.4 : health < 50 ? 12.1 : 7.2).toFixed(1);
  steps.push({ step:2, agent:'twin', action:'FAILURE_SIMULATION', result:`Twin projects ${oeeProjectedLoss}% OEE loss on unplanned failure` });
  persistEventImpact(eventId, 'twin', 'oee_loss', oeeProjectedLoss, '%',
    `Digital twin simulated ${assetName} failure scenario. Projected OEE impact: -${oeeProjectedLoss}% vs current.`,
    'Scenario SCN-AUTO created', `SCN-${assetId}`);
  await broadcastStep(assetId, 'twin', 'oee', 'TWIN_FAILURE_PROJECTION',
    `Twin projects -${oeeProjectedLoss}% OEE if ${assetName} fails unplanned`, 'warning');

  // ── Step 3: OEE — current and projected loss flagged ────────────────────
  await delay(600);
  const state = getPlantState();
  const asset = state.machines.find(m => m.id === assetId);
  const currentOee = asset?.oee ?? 72;
  steps.push({ step:3, agent:'oee', action:'LOSS_PROJECTION', result:`Current OEE ${currentOee}%. Projected post-failure: ${(currentOee-oeeProjectedLoss).toFixed(1)}%` });
  persistEventImpact(eventId, 'oee', 'oee_loss', oeeProjectedLoss, '%',
    `Current ${assetName} OEE: ${currentOee}%. Unplanned failure would reduce plant OEE to ${(currentOee-oeeProjectedLoss).toFixed(1)}%.`,
    'OEE impact logged', null);

  // ── Step 4: Supply — parts availability check ───────────────────────────
  await delay(700);
  const parts = loadParts();
  const relatedPart = (parts.orders as any[]).find((p: any) =>
    p.asset === assetId || assetId.toLowerCase().includes(p.sku?.toLowerCase()?.slice(0,3) ?? 'XXX')
  );
  const partAvailable = relatedPart ? relatedPart.stock > 0 : false;
  const partLeadDays  = relatedPart?.lead ?? 5;
  steps.push({ step:4, agent:'supply', action:'PARTS_LEAD_CHECK',
    result: partAvailable ? `Parts in stock (${relatedPart?.sku})` : `Parts on order — lead time ${partLeadDays} days` });
  persistEventImpact(eventId, 'supply', 'supply_risk',
    partAvailable ? 0 : partLeadDays, 'days',
    partAvailable
      ? `Required spares available in stock for ${assetName} maintenance.`
      : `Critical spare (${relatedPart?.sku ?? 'SRV-SERVO'}) lead time ${partLeadDays} days. PO required immediately.`,
    partAvailable ? 'Stock confirmed' : 'Emergency PO raised',
    partAvailable ? null : `PO-${assetId}-EMRG`);
  await broadcastStep(assetId, 'supply', 'pdm', 'PARTS_STATUS_CHECK',
    partAvailable ? `Parts in stock for ${assetName}` : `Spare parts order required — ${partLeadDays}d lead`, 'info');

  // ── Step 5: Safety — PTW pre-creation ──────────────────────────────────
  await delay(600);
  const ptwId = `PTW-${assetId}-${Date.now().toString().slice(-6)}`;
  steps.push({ step:5, agent:'safety', action:'PTW_PRE_CREATED', result:`PTW ${ptwId} pre-created for maintenance window`, ref:ptwId });
  persistEventImpact(eventId, 'safety', 'safety_risk', null, null,
    `Permit-to-Work ${ptwId} pre-created for ${assetName} maintenance. Isolation procedure and competency checks initiated.`,
    'PTW pre-created', ptwId);
  await broadcastStep(assetId, 'safety', 'pdm', 'PTW_PRE_CREATED',
    `PTW ${ptwId} pre-created for ${assetName} maintenance`, 'info');

  // ── Step 6: Yield — parameter compensation ──────────────────────────────
  await delay(500);
  steps.push({ step:6, agent:'yield', action:'PARAM_COMPENSATION', result:'DCS parameters adjusted to compensate reduced line capacity' });
  persistEventImpact(eventId, 'yield', 'yield_risk', 3.2, '%',
    `${assetName} degradation risk: -3.2% yield on linked parameters. DCS compensation set-points recommended.`,
    'DCS recommendations generated', null);
  await broadcastStep(assetId, 'yield', 'pdm', 'YIELD_PARAM_ADJUSTMENT',
    `DCS parameters adjusted for ${assetName} reduced capacity`, 'info');

  // ── Step 7: Quality — heightened monitoring ─────────────────────────────
  await delay(400);
  steps.push({ step:7, agent:'quality', action:'MONITORING_HEIGHTENED', result:'Vision AI inspection frequency doubled for linked line' });
  persistEventImpact(eventId, 'quality', 'defect_rate', 1.8, '%',
    `Degrading ${assetName} may cause dimensional variance. Quality vision inspection rate doubled on ${asset?.line ?? 'linked line'}.`,
    'Inspection frequency doubled', null);
  await broadcastStep(assetId, 'quality', 'oee', 'QUALITY_RISK_FLAGGED',
    `Quality inspection rate doubled — ${assetName} dimensional risk`, 'warning');

  // ── Step 8: Energy — load redistribution ────────────────────────────────
  await delay(500);
  steps.push({ step:8, agent:'energy', action:'LOAD_REDISTRIBUTED', result:`${assetName} load shifted to alternative assets` });
  persistEventImpact(eventId, 'energy', 'energy_impact', null, null,
    `${assetName} approaching critical — energy load redistributed. Demand response dispatch updated.`,
    'Load dispatch updated', `LD-${assetId}`);
  await broadcastStep(assetId, 'energy', 'pdm', 'ENERGY_LOAD_REDISTRIBUTED',
    `Energy load redistributed away from degrading ${assetName}`, 'info');

  // ── Scenario complete ────────────────────────────────────────────────────
  const summary = `8-agent orchestration complete for ${assetName}. RUL=${rul}d. PTW created. Parts checked. Yield adjusted.`;
  try {
    getDb().prepare(`
      UPDATE orchestration_scenario
      SET status='complete', completed_at=?, steps_done=8, summary=?
      WHERE scenario_id=?
    `).run(Date.now(), summary, scenarioId);
  } catch { /* non-fatal */ }

  logger.info(`[Orchestration] Scenario complete — ${scenarioId}`, { steps: steps.length });
}

async function broadcastStep(
  assetId: string, from: string, to: string,
  type: string, msg: string, sev: 'critical'|'warning'|'info'
): Promise<void> {
  const event = {
    id: `${type}-${assetId}-${Date.now()}`,
    from, to, type, sev, msg,
    impact: msg, asset: assetId,
    ts: new Date().toISOString(),
  };
  await semanticLayer.publishEvent(event as any);
  broadcastEvent(event as any);
}

function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export function getActiveScenarios(): any[] {
  try {
    return getDb().prepare(
      'SELECT * FROM orchestration_scenario ORDER BY started_at DESC LIMIT 10'
    ).all();
  } catch { return []; }
}

export function getScenarioSteps(scenarioId: string): any[] {
  try {
    const db = getDb();
    const scenario = db.prepare('SELECT * FROM orchestration_scenario WHERE scenario_id=?').get(scenarioId);
    if (!scenario) return [];
    const event = db.prepare('SELECT * FROM semantic_event WHERE event_id=?').get((scenario as any).trigger_event);
    const impacts = db.prepare('SELECT * FROM semantic_event_impact WHERE event_id=? ORDER BY ts ASC').all((scenario as any).trigger_event);
    return [{ scenario, event, impacts }];
  } catch { return []; }
}
