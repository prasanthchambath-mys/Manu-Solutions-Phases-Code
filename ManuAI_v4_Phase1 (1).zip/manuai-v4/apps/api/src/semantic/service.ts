import { EventEmitter } from 'events';
import { persistSemanticEvent, persistEventImpact, getRecentEvents as getStoredEvents } from '../database/event-store';
import { logger } from '../middleware/logger';
import { broadcastEvent } from '../websocket/broadcaster';

export type AgentId = 'oee' | 'yield' | 'pdm' | 'quality' | 'energy' | 'supply' | 'twin' | 'safety';

export interface CrossAgentEvent {
  id: string; from: AgentId | string; to: AgentId | string;
  type: string; sev: 'critical' | 'warning' | 'info';
  msg: string; impact: string; asset: string; ts: string;
}

export interface AgentAction {
  agent: AgentId; type: string; assetId?: string; tagId?: string;
}

// KPI definitions — single source of truth for all 9 agents
export const KPI_DEFINITIONS = {
  oee:               { name: 'OEE',               formula: 'Availability × Performance × Quality',                       unit: '%',            agents: ['oee','pdm','yield','twin'],        src: 'MES + OPC-UA' },
  availability:      { name: 'Availability',       formula: '(Planned time − Downtime) / Planned time × 100',            unit: '%',            agents: ['oee'],                              src: 'MES event codes' },
  performance:       { name: 'Performance',        formula: '(Ideal cycle time × Actual output) / Run time × 100',       unit: '%',            agents: ['oee'],                              src: 'MES + PLC counts' },
  quality:           { name: 'Quality',            formula: 'Good units / Total units × 100',                            unit: '%',            agents: ['oee','quality'],                    src: 'MES + Vision AI' },
  yield_pct:         { name: 'Yield',              formula: 'Good units / Planned units × 100',                          unit: '%',            agents: ['yield','twin'],                     src: 'SAP PP + LIMS' },
  asset_health_pct:  { name: 'Asset Health',       formula: 'Composite z-score: vibration + thermal + pressure (0–100)', unit: '%',            agents: ['pdm','twin'],                       src: 'IoT Hub + PI' },
  rul_days:          { name: 'Remaining Useful Life', formula: 'Azure ML regression on multi-sensor features',           unit: 'days',         agents: ['pdm'],                              src: 'IoT Hub + PI historian' },
  kwh_per_unit:      { name: 'kWh / Unit',         formula: 'Total plant kWh / Units produced',                          unit: 'kWh/unit',     agents: ['energy'],                           src: 'Smart meters + MES' },
  carbon_intensity:  { name: 'Carbon Intensity',   formula: 'Grid carbon factor × kWh consumed / Units produced',        unit: 'kgCO₂/unit',   agents: ['energy'],                           src: 'Grid API + smart meters' },
  defect_rate:       { name: 'Defect Rate',        formula: 'Defective parts / Total parts × 100',                       unit: '%',            agents: ['quality','oee'],                    src: 'Vision AI + MES' },
  supply_risk_score: { name: 'Supply Risk Score',  formula: 'Composite: lead drift × financial risk × geo risk',         unit: '0–100',        agents: ['supply'],                           src: 'ERP + external APIs' },
  twin_divergence:   { name: 'Twin Divergence',    formula: '|actual_KPI − twin_KPI| / twin_KPI × 100',                 unit: '%',            agents: ['twin','pdm','yield'],               src: 'PI System + Azure Digital Twins' },
  near_miss_rate:    { name: 'Near-Miss Rate',     formula: 'Near-miss events / Production hours × 1000',                unit: 'per 1000h',    agents: ['safety'],                           src: 'IoT sensor network' },
  permit_compliance: { name: 'Permit Compliance',  formula: 'Valid PTWs / Total PTW requests × 100',                     unit: '%',            agents: ['safety'],                           src: 'CMMS + PTW system' },
};

// Conflict rules — if trigger is active, the matching action is blocked
const CONFLICT_RULES = [
  {
    id: 'CR-001',
    description: 'PdM critical fault blocks Yield DCS write on linked asset',
    triggerAgent: 'pdm' as AgentId,
    blockAgent: 'yield' as AgentId,
    blockActionType: 'dcs_write',
    reason: 'PdM critical fault detected — DCS write unsafe until maintenance work order closes',
  },
  {
    id: 'CR-002',
    description: 'Active gas precursor blocks hot-work PTW approval',
    triggerAgent: 'safety' as AgentId,
    blockAgent: 'safety' as AgentId,
    blockActionType: 'ptw_approve',
    reason: 'Active gas precursor in zone — hot-work permit cannot be approved',
  },
];

// Active faults: Map<"ruleId::assetId", since>
const activeFaults = new Map<string, Date>();

class SemanticLayerService {
  private emitter = new EventEmitter();
  private recentEvents: CrossAgentEvent[] = [];
  private _cache = new Map<string, { val: unknown; exp: number }>();

  constructor() {
    this.emitter.setMaxListeners(50);
    logger.info('[Semantic] Using in-memory event bus (Redis inactive)');
  }

  getKPIDefinitions() { return KPI_DEFINITIONS; }

  registerFault(ruleId: string, assetId: string): void {
    activeFaults.set(`${ruleId}::${assetId}`, new Date());
    logger.info('Semantic Layer: fault registered', { ruleId, assetId });
  }

  resolveFault(ruleId: string, assetId: string): void {
    activeFaults.delete(`${ruleId}::${assetId}`);
    logger.info('Semantic Layer: fault resolved', { ruleId, assetId });
  }

  checkConflict(action: AgentAction): { blocked: boolean; reason?: string } {
    for (const rule of CONFLICT_RULES) {
      if (rule.blockAgent !== action.agent) continue;
      if (rule.blockActionType !== action.type) continue;
      for (const [faultKey] of activeFaults) {
        if (faultKey.startsWith(rule.id)) {
          return { blocked: true, reason: rule.reason };
        }
      }
    }
    return { blocked: false };
  }

  async publishEvent(event: CrossAgentEvent): Promise<void> {
    // Persist to SQLite first — full audit trail
    persistSemanticEvent(event);
    // Keep in-memory for fast reads
    this.recentEvents.unshift(event);
    if (this.recentEvents.length > 500) this.recentEvents = this.recentEvents.slice(0, 500);
    this.emitter.emit('cross_agent_event', event);
    broadcastEvent(event as unknown as Record<string, unknown>);
    logger.info('Semantic event', { type: event.type, from: event.from, to: event.to });
  }

  async getRecentEvents(limit = 50): Promise<CrossAgentEvent[]> {
    try {
      // Read from SQLite for persistence across restarts
      const stored = getStoredEvents(limit);
      if (stored.length > 0) {
        return stored.map((r: any) => ({
          ...JSON.parse(r.payload ?? '{}'),
          id: r.event_id, type: r.event_type,
          from: r.from_agent, asset: r.asset_id,
          sev: r.severity, msg: r.message, ts: new Date(r.ts).toISOString(),
        }));
      }
    } catch { /* fall through to in-memory */ }
    return this.recentEvents.slice(0, limit);
  }

  async cache<T>(key: string, ttl: number, fn: () => Promise<T>): Promise<T> {
    const cached = this._cache.get(key);
    if (cached && Date.now() < cached.exp) return cached.val as T;
    const val = await fn();
    this._cache.set(key, { val, exp: Date.now() + ttl * 1000 });
    return val;
  }
}

export const semanticLayer = new SemanticLayerService();
