import 'dotenv/config';
import { runMigrations } from './database/schema';
import { isHistorySeeded } from './database/schema';
import { seedHistory } from './database/seed-history';
import { seedDimensions } from './database/seed-dimensions';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import { createServer } from 'http';
import { initWebSocket } from './websocket/broadcaster';
import { authMiddleware } from './middleware/auth';
import { requestLogger, logger, errorHandler } from './middleware/logger';
import { startIngestion } from './connectors/iot-hub';
import { simulationEngine } from './simulation/engine';
import healthRoutes from './routes/health';
import oeeRoutes from './routes/oee';
import yieldRoutes from './routes/yield';
import pdmRoutes from './routes/pdm';
import qualityRoutes from './routes/quality';
import energyRoutes from './routes/energy';
import supplyRoutes from './routes/supply';
import twinRoutes from './routes/twin';
import safetyRoutes from './routes/safety';
import semanticRoutes from './routes/semantic';
import aiRoutes from './routes/ai';
import historyRoutes from './routes/history';
import configRoutes      from './routes/config';
import { sourceRouter }      from './routes/source';
import { semanticCoreRouter } from './routes/semantic-core';

const app = express();
const httpServer = createServer(app);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: process.env.CORS_ORIGINS?.split(',') ?? ['http://localhost:5173'],
  credentials: true,
}));
app.use(rateLimit({ windowMs: 60_000, max: 2000, standardHeaders: true, skip: (req) => req.path.startsWith('/api/oee/live') || req.path.startsWith('/api/health') }));
app.use(compression());
app.use(express.json({ limit: '1mb' }));
app.use(requestLogger);

app.use('/api/health',   healthRoutes);
app.use('/api',          authMiddleware);
app.use('/api/oee',      oeeRoutes);
app.use('/api/yield',    yieldRoutes);
app.use('/api/pdm',      pdmRoutes);
app.use('/api/quality',  qualityRoutes);
app.use('/api/energy',   energyRoutes);
app.use('/api/supply',   supplyRoutes);
app.use('/api/twin',     twinRoutes);
app.use('/api/safety',   safetyRoutes);
app.use('/api/semantic', semanticRoutes);
app.use('/api/ai',       aiRoutes);
app.use('/api/history',  historyRoutes);
app.use('/api/config',      configRoutes);
app.use('/api/source',      sourceRouter);
app.use('/api/semantic/core', semanticCoreRouter);
app.use(errorHandler);

// ── Database init ──────────────────────────────────────────────────────────
runMigrations();
  seedDimensions();
(async () => {
  if (!isHistorySeeded()) {
    logger.info('Database empty — seeding 30 days of historical data...');
    await seedHistory();
  } else {
    logger.info('[DB] Historical data already present — skipping seed');
  }
})().catch(err => logger.error('[DB] Seed error', { error: String(err) }));

initWebSocket(httpServer);

// Start IoT Hub ingestion (falls back to simulation if no connection string)
void startIngestion();

// Start synthetic data engine (disabled when real connectors are active)
if (process.env.MOCK_DATA_ENGINE !== 'false') {
  simulationEngine.start(4000);
  logger.info('Synthetic data engine active');
} else {
  logger.info('Synthetic data engine disabled (real connectors mode)');
}

const PORT = Number(process.env.PORT ?? 4000);
httpServer.listen(PORT, () => {
  logger.info(`ManuAI API running on port ${PORT} [${process.env.NODE_ENV ?? 'development'}]`);
});

export default app;
