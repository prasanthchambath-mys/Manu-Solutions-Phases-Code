import { safetyRouter } from './all-routes';
import { loadSafetyPermits, loadSafetyZones } from '../data/csv-loader';

safetyRouter.get('/permits', (_req, res) => {
  res.json({ permits: loadSafetyPermits() });
});

safetyRouter.get('/zones', (_req, res) => {
  res.json({ zones: loadSafetyZones() });
});

export default safetyRouter;
