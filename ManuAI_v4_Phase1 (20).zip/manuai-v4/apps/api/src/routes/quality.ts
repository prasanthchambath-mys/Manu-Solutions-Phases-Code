import { qualityRouter } from './all-routes';
import { loadQualityDefects, loadQualityLines } from '../data/csv-loader';

qualityRouter.get('/defects', (_req, res) => {
  const defects = loadQualityDefects() as any[];
  const hourly: Record<string, number> = {};
  for (let h = 6; h <= 18; h++) {
    hourly[`${String(h).padStart(2, '0')}:00`] = 0;
  }
  for (const d of defects) {
    const bucket = (d.time?.slice(0, 2) ?? '06') + ':00';
    if (hourly[bucket] !== undefined) hourly[bucket]++;
  }
  const trend = Object.entries(hourly).map(([h, count]) => ({ h, defects: count }));
  res.json({ log: defects, trend });
});

qualityRouter.get('/lines', (_req, res) => {
  res.json({ lines: loadQualityLines() });
});

export default qualityRouter;
