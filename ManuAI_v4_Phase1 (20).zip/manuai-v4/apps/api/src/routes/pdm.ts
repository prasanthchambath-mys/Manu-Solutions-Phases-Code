import { pdmRouter } from './all-routes';
import { loadParts, loadPdmRules } from '../data/csv-loader';

// Add extra PdM endpoints not in all-routes.ts
pdmRouter.get('/parts', (_req, res) => {
  const { orders, inventory } = loadParts();
  res.json({ orders, inventory });
});

pdmRouter.get('/rules', (_req, res) => {
  res.json({ rules: loadPdmRules() });
});

export default pdmRouter;
