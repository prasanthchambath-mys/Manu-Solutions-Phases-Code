/**
 * ManuAI — Source System Ingestion Layer Routes
 *
 * These routes represent the enterprise ingestion layer.
 * They expose CSV-backed synthetic data AS IF it came from
 * real enterprise source systems:
 *
 *   /source/pi/*       → Synthetic OSIsoft PI Historian
 *   /source/mes/*      → Synthetic MES / SAP PP
 *   /source/sap/*      → Synthetic SAP PM / ERP
 *   /source/lims/*     → Synthetic LabVantage LIMS
 *   /source/ehs/*      → Synthetic EHS / PTW System
 *   /source/scada/*    → Synthetic SCADA / IoT Hub
 *   /source/qm/*       → Synthetic SAP QM / Vision AI
 *   /source/erp/*      → Synthetic ERP Supplier Risk
 *
 * In Phase 3: replace each loader with the real connector.
 * The route path, response shape and consuming APIs do not change.
 *
 * This is the enterprise data ingestion pattern.
 */

import { Router } from 'express';
import { getPlantState } from '../simulation/engine';
import {
  loadMachines, loadUtilities, loadYieldParams, loadProductionOrders,
  loadWorkOrders, loadLimsResults, loadSafetyPermits, loadSafetyZones,
  loadQualityDefects, loadQualityLines, loadSupplyRisks, loadEnergyAssets,
  loadEnergyHourly, loadParts,
} from '../data/csv-loader';

export const sourceRouter = Router();

// ── /source/pi — OSIsoft PI Historian ────────────────────────────────────────
sourceRouter.get('/pi/assets', (_req, res) => {
  // REPLACE WITH: PI Web API GET /points?nameFilter=*
  const machines = loadMachines() as any[];
  const utilities = loadUtilities() as any[];
  const state = getPlantState();
  const liveMap = new Map(state.machines.map(m => [m.id, m]));
  const liveUtilMap = new Map(state.utilities.map(u => [u.id, u]));

  const assets = [
    ...machines.map(m => {
      const live = liveMap.get(m.id) ?? m;
      return {
        tag:          m.id,
        name:         m.name,
        system:       'PI_HISTORIAN',
        asset_type:   'production_machine',
        line:         m.line,
        health:       live.health,
        rul_days:     live.rul,
        vibration:    live.vib,
        temperature:  live.temp,
        oee:          live.oee,
        status:       live.status,
        last_reading: new Date().toISOString(),
      };
    }),
    ...utilities.map(u => {
      const live = liveUtilMap.get(u.id) ?? u;
      return {
        tag:          u.id,
        name:         u.name,
        system:       'IOT_HUB',
        asset_type:   'utility_asset',
        line:         null,
        health:       live.health,
        rul_days:     live.rul,
        vibration:    live.vib,
        temperature:  live.temp,
        oee:          null,
        status:       live.status,
        last_reading: new Date().toISOString(),
      };
    }),
  ];
  res.json({ source: 'PI_HISTORIAN', source_mode: SOURCE_MODE_MAP['PI_HISTORIAN'], count: assets.length, assets });
});

sourceRouter.get('/pi/tags/:assetId', (req, res) => {
  // REPLACE WITH: PI Web API GET /streams/{webId}/value
  const state = getPlantState();
  const m = state.machines.find(m => m.id === req.params.assetId)
         || state.utilities.find(u => u.id === req.params.assetId);
  if (!m) { res.status(404).json({ error: 'Asset not found in PI' }); return; }
  res.json({
    source: 'PI_HISTORIAN',
    asset_id: req.params.assetId,
    timestamp: new Date().toISOString(),
    readings: [
      { tag: `${req.params.assetId}.Vibration`,   value: (m as any).vib,    unit: 'mm/s',  quality: 'GOOD' },
      { tag: `${req.params.assetId}.Temperature`, value: (m as any).temp,   unit: '°C',    quality: 'GOOD' },
      { tag: `${req.params.assetId}.Health`,      value: (m as any).health, unit: '%',     quality: 'GOOD' },
      { tag: `${req.params.assetId}.RUL`,         value: (m as any).rul,    unit: 'days',  quality: 'GOOD' },
    ],
  });
});

// ── /source/mes — MES / SAP PP ────────────────────────────────────────────────
sourceRouter.get('/mes/orders', (_req, res) => {
  // REPLACE WITH: SAP PP OData /ProductionOrders
  const orders = loadProductionOrders() as any[];
  res.json({ source: 'SAP_PP_MES', source_mode: SOURCE_MODE_MAP['SAP_PP_MES'], count: orders.length, orders });
});

sourceRouter.get('/mes/yield-params', (_req, res) => {
  // REPLACE WITH: OPC-UA real-time DCS tag values
  const params = loadYieldParams() as any[];
  const state = getPlantState();
  const liveParams = new Map(state.yieldParams.map(p => [p.id, p]));
  res.json({
    source: 'OPC_UA_DCS',
    count: params.length,
    params: params.map((p: any) => ({
      ...p,
      live_value: liveParams.get(p.id)?.val ?? p.val,
      live_warn:  liveParams.get(p.id)?.warn ?? false,
      as_of:      new Date().toISOString(),
    })),
  });
});

// ── /source/sap — SAP PM Work Orders ────────────────────────────────────────
sourceRouter.get('/sap/workorders', (_req, res) => {
  // REPLACE WITH: SAP PM OData /MaintenanceOrders
  const wos = loadWorkOrders() as any[];
  res.json({ source: 'SAP_PM', count: wos.length, workorders: wos });
});

sourceRouter.get('/sap/parts', (_req, res) => {
  // REPLACE WITH: SAP MM OData /Materials + stock levels
  const { orders, inventory } = loadParts();
  res.json({ source: 'SAP_MM', orders, inventory });
});

// ── /source/lims — LabVantage LIMS ───────────────────────────────────────────
sourceRouter.get('/lims/results', (_req, res) => {
  // REPLACE WITH: LabVantage REST API /samples
  const results = loadLimsResults() as any[];
  res.json({ source: 'LIMS_LABVANTAGE', source_mode: SOURCE_MODE_MAP['LIMS_LABVANTAGE'], count: results.length, results });
});

// ── /source/ehs — EHS / PTW System ──────────────────────────────────────────
sourceRouter.get('/ehs/permits', (_req, res) => {
  // REPLACE WITH: EHS system REST API /permits
  const permits = loadSafetyPermits() as any[];
  res.json({ source: 'EHS_SYSTEM', count: permits.length, permits });
});

sourceRouter.get('/ehs/zones', (_req, res) => {
  // REPLACE WITH: DCS zone sensor API
  const zones = loadSafetyZones() as any[];
  const state = getPlantState();
  const liveZones = new Map(state.safetyZones.map(z => [z.zone, z]));
  res.json({
    source: 'EHS_SENSOR_NETWORK',
    count: zones.length,
    zones: zones.map((z: any) => ({
      ...z,
      live: liveZones.get(z.zone_id) ?? null,
      as_of: new Date().toISOString(),
    })),
  });
});

// ── /source/qm — SAP QM / Vision AI ─────────────────────────────────────────
sourceRouter.get('/qm/defects', (_req, res) => {
  // REPLACE WITH: Vision AI inference API + SAP QM NCR feed
  const defects = loadQualityDefects() as any[];
  res.json({ source: 'VISION_AI_SAP_QM', count: defects.length, defects });
});

sourceRouter.get('/qm/lines', (_req, res) => {
  // REPLACE WITH: MES line quality reporting API
  const lines = loadQualityLines() as any[];
  res.json({ source: 'MES_QUALITY', count: lines.length, lines });
});

// ── /source/erp — ERP Supplier Risk ─────────────────────────────────────────
sourceRouter.get('/erp/suppliers', (_req, res) => {
  // REPLACE WITH: ERP supplier master + external risk API
  const risks = loadSupplyRisks() as any[];
  res.json({ source: 'ERP_SUPPLIER_RISK', count: risks.length, suppliers: risks });
});

// ── /source/scada — SCADA / Smart Meter ─────────────────────────────────────
sourceRouter.get('/scada/energy', (_req, res) => {
  // REPLACE WITH: Azure IoT Hub / smart meter telemetry API
  const assets = loadEnergyAssets() as any[];
  const hourly = loadEnergyHourly();
  const state  = getPlantState();
  const liveMap = new Map(state.energyAssets.map(a => [a.id, a]));
  res.json({
    source: 'SCADA_IOT_HUB',
    assets: assets.map((a: any) => ({
      ...a,
      live_kw:  liveMap.get(a.id)?.kw ?? a.rated_kw,
      anomaly:  liveMap.get(a.id)?.anomaly ?? false,
      as_of:    new Date().toISOString(),
    })),
    hourly_profile: hourly,
  });
});

// ── /source/status — Ingestion layer health ───────────────────────────────────
// Source mode map — change CSV/env to flip individual sources to real connectors
const SOURCE_MODE_MAP: Record<string, 'Synthetic' | 'CSV' | 'Connector' | 'Live'> = {
  PI_HISTORIAN:     (process.env.PI_WEB_API_URL     ? 'Connector' : 'Synthetic'),
  SAP_PP_MES:       (process.env.SAP_ODATA_BASE_URL ? 'CSV'       : 'Synthetic'),
  SAP_PM:           (process.env.SAP_ODATA_BASE_URL ? 'CSV'       : 'Synthetic'),
  SAP_MM:           (process.env.SAP_ODATA_BASE_URL ? 'CSV'       : 'Synthetic'),
  LIMS_LABVANTAGE:  (process.env.LIMS_BASE_URL      ? 'Connector' : 'CSV'),
  EHS_SYSTEM:       'CSV',
  VISION_AI_SAP_QM: 'CSV',
  ERP_SUPPLIER_RISK:'CSV',
  SCADA_IOT_HUB:    (process.env.IOT_HUB_CONNECTION_STRING ? 'Live' : 'Synthetic'),
};

sourceRouter.get('/status', (_req, res) => {
  const sources = [
    { id: 'PI_HISTORIAN',    name: 'OSIsoft PI Historian',   latency_ms: 4000 },
    { id: 'SAP_PP_MES',      name: 'SAP PP / MES',           latency_ms: 0    },
    { id: 'SAP_PM',          name: 'SAP PM (Work Orders)',    latency_ms: 0    },
    { id: 'SAP_MM',          name: 'SAP MM (Materials)',      latency_ms: 0    },
    { id: 'LIMS_LABVANTAGE', name: 'LabVantage LIMS',        latency_ms: 0    },
    { id: 'EHS_SYSTEM',      name: 'EHS / PTW System',       latency_ms: 0    },
    { id: 'VISION_AI_SAP_QM',name: 'Vision AI + SAP QM',    latency_ms: 0    },
    { id: 'ERP_SUPPLIER_RISK',name:'ERP Supplier Risk',      latency_ms: 0    },
    { id: 'SCADA_IOT_HUB',   name: 'SCADA / Azure IoT Hub', latency_ms: 4000 },
  ].map(s => ({
    ...s,
    status:      'connected',
    source_mode: SOURCE_MODE_MAP[s.id] ?? 'Synthetic',
    mode:        (SOURCE_MODE_MAP[s.id] ?? 'Synthetic').toLowerCase(),
  }));

  res.json({
    ingestion_layer: 'healthy',
    sources,
    source_mode_legend: {
      Synthetic:  'Data generated by simulation engine — no external dependency',
      CSV:        'Data loaded from data/csv/*.csv — edit file to change values',
      Connector:  'Data from a real enterprise connector (OPC-UA, SAP OData etc)',
      Live:       'Real-time IoT / sensor stream (Azure IoT Hub or similar)',
    },
    note: 'Replace each loader with real connector for Phase 3.',
  });
});
