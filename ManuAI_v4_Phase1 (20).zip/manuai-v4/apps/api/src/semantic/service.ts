import { EventEmitter } from 'events';
import { loadConflictRules } from '../data/csv-loader';
import { persistSemanticEvent, persistEventImpact, getRecentEvents as getStoredEvents } from '../database/event-store';
import { logger } from '../middleware/logger';
import { broadcastEvent } from '../websocket/broadcaster';

export type AgentId = 'oee' | 'yield' | 'pdm' | 'quality' | 'energy' | 'supply' | 'twin' | 'safety';

export interface CrossAgentEvent {
  id: string; from: AgentId | string; to: AgentId | string;
  type: string; sev: 'critical' | 'warning' | 'info';
  msg: string; impact: string; asset: string; ts: string;
}

export interface AgentAction {
  agent: AgentId; type: string; assetId?: string; tagId?: string;
}

// KPI definitions loaded from semantic_kpi_definitions.csv (seeded to DB at startup)
// Source: data/csv/semantic_kpi_definitions.csv — edit there to change definitions
// REPLACE WITH: Azure App Configuration or admin UI in Phase 2
import { loadSemanticKpiDefs } from '../data/csv-loader';
import { getDb } from '../database/connection';

function loadKpiDefinitionsFromDb(): Record<string, any> {
  try {
    const rows = getDb().prepare('SELECT * FROM semantic_kpi_definition').all() as any[];
    if (rows.length === 0) throw new Error('empty');
    const result: Record<string, any> = {};
    for (const r of rows) {
      result[r.kpi_id] = {
        name:    r.kpi_name,
        formula: r.formula,
        unit:    r.unit,
        agents:  r.agents.split(','),
        src:     r.source_system,
        governance: r.governance,
      };
    }
    return result;
  } catch {
    // Fallback to CSV if DB not ready yet
    const defs = loadSemanticKpiDefs();
    const result: Record<string, any> = {};
    for (const d of defs as any[]) {
      result[d.id] = { name: d.name, formula: d.formula, unit: d.unit,
        agents: Array.isArray(d.agents) ? d.agents : d.agents.split(';'),
        src: d.src, governance: d.governance };
    }
    return result;
  }
}

let _kpiDefsCache: Record<string, any> | null = null;
export function getKpiDefinitions(): Record<string, any> {
  if (!_kpiDefsCache) _kpiDefsCache = loadKpiDefinitionsFromDb();
  return _kpiDefsCache;
}
export function reloadKpiDefinitions(): void { _kpiDefsCache = null; }

// Legacy export for backward compat — lazy loaded from CSV/DB
export const KPI_DEFINITIONS = new Proxy({} as Record<string, any>, {
  get: (_t, key: string) => getKpiDefinitions()[key],
  ownKeys: () => Object.keys(getKpiDefinitions()),
  getOwnPropertyDescriptor: () => ({ configurable: true, enumerable: true }),
});

// Conflict rules loaded from conflict_rules.csv — no hardcoded rules
// REPLACE WITH: CMMS conflict rule API in Phase 3
let _conflictRulesCache: ReturnType<typeof loadConflictRules> | null = null;
function getConflictRules() {
  if (!_conflictRulesCache) _conflictRulesCache = loadConflictRules();
  return _conflictRulesCache;
}

// Active faults: Map<"ruleId::assetId", { since, assetId, zoneId? }>
// Key is scoped: "CR-001::MCH-06" — asset-specific blocking
const activeFaults = new Map<string, { since: Date; assetId: string; zoneId?: string }>();

class SemanticLayerService {
  private emitter = new EventEmitter();
  private recentEvents: CrossAgentEvent[] = [];
  private _cache = new Map<string, { val: unknown; exp: number }>();

  constructor() {
    this.emitter.setMaxListeners(50);
    logger.info('[Semantic] Using in-memory event bus (Redis inactive)');
  }

  getKPIDefinitions() { return getKpiDefinitions(); }

  registerFault(ruleId: string, assetId: string, zoneId?: string): void {
    activeFaults.set(`${ruleId}::${assetId}`, { since: new Date(), assetId, zoneId });
    logger.info('Semantic Layer: fault registered', { ruleId, assetId, zoneId });
  }

  resolveFault(ruleId: string, assetId: string): void {
    activeFaults.delete(`${ruleId}::${assetId}`);
    logger.info('Semantic Layer: fault resolved', { ruleId, assetId });
  }

  getActiveFaults(): Array<{ key: string; ruleId: string; assetId: string; since: Date }> {
    return Array.from(activeFaults.entries()).map(([key, v]) => ({
      key, ruleId: key.split('::')[0], assetId: v.assetId, since: v.since,
    }));
  }

  checkConflict(action: AgentAction): { blocked: boolean; reason?: string; ruleId?: string } {
    const rules = getConflictRules();
    for (const rule of rules) {
      if (rule.blockAgent !== action.agent) continue;
      if (rule.blockActionType !== action.type) continue;
      for (const [faultKey, fault] of activeFaults) {
        if (!faultKey.startsWith(rule.id)) continue;
        // Asset-scoped: only block if same asset (or global rule)
        if (rule.assetScope === 'asset' && action.assetId && fault.assetId !== action.assetId) continue;
        // Zone-scoped: only block if same zone
        if (rule.assetScope === 'zone' && action.assetId && fault.zoneId && fault.zoneId !== action.assetId) continue;
        return { blocked: true, reason: rule.reason, ruleId: rule.id };
      }
    }
    return { blocked: false };
  }

  async publishEvent(event: CrossAgentEvent): Promise<void> {
    // Persist to SQLite first — full audit trail
    persistSemanticEvent(event);
    // Keep in-memory for fast reads
    this.recentEvents.unshift(event);
    if (this.recentEvents.length > 500) this.recentEvents = this.recentEvents.slice(0, 500);
    this.emitter.emit('cross_agent_event', event);
    broadcastEvent(event as unknown as Record<string, unknown>);
    logger.info('Semantic event', { type: event.type, from: event.from, to: event.to });
  }

  async getRecentEvents(limit = 50): Promise<CrossAgentEvent[]> {
    try {
      // Read from SQLite for persistence across restarts
      const stored = getStoredEvents(limit);
      if (stored.length > 0) {
        return stored.map((r: any) => ({
          ...JSON.parse(r.payload ?? '{}'),
          id: r.event_id, type: r.event_type,
          from: r.from_agent, asset: r.asset_id,
          sev: r.severity, msg: r.message, ts: new Date(r.ts).toISOString(),
        }));
      }
    } catch { /* fall through to in-memory */ }
    return this.recentEvents.slice(0, limit);
  }

  async cache<T>(key: string, ttl: number, fn: () => Promise<T>): Promise<T> {
    const cached = this._cache.get(key);
    if (cached && Date.now() < cached.exp) return cached.val as T;
    const val = await fn();
    this._cache.set(key, { val, exp: Date.now() + ttl * 1000 });
    return val;
  }
}

export const semanticLayer = new SemanticLayerService();
