import React,{useState,useEffect,useRef,useCallback}from'react';
import{AppProvider,useApp}from'./context';
import{useStore}from'./store';
import{aiApi,getSocket,subscribeChannels}from'./api';
import{fetchMachines,fetchUtilities,fetchYieldParams,fetchDcsSetpoints,fetchLims,fetchProductionOrders,fetchWorkOrders,fetchSupplyRisks,fetchAlerts,fetchOeeTrend,fetchSixLosses,fetchLossTrend,fetchRulTrend,fetchSensorHistory,fetchOeeScorecard,fetchShifts,fetchTwinComponents,fetchParts,fetchEnergySpend,fetchPlatformConfig,fetchEnergyWaste,fetchCarbonTrend,fetchDemandForecast,fetchEnergyDispatch,fetchTwinScenarios,fetchDivergenceLog,fetchQualityDefects,fetchQualityLines,fetchSafetyPermits,fetchSafetyEvents,fetchEnergyAssets,fetchEnergyTrend,fetchTechStack,fetchSemanticKpiDefs,fetchPersonas,fetchBaselines,fetchPdmRules}from'./csvApi';
import{LineChart,Line,BarChart,Bar,AreaChart,Area,ComposedChart,PieChart,Pie,Cell,ScatterChart,Scatter,ZAxis,XAxis,YAxis,CartesianGrid,Tooltip,Legend,ResponsiveContainer,ReferenceLine}from'recharts';
import{T,tt,hc,sc}from'./tokens';
import{Bdg,AgChip,Kpi,Card,CH,Btn,HR,MTag,OeeGauge,FeatBar,LayerBar,Divider,RetBtn,SpecHeader,TabBar}from'./ui';
// All data comes from API — no static fallbacks from data.ts
// Initial useState values are empty arrays/objects; API data populates them on mount
const MACHINES:any[]=[],UTIL:any[]=[],DT_COMPS:any={},
  SIX_LOSSES:any[]=[],OEE_TREND:any[]=[],LOSS_TREND:any[]=[],RUL_TREND:any[]=[],
  SENSOR_H:any[]=[{t:'00:00',vib:0,tmp:0}],YIELD_PARAMS:any[]=[],LIMS:any[]=[],
  DCS_INIT:any[]=[],SAP_ORDERS:any[]=[],BENCHMARK:any[]=[],
  YIELD_FEATS:any[]=[],PDM_FEATS:any[]=[],MODEL_YIELD:any[]=[],MODEL_PDM:any[]=[],
  WO_INIT:any[]=[],PARTS_INIT:any[]=[],PARTS_INV:any[]=[],SPEND_TREND:any[]=[],
  SUPPLIER_PERF:any[]=[],SHIFTS:any[]=[],CROSS_EVENTS:any[]=[],ALERT_INIT:any[]=[],
  OEE_SCORECARD:any[]=[],ADOPTION_TREND:any[]=[],SCATTER_DATA:any[]=[],  // unused — twin_kpis served via fetchDivergenceLog
  SEMANTIC_KPI:any={};

/* NAV */
const NAV=[
  {id:'overview',icon:'⬡',label:'Unified Overview',accent:T.sem,section:'PLATFORM'},
  {id:'semantic',icon:'∿',label:'Semantic Layer',accent:T.sem,section:'PLATFORM'},
  {id:'oee',icon:'📊',label:'OEE Visibility',accent:T.oee,section:'OPERATIONS'},
  {id:'yield',icon:'⚗️',label:'Yield Optimisation',accent:T.yield,section:'OPERATIONS'},
  {id:'pdm',icon:'🔩',label:'Predictive Maint.',accent:T.pdm,section:'OPERATIONS'},
  {id:'quality',icon:'👁',label:'Quality Vision',accent:T.quality,section:'OPERATIONS'},
  {id:'energy',icon:'⚡',label:'Energy Optimisation',accent:T.energy,section:'SUSTAINABILITY'},
  {id:'supply',icon:'🚢',label:'Supply Chain',accent:T.supply,section:'SUSTAINABILITY'},
  {id:'twin',icon:'🔮',label:'Digital Twin Ops',accent:T.twin,section:'ADVANCED'},
  {id:'safety',icon:'🦺',label:'Safety & Compliance',accent:T.safety,section:'ADVANCED'},
];
const SEC_COLS={PLATFORM:T.sem,OPERATIONS:T.oee,SUSTAINABILITY:T.supply,ADVANCED:T.safety};
const SECS=['PLATFORM','OPERATIONS','SUSTAINABILITY','ADVANCED'];
const scroll={padding:18,overflowY:'auto',height:'100%',display:'flex',flexDirection:'column',gap:14};

/* EXTRA MOCK DATA */
// ENERGY_TREND loaded from fetchEnergyTrend()
// ENERGY_ASSETS loaded from CSV via fetchEnergyAssets()
// const ENERGY_WASTE loaded from API
// const CARBON_TREND loaded from API
// const SUPPLY_RISKS loaded from API
// const DEMAND_FORECAST loaded from API
// const DEFECT_TREND loaded from API
// const DEFECT_LOG loaded from API
// const SAFETY_EVENTS loaded from API
// const PTW_LIST loaded from API
// const TWIN_SCENARIOS loaded from API
// const DIVERGENCE_LOG loaded from API
// const QUALITY_LINES loaded from API
// EXTENDED_SEMANTIC built from semantic_kpi_definitions.csv
const buildExtendedSemantic=(defs:any[])=>{
  const result:Record<string,any>={};
  for(const d of defs){
    result[d.id]={name:d.name,formula:d.formula,unit:d.unit,agents:d.agents,src:d.src};
  }
  return result;
};
const EXTENDED_SEMANTIC:Record<string,any>={}; // populated reactively via useSharedCfg in SemanticLayer

// Shared config — reads from React Context (AppProvider)
const _sharedCfg:{cfg:any,appCfg:any,baselines:any,techStacks:any}=
  {cfg:{},appCfg:{},baselines:{},techStacks:{}};
function useSharedCfg(){
  const ctx=useApp();
  // Keep _sharedCfg in sync for legacy callers
  _sharedCfg.cfg=ctx.appCfg;
  _sharedCfg.appCfg=ctx.appCfg;
  _sharedCfg.baselines=ctx.baselines;
  _sharedCfg.techStacks=ctx.techStacks;
  return{cfg:ctx.appCfg,appCfg:ctx.appCfg,baselines:ctx.baselines,techStacks:ctx.techStacks};
}

function AgentPage({quarter,title,tags,target,accentCol,tabs,activeTab,setActiveTab,children}){
  return(
    <div style={{height:'100%',display:'flex',flexDirection:'column',background:T.bg}}>
      <SpecHeader quarter={quarter} title={title} tags={tags} target={target} accentCol={accentCol}/>
      <TabBar tabs={tabs} active={activeTab} onSelect={setActiveTab} col={accentCol}/>
      <div style={{flex:1,overflow:'hidden'}}>{children}</div>
    </div>
  );
}

/* UNIFIED OVERVIEW */
function UnifiedOverview(){
  const{energyWaste,supplyRisksData,ptwList,divergenceLog,qualityLines,agsMachines,agsOee,critical,agsYield,crossEvents,mch,oeeTrend,sixLosses,lossTrend,oeeScorecard}=useApp();

  const{fetchMachines}=useStore();
  useEffect(()=>{
    fetchMachines();
    const iv=setInterval(fetchMachines,4000);
    return()=>clearInterval(iv);
  },[]);

  const pOEE=(mch.reduce((s,m)=>s+m.oee,0)/mch.length).toFixed(1);
  const agsCrit=(agsMachines as any[]).filter((m:any)=>m.status==='critical').length;
  const agsMinRul=(agsMachines as any[]).reduce((n:number,m:any)=>Math.min(n,Number(m.rul??999)),999);
  const agsWarnY=(agsYield as any[]).filter((p:any)=>p.warn).length;
  const AGS=[
    {label:'OEE',val:agsOee+'%',col:T.oee,sub:'target 85%'},
    {label:'Yield',val:agsWarnY+' params warn',col:T.yield,sub:'from DCS params'},
    {label:'Fleet Health',val:agsCrit+' critical',col:T.pdm,sub:'min RUL '+agsMinRul+'d'},
    {label:'Quality Rate',val:qualityLines.length?+(qualityLines.reduce((s:number,l:any)=>s+Number(l.rate??0),0)/qualityLines.length).toFixed(1)+'%':'--',col:T.quality,sub:'avg all lines'},
    {label:'Energy Cost',val:energyWaste.length?energyWaste.length+' patterns':'—',col:T.energy,sub:'waste detected'},
    {label:'Supply Risk',val:supplyRisksData.filter((r:any)=>r.risk==='critical'||r.risk==='high').length+' HIGH',col:T.supply,sub:'shortfall alerts'},
    {label:'Twin Divergence',val:divergenceLog.filter((d:any)=>d.status==='diverging').length+' KPIs',col:T.twin,sub:'vs digital twin'},
    {label:'Safety Events',val:ptwList.filter((p:any)=>p.status==='pending').length+' PTW',col:T.safety,sub:'permits pending'},
  ];
  return(
    <div style={scroll}>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
        {AGS.map(a=><Kpi key={a.label} label={a.label} value={a.val} sub={a.sub} color={a.col} accent={a.col}/>)}
      </div>
      <Card>
        <CH title="OEE x Yield x Asset Health - Cross-Agent Correlation" sub={`Semantic Layer: ${crossEvents.length>0?(crossEvents as any[])[0]?.msg??'Cross-agent correlation active':'No recent cross-agent events'}`} right={<Bdg label="Semantic Layer" color={T.sem}/>}/>
        <ResponsiveContainer width="100%" height={150}>
          <ComposedChart data={oeeTrend}>
            <CartesianGrid strokeDasharray="3 3" stroke={T.border}/>
            <XAxis dataKey="day" tick={{fill:T.m2,fontSize:10}}/><YAxis yAxisId="l" domain={[68,93]} tick={{fill:T.m2,fontSize:10}}/><YAxis yAxisId="r" orientation="right" domain={[40,85]} tick={{fill:T.m2,fontSize:10}}/>
            <Tooltip {...tt}/>
            <Area yAxisId="l" type="monotone" dataKey="oee" stroke={T.oee} fill={T.oee+'18'} strokeWidth={2} name="OEE %"/>
            <Line yAxisId="l" type="monotone" dataKey="yld" stroke={T.yield} strokeWidth={2} dot={false} strokeDasharray="4 2" name="Yield %"/>
            <Line yAxisId="r" type="monotone" dataKey="health" stroke={T.pdm} strokeWidth={2} dot={false} strokeDasharray="4 4" name="Fleet Health %"/>
            <ReferenceLine yAxisId="l" y={85} stroke={T.green} strokeDasharray="3 3" label={{value:'Target',fill:T.green,fontSize:9}}/>
            <Legend wrapperStyle={{fontSize:11}}/>
          </ComposedChart>
        </ResponsiveContainer>
      </Card>
      <Card>
        <CH title="Machine Fleet - All 8 Assets (live 3.5s)" sub="OEE Agent + PdM Agent shared universe"/>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:9}}>
          {mch.map(m=>{
            const stC=sc(m.status),oeeC=m.oee>=85?T.green:m.oee>=75?T.amber:T.red;
            return(
              <div key={m.id} style={{background:T.s2,border:`1px solid ${m.status==='critical'?T.red+'40':T.border}`,borderLeft:`3px solid ${stC}`,borderRadius:10,padding:'10px 12px'}}>
                <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:6}}>
                  <div><div style={{fontSize:11,fontWeight:700}}>{m.name}</div><div style={{fontSize:9,color:T.m2}}>{m.id}</div></div>
                  <HR value={m.health} size={40}/>
                </div>
                <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:4,marginBottom:4}}>
                  {[['OEE',m.oee,oeeC],['A',m.avail,T.green],['P',m.perf,T.amber],['Q',m.qual,T.oee]].map(([k,v,c])=>(
                    <div key={k} style={{textAlign:'center',background:T.surface,borderRadius:4,padding:'3px 2px',border:`1px solid ${T.border}`}}>
                      <div style={{fontSize:9,color:T.m2}}>{k}</div><div style={{fontSize:10,fontWeight:700,color:c}}>{v}%</div>
                    </div>
                  ))}
                </div>
                <div style={{fontSize:9,color:T.m2}}>RUL: <span style={{color:m.rul<15?T.red:m.rul<40?T.amber:T.green,fontWeight:700}}>{m.rul}d</span></div>
              </div>
            );
          })}
        </div>
      </Card>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Card>
          <CH title="OEE Gap Attribution" sub="Cross-agent root cause via Semantic Layer" right={<Bdg label="Semantic" color={T.sem}/>}/>
          {(()=>{
            // Compute gap attribution from live machine loss data
            const ms=agsMachines as any[];
            const total=ms.reduce((s:number,m:any)=>s+Number(m.lossMin??0),0)||100;
            const breakdown=[
              {k:'Asset degradation',v:ms.filter((m:any)=>m.loss==='Unplanned Breakdown'||m.loss==='Speed Loss').reduce((s:number,m:any)=>s+Number(m.lossMin??0),0),c:T.pdm},
              {k:'Process params',v:ms.filter((m:any)=>m.loss==='Minor Stops').reduce((s:number,m:any)=>s+Number(m.lossMin??0),0),c:T.yield},
              {k:'In-process defects',v:ms.filter((m:any)=>m.loss==='In-process Defects').reduce((s:number,m:any)=>s+Number(m.lossMin??0),0),c:T.oee},
              {k:'Other',v:ms.filter((m:any)=>!['Unplanned Breakdown','Speed Loss','Minor Stops','In-process Defects'].includes(m.loss)).reduce((s:number,m:any)=>s+Number(m.lossMin??0),0),c:T.m2},
            ].filter(b=>b.v>0);
            const src=breakdown.length?breakdown:[
              {k:'Asset degradation',v:42,c:T.pdm},{k:'Process params',v:21,c:T.yield},
              {k:'In-process defects',v:18,c:T.oee},{k:'Other',v:8,c:T.m2},
            ];
            const tot=src.reduce((s,b)=>s+b.v,0)||1;
            return src.map(({k,v,c})=>(
              <div key={k} style={{marginBottom:9}}>
                <div style={{display:'flex',justifyContent:'space-between',fontSize:11,marginBottom:3}}><span style={{fontWeight:600}}>{k}</span><span style={{color:c,fontWeight:700}}>{(v/tot*100).toFixed(1)}%</span></div>
                <div style={{height:5,background:T.s3,borderRadius:3}}><div style={{height:5,width:`${(v/tot*100)}%`,background:c,borderRadius:3}}/></div>
              </div>
            ));
          })()}
        </Card>
        <Card>
          <CH title="Active Cross-Agent Events" sub="Semantic Layer event bus"/>
          {(crossEvents as any[]).slice(0,4).map((e:any)=>{
            const col={critical:T.red,warning:T.amber,info:T.sem}[e.sev]||T.m2;
            return(
              <div key={e.id} style={{display:'flex',alignItems:'center',gap:8,padding:'7px 10px',background:T.s2,borderRadius:7,borderLeft:`3px solid ${col}`,marginBottom:6}}>
                <AgChip agent={e.from}/><span style={{fontSize:9,color:T.m2}}>→</span><AgChip agent={e.to}/>
                <span style={{fontSize:10,flex:1,color:T.txt2,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{e.msg}</span>
                <span style={{fontSize:10,fontWeight:700,color:col,whiteSpace:'nowrap',flexShrink:0}}>{e.impact}</span>
              </div>
            );
          })}
        </Card>
      </div>
    </div>
  );
}

/* SEMANTIC LAYER */
function SemanticLayer(){
  const{crossEvents}=useApp();
  const[sel,setSel]=useState('oee');
  const{cfg:shCfg}=useSharedCfg();
  // Semantic KPIs: live values from store, definitions from platform_config.csv
  const{machines:semMachines,yieldParams:semYield}=useStore();
  const liveSemantic=React.useMemo(()=>{
    const base=shCfg.semanticKpi??{};
    // Override values with live computed data where available
    const avgOee=(semMachines as any[]).length
      ? +((semMachines as any[]).reduce((s:number,m:any)=>s+Number(m.oee??0),0)/(semMachines as any[]).length).toFixed(1)
      : Number(base.oee?.value??0);
    const avgHealth=(semMachines as any[]).length
      ? +((semMachines as any[]).reduce((s:number,m:any)=>s+Number(m.health??0),0)/(semMachines as any[]).length).toFixed(1)
      : Number(base.asset_health?.value??0);
    const minRul=(semMachines as any[]).length
      ? Math.min(...(semMachines as any[]).map((m:any)=>Number(m.rul??999)))
      : Number(base.rul_days?.value??0);
    return {...SEMANTIC_KPI,...EXTENDED_SEMANTIC,
      ...(Object.keys(base).length ? Object.fromEntries(
        Object.entries(base).map(([k,v]:any)=>[k,{...SEMANTIC_KPI[k as keyof typeof SEMANTIC_KPI],...v,
          value: k==='oee'?avgOee : k==='asset_health'?avgHealth : k==='rul_days'?minRul : v.value
        }])
      ) : {})
    };
  },[shCfg,semMachines,semYield]);
  const allK=liveSemantic;
  const k=allK[sel];
  const evCol={critical:T.red,warning:T.amber,info:T.sem};
  return(
    <div style={scroll}>
      <CH title="AI Semantic Layer - Unified KPI Dictionary & Event Bus" sub={`${Object.keys(allK).length} KPIs governed across all 9 agents`} right={<Bdg label="All 9 agents" color={T.sem}/>}/>
      <div style={{background:T.sDim,border:`1px solid ${T.sem}25`,borderRadius:10,padding:'12px 16px'}}>
        <div style={{fontSize:12,fontWeight:700,color:T.sem,marginBottom:8}}>What the Semantic Layer delivers</div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12}}>
          {[['One number everywhere','OEE, yield, defect rate identical for shop floor, finance and executive across all plants.'],['Conflict resolution','PdM fault blocks Yield recs. Safety precursor pauses hot-work PTW. Cross-agent safety net.'],['Causal attribution','Traces CHP-002 chiller to MCH-01 speed loss to OEE to yield drop across 9 agents.'],['NL query layer','Which supplier has >30d lead drift AND financial distress? Answered in plain English, no SQL.']].map(([t,d])=>(
            <div key={t}><div style={{fontSize:11,fontWeight:700,color:T.txt,marginBottom:4}}>{t}</div><div style={{fontSize:11,color:T.m2,lineHeight:1.5}}>{d}</div></div>
          ))}
        </div>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'220px 1fr',gap:12}}>
        <div>
          <div style={{fontSize:10,fontWeight:800,color:T.m2,marginBottom:8,letterSpacing:1,textTransform:'uppercase'}}>KPI Dictionary</div>
          {Object.entries(allK).map(([id,kpi])=>(
            <div key={id} onClick={()=>setSel(id)} style={{background:T.surface,border:`1px solid ${sel===id?T.sem+'60':T.border}`,borderLeft:`3px solid ${T.sem}`,borderRadius:8,padding:'9px 11px',marginBottom:5,cursor:'pointer',boxShadow:sel===id?`0 0 0 2px ${T.sem}20`:'0 1px 3px rgba(0,0,0,.04)'}}>
              <div style={{fontSize:11,fontWeight:700,color:T.txt}}>{kpi.name}</div>
              <div style={{fontSize:9,color:T.m2}}>{kpi.agents.join(' + ')} - {kpi.unit}</div>
            </div>
          ))}
        </div>
        {k&&(
          <Card>
            <div style={{fontSize:15,fontWeight:800,color:T.sem,marginBottom:10}}>{k.name}</div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:10}}>
              {[['Formula',k.formula,T.oee,true],['Source Systems',k.src,T.txt,false],['Unit',k.unit,T.txt,false],['Consumed By',k.agents.join(', '),T.sem,false]].map(([lbl,val,col,mono])=>(
                <div key={lbl} style={{background:T.s2,borderRadius:8,padding:'10px 12px',border:`1px solid ${T.border}`}}>
                  <div style={{fontSize:9,color:T.m2,textTransform:'uppercase',letterSpacing:'0.5px',marginBottom:4}}>{lbl}</div>
                  <div style={{fontSize:12,fontWeight:600,color:col,fontFamily:mono?'monospace':'inherit'}}>{val}</div>
                </div>
              ))}
            </div>
            <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>{k.agents.map(a=><AgChip key={a} agent={a}/>)}</div>
          </Card>
        )}
      </div>
      <CH title="Cross-Agent Event Bus - Live Log" sub="Real-time events between all 9 agents"/>
      {(crossEvents as any[]).map((e:any)=>{
        const col=evCol[e.sev]||T.m2;
        return(
          <div key={e.id} style={{background:T.surface,border:`1px solid ${col+'30'}`,borderLeft:`3px solid ${col}`,borderRadius:9,padding:'11px 14px',marginBottom:8}}>
            <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:6,flexWrap:'wrap'}}>
              <MTag text={e.id} color={col}/><AgChip agent={e.from}/><span style={{fontSize:10,color:T.m2}}>→</span><AgChip agent={e.to}/>
              <Bdg label={e.type.replace(/_/g,' ')} color={col} sm/><Bdg label={e.asset} color={T.m3} sm/>
              <span style={{marginLeft:'auto',fontSize:10,color:T.m2}}>{e.ts}</span>
            </div>
            <div style={{fontSize:11,color:T.txt,lineHeight:1.55,marginBottom:4}}>{e.msg}</div>
            <div style={{fontSize:11,fontWeight:700,color:col}}>Impact: {e.impact}</div>
          </div>
        );
      })}
    </div>
  );
}

/* OEE AGENT */
function OeeAgent(){
  const[tab,setTab]=useState('dashboard');
  const[alerts,setAlerts]=useState(ALERT_INIT);
  useEffect(()=>{fetchAlerts().then(d=>{if(d.length)setAlerts(d as any);}).catch(()=>{});},[]);
  const ack=id=>setAlerts(as=>as.map(a=>a.id===id?{...a,ack:true}:a));
  return(
    <AgentPage quarter="Q2" title="OEE Visibility & Alerting Agent" tags={['MES','SCADA','PLC']} target="Target: +10-15% OEE in 90 days" accentCol={T.oee}
      tabs={[['dashboard','Dashboard'],['losses','Six Big Losses'],['alerts','Alerts & Routing'],['scorecard','Scorecard']]} activeTab={tab} setActiveTab={setTab}>
      {tab==='dashboard'&&<OeeDash/>}
      {tab==='losses'&&<OeeLosses/>}
      {tab==='alerts'&&<OeeAlerts alerts={alerts} ack={ack}/>}
      {tab==='scorecard'&&<OeeScorecard/>}
    </AgentPage>
  );
}
function OeeDash(){
  const{agsMachines,agsOee,mch,oeeTrend,sixLosses}=useApp();
  const[oeeTrend2,setOeeTrend2]=useState(OEE_TREND);
  useEffect(()=>{
    fetchOeeTrend(30).then(d=>{if(d.length)setOeeTrend2(d as any);}).catch(()=>{});
  },[]);
  // live machine data comes from context via mch
  return(
    <div style={scroll}>
      <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:10}}>
        <Kpi label="Plant OEE" value={agsOee+"%"} delta="target 85%" up={false} color={T.oee} accent={T.oee}/>
        <Kpi label="Availability" value={(agsMachines as any[]).length?+((agsMachines as any[]).reduce((s:number,m:any)=>s+Number(m.avail??0),0)/(agsMachines as any[]).length).toFixed(1)+"%":"--"} delta="" up color={T.green} accent={T.oee}/>
        <Kpi label="Performance" value={(agsMachines as any[]).length?+((agsMachines as any[]).reduce((s:number,m:any)=>s+Number(m.perf??0),0)/(agsMachines as any[]).length).toFixed(1)+"%":"--"} delta="" up={false} color={T.amber} accent={T.oee}/>
        <Kpi label="Quality" value={(agsMachines as any[]).length?+((agsMachines as any[]).reduce((s:number,m:any)=>s+Number(m.qual??0),0)/(agsMachines as any[]).length).toFixed(1)+"%":"--"} delta="" up color={T.sem} accent={T.oee}/>
        <Kpi label="Loss Today" value={(agsMachines as any[]).length?(agsMachines as any[]).reduce((s:number,m:any)=>s+Number(m.lossMin??0),0)+" min":"-- min"} sub="6 categories" color={T.red} accent={T.oee}/>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Card>
          <CH title="OEE Trend - 7 Days" sub="vs 85% target"/>
          <ResponsiveContainer width="100%" height={140}>
            <AreaChart data={oeeTrend}>
              <defs><linearGradient id="ogg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={T.oee} stopOpacity={0.2}/><stop offset="95%" stopColor={T.oee} stopOpacity={0}/></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke={T.border}/>
              <XAxis dataKey="day" tick={{fill:T.m2,fontSize:10}}/><YAxis domain={[68,88]} tick={{fill:T.m2,fontSize:10}}/>
              <Tooltip {...tt}/><ReferenceLine y={85} stroke={T.green} strokeDasharray="4 4" label={{value:'Target',fill:T.green,fontSize:9}}/>
              <Area type="monotone" dataKey="oee" stroke={T.oee} fill="url(#ogg)" strokeWidth={2} name="OEE %"/>
            </AreaChart>
          </ResponsiveContainer>
        </Card>
        <Card>
          <CH title="Six Big Losses Today" sub="Auto-categorised from PLC event codes - zero manual logging"/>
          {sixLosses.map(l=>(
            <div key={l.name} style={{marginBottom:7}}>
              <div style={{display:'flex',justifyContent:'space-between',fontSize:11,marginBottom:3}}><span style={{fontWeight:600}}>{l.name}</span><span style={{color:l.col,fontWeight:700}}>{l.min}min ({l.pct}%)</span></div>
              <div style={{height:5,background:T.s3,borderRadius:3}}><div style={{height:5,width:`${l.pct*2}%`,background:l.col,borderRadius:3}}/></div>
            </div>
          ))}
        </Card>
      </div>
      <Card>
        <CH title="Machine-Level OEE - Live (3.5s refresh)" sub="Drill down Plant > Line > Machine"/>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:9}}>
          {mch.map(m=>{
            const stC=sc(m.status);
            return(
              <div key={m.id} style={{background:T.s2,border:`1px solid ${m.status==='critical'?T.red+'40':T.border}`,borderLeft:`3px solid ${stC}`,borderRadius:10,padding:'11px 12px'}}>
                <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:7}}>
                  <div><div style={{fontSize:11,fontWeight:700}}>{m.name}</div><div style={{fontSize:9,color:T.m2}}>{m.id}</div></div>
                  <OeeGauge value={m.oee} size={56}/>
                </div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:5,marginBottom:5}}>
                  {[['A',m.avail,T.green],['P',m.perf,T.amber],['Q',m.qual,T.oee]].map(([k,v,c])=>(
                    <div key={k} style={{textAlign:'center',background:T.surface,borderRadius:4,padding:'3px 2px',border:`1px solid ${T.border}`}}>
                      <div style={{fontSize:9,color:T.m2}}>{k}</div><div style={{fontSize:12,fontWeight:700,color:c}}>{v}%</div>
                    </div>
                  ))}
                </div>
                <div style={{fontSize:10,color:T.orange,fontWeight:600}}>Loss: {m.loss} {m.lossMin}min</div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
function OeeLosses(){
  const{sixLosses,lossTrend}=useApp();

  return(
    <div style={scroll}>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10}}>
        {sixLosses.map(l=>(
          <div key={l.name} style={{background:T.surface,border:`1px solid ${T.border}`,borderTop:`3px solid ${l.col}`,borderRadius:11,padding:'14px 15px',boxShadow:'0 1px 4px rgba(0,0,0,.05)'}}>
            <div style={{fontSize:12,fontWeight:700,color:l.col,marginBottom:7}}>{l.name}</div>
            <div style={{fontSize:28,fontWeight:800,letterSpacing:'-1px'}}>{l.min}<span style={{fontSize:12,color:T.m2}}> min</span></div>
            <div style={{fontSize:11,color:T.m2,marginTop:4}}>{l.cnt} events - {l.pct}% of total</div>
            <div style={{fontSize:10,color:T.m3,marginTop:4}}>Machines: {l.machines.join(', ')}</div>
          </div>
        ))}
      </div>
      <Card>
        <CH title="Loss Trend - 4 Weeks" sub="Week-on-week improvement since OEE agent deployment"/>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={lossTrend}>
            <CartesianGrid strokeDasharray="3 3" stroke={T.border}/>
            <XAxis dataKey="w" tick={{fill:T.m2,fontSize:10}}/><YAxis tick={{fill:T.m2,fontSize:10}}/>
            <Tooltip {...tt}/>
            <Bar dataKey="brk" fill={T.red} opacity={0.8} stackId="a" name="Breakdown"/>
            <Bar dataKey="chg" fill={T.amber} opacity={0.8} stackId="a" name="Changeover"/>
            <Bar dataKey="mst" fill="#ca8a04" opacity={0.8} stackId="a" name="Minor Stops"/>
            <Bar dataKey="spd" fill={T.orange} opacity={0.8} stackId="a" name="Speed Loss"/>
            <Bar dataKey="def" fill={T.blue} opacity={0.8} stackId="a" radius={[3,3,0,0]} name="Defects"/>
            <Legend wrapperStyle={{fontSize:10}}/>
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}
function OeeAlerts({alerts,ack}){
  const{critical}=useApp();
  return(
    <div style={scroll}>
      <div style={{background:T.sDim,border:`1px solid ${T.sem}25`,borderRadius:10,padding:'11px 14px'}}>
        <div style={{fontSize:12,fontWeight:700,color:T.sem,marginBottom:6}}>Contextual Routing Logic</div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
          {[['Unplanned Breakdown','Maintenance + SAP WO auto-created',T.red],['Speed Loss / Minor Stops','Operator + Supervisor notified',T.amber],['Changeover Overrun','Supervisor + IE team',T.orange],['Quality Defects','QC hold + Quality team',T.blue]].map(([t,a,c])=>(
            <div key={t} style={{background:T.surface,borderRadius:7,padding:'8px 10px',border:`1px solid ${T.border}`}}>
              <div style={{fontSize:10,fontWeight:700,color:c,marginBottom:3}}>{t}</div>
              <div style={{fontSize:10,color:T.m2}}>→ {a}</div>
            </div>
          ))}
        </div>
      </div>
      {alerts.map(a=>{
        const col={critical:T.red,warning:T.amber}[a.sev]||T.oee;
        return(
          <div key={a.id} style={{background:T.surface,border:`1px solid ${a.ack?T.border:col+'40'}`,borderLeft:`4px solid ${col}`,borderRadius:11,padding:'13px 15px',opacity:a.ack?0.6:1}}>
            <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8,flexWrap:'wrap'}}>
              <MTag text={a.id} color={col}/><Bdg label={a.sev.toUpperCase()} color={col}/><Bdg label={a.type} color={T.oee}/>
              <span style={{fontSize:12,fontWeight:700}}>{a.machine}</span>
              {a.ack&&<Bdg label="ACK" color={T.green} sm/>}
              <span style={{marginLeft:'auto',fontSize:10,color:T.m2}}>{a.ts}</span>
            </div>
            <div style={{fontSize:12,color:T.txt2,lineHeight:1.55,marginBottom:7}}>{a.msg}</div>
            <div style={{fontSize:11,color:T.sem,marginBottom:a.ack?0:8}}>→ {a.routed}</div>
            {!a.ack&&<div style={{display:'flex',gap:7}}><Btn v="teal" sm onClick={()=>ack(a.id)}>Acknowledge</Btn><Btn sm>Create WO</Btn><Btn sm>Escalate</Btn></div>}
          </div>
        );
      })}
    </div>
  );
}
function OeeScorecard(){
  const{wos,oeeScorecard,qualityLines,baselines,personasCfg,critical}=useApp();
  const[persona,setPersona]=useState('executive');
  // Persona config from personas.csv — live KPI values injected per persona
  const{machines:pMach,yieldParams:pYield}=useStore();
  const pAvgOee=pMach.length?+((pMach as any[]).reduce((s:number,m:any)=>s+Number(m.oee??0),0)/(pMach as any[]).length).toFixed(1):0;
  const pMinRul=(pMach as any[]).reduce((n:number,m:any)=>Math.min(n,Number(m.rul??999)),999);
  const pWarnWos=wos.filter((w:any)=>w.status==='open'||w.status==='in_progress').length;
  const livePersonaValues:Record<string,string>={
    machine_oee: pAvgOee+'%',
    plant_oee:   pAvgOee+'%',
    line_oee:    pAvgOee+'%',
    shift_oee:   (pAvgOee*1.03).toFixed(1)+'%',
    oee_gap:     (pAvgOee-85).toFixed(1)+'%',
    mttr:        baselines?.mttr?(baselines.mttr.current??'--')+' min':'--',
    mtbf:        baselines?.mtbf?(baselines.mtbf.current??'--')+' hrs':'--',
    breakdowns:  String((pMach as any[]).filter((m:any)=>m.status==='critical').length),
    pending_wos: String(pWarnWos),
    loss_type:   (pMach as any[]).find((m:any)=>m.loss)?.loss??'Speed Loss',
    loss_cat:    (pMach as any[]).find((m:any)=>m.loss)?.loss??'Breakdown',
    cost_of_loss:'Rs '+(((100-pAvgOee)/100)*48000).toFixed(0)+'L/day',
    roi:         baselines?.roi?(baselines.roi.current??'--')+'x':'--',
    cycle_time:  baselines?.cycle_time?(baselines.cycle_time.current??'--')+'s':'--',
    defects_hr:  qualityLines.length?String((qualityLines.reduce((s:number,l:any)=>s+Number(l.defects??0),0)/8).toFixed(1)):'--',
    changeover_min: baselines?.changeover?(baselines.changeover.current??'--')+'min':'--',
  };
  // Build P from personasCfg CSV or fall back to defaults
  const defaultP={
    operator:{label:'Operator',col:T.blue,kpis:[['OEE',livePersonaValues.machine_oee],['Active Loss',livePersonaValues.loss_type],['Cycle Time',livePersonaValues.cycle_time],['Defects/hr',livePersonaValues.defects_hr]]},
    supervisor:{label:'Supervisor',col:T.oee,kpis:[['Line OEE',livePersonaValues.line_oee],['Shift OEE',livePersonaValues.shift_oee],['Loss Cat.',livePersonaValues.loss_cat],['Changeover',livePersonaValues.changeover_min]]},
    maintenance:{label:'Maintenance',col:T.pdm,kpis:[['MTTR',livePersonaValues.mttr],['MTBF',livePersonaValues.mtbf],['Breakdowns',livePersonaValues.breakdowns],['Pending WOs',livePersonaValues.pending_wos]]},
    executive:{label:'Executive',col:T.yield,kpis:[['Plant OEE',livePersonaValues.plant_oee],['Gap to 85%',livePersonaValues.oee_gap],['Cost of Loss',livePersonaValues.cost_of_loss],['ROI',livePersonaValues.roi]]},
  };
  const P:any=Object.keys(personasCfg).length?Object.fromEntries(
    Object.entries(personasCfg).map(([id,v]:any)=>[id,{
      ...v,
      kpis:v.kpis.map(([label,key]:[string,string])=>[label,livePersonaValues[key]??key])
    }])
  ):defaultP;
  const pv=P[persona];
  return(
    <div style={scroll}>
      <CH title="OEE Scorecard - Persona Views" sub="Single governed OEE definition for all roles" right={<Bdg label="Semantic Layer" color={T.sem}/>}/>
      <div style={{display:'flex',gap:7,marginBottom:4}}>
        {Object.entries(P).map(([id,v])=>(
          <button key={id} onClick={()=>setPersona(id)} style={{fontSize:11,fontWeight:700,padding:'6px 14px',borderRadius:8,cursor:'pointer',border:`1px solid ${persona===id?v.col:T.border}`,background:persona===id?v.col+'15':'transparent',color:persona===id?v.col:T.m2}}>{v.label}</button>
        ))}
      </div>
      <div style={{background:T.surface,border:`1px solid ${pv.col+'40'}`,borderTop:`3px solid ${pv.col}`,borderRadius:12,padding:16}}>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
          {pv.kpis.map(([k,v])=>(
            <div key={k} style={{background:T.s2,borderRadius:8,padding:'10px 12px',border:`1px solid ${T.border}`}}>
              <div style={{fontSize:10,color:T.m2,textTransform:'uppercase',letterSpacing:'0.5px',marginBottom:4}}>{k}</div>
              <div style={{fontSize:20,fontWeight:800,color:pv.col}}>{v}</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Card>
          <CH title="6-Month OEE Trend" sub="Target: 85% by Month 6"/>
          <ResponsiveContainer width="100%" height={150}>
            <ComposedChart data={oeeScorecard}>
              <CartesianGrid strokeDasharray="3 3" stroke={T.border}/>
              <XAxis dataKey="m" tick={{fill:T.m2,fontSize:10}}/><YAxis domain={[60,90]} tick={{fill:T.m2,fontSize:10}}/>
              <Tooltip {...tt}/><ReferenceLine y={85} stroke={T.green} strokeDasharray="4 4" label={{value:'Target',fill:T.green,fontSize:9}}/>
              <Bar dataKey="p1" fill={T.oee} opacity={0.7} radius={[3,3,0,0]} name="Plant 1"/>
              <Bar dataKey="p2" fill={T.blue} opacity={0.5} radius={[3,3,0,0]} name="Plant 2"/>
              <Legend wrapperStyle={{fontSize:11}}/>
            </ComposedChart>
          </ResponsiveContainer>
        </Card>
        <div style={{display:'flex',flexDirection:'column',gap:10}}>
          {(oeeScorecard.length>0?[
              {name:'Plant 1',val:oeeScorecard[oeeScorecard.length-1]?.p1??null},
              {name:'Plant 2',val:oeeScorecard[oeeScorecard.length-1]?.p2??null},
            ]:[]).filter(p=>p.val!=null).map(({name,val})=>(
            <div key={name} style={{background:T.surface,border:`1px solid ${T.border}`,borderRadius:11,padding:'13px 15px',flex:1,display:'flex',alignItems:'center',justifyContent:'space-between'}}>
              <div><div style={{fontSize:12,fontWeight:700,marginBottom:4}}>{name}</div><div style={{fontSize:10,color:T.m2}}>Gap: <span style={{color:T.red,fontWeight:700}}>-{(85-val).toFixed(1)}%</span></div></div>
              <OeeGauge value={val} size={70}/>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* YIELD AGENT */
function YieldAgent(){
  const[tab,setTab]=useState('dashboard');
  return(
    <AgentPage quarter="Q4" title="Yield Optimisation Agent" tags={['OSIsoft PI','LIMS','SAP PP','DCS write-back']} target="Target: +5-8% yield, -10% RM waste" accentCol={T.yield}
      tabs={[['dashboard','Dashboard'],['lims','LIMS Results'],['dcs','DCS Set-points'],['sap','SAP Orders'],['benchmark','Benchmarking'],['model','ML Model']]} activeTab={tab} setActiveTab={setTab}>
      {tab==='dashboard'&&<YieldDash/>}
      {tab==='lims'&&<YieldLims/>}
      {tab==='dcs'&&<YieldDcs/>}
      {tab==='sap'&&<YieldSap/>}
      {tab==='benchmark'&&<YieldBenchmark/>}
      {tab==='model'&&<YieldModel/>}
    </AgentPage>
  );
}
function YieldDash(){
  const{agsYield,baselines}=useApp();
  const[cfg,setCfg]=useState<any>({});
  useEffect(()=>{fetchPlatformConfig().then(d=>{setCfg(d);_sharedCfg.cfg=d;_sharedCfg.appCfg=d;}).catch(()=>{});},[]);
  const[lims,setLims]=useState(LIMS);
  const[dcs,setDcs]=useState(DCS_INIT);
  const[sapOrders,setSapOrders]=useState(SAP_ORDERS);
  useEffect(()=>{
    fetchLims().then(d=>{if(d.length)setLims(d as any);}).catch(()=>{});
    fetchDcsSetpoints().then(d=>{if(d.length)setDcs(d as any);}).catch(()=>{});
    fetchProductionOrders().then(d=>{if(d.length)setSapOrders(d as any);}).catch(()=>{});
  },[]);
  const[params,setParams]=useState(YIELD_PARAMS);
  useEffect(()=>{fetchYieldParams().then(d=>{if(d.length)setParams(d as any);}).catch(()=>{});},[]);
  const{yieldParams:storeParams,fetchYieldParams}=useStore();
  useEffect(()=>{
    fetchYieldParams();
    const iv=setInterval(fetchYieldParams,4000);
    return()=>clearInterval(iv);
  },[]);
  useEffect(()=>{
    if(storeParams&&storeParams.length>0)setParams(storeParams as typeof params);
  },[storeParams]);
  return(
    <div style={scroll}>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
        <Kpi label="Current Yield" value={(agsYield as any[]).length?Number((agsYield as any[])[0]?.val??0).toFixed(1)+"%":"--"} delta="+6.1% vs baseline" up color={T.green} accent={T.yield}/>
        <Kpi label="Scrap Rate" value={(agsYield as any[]).length?(100-Number((agsYield as any[])[0]?.val??0)).toFixed(1)+"%":"--"} delta="-1.4% this shift" up color={T.amber} accent={T.yield}/>
        <Kpi label="RM Waste" value={baselines?.rm_waste?Number(baselines.rm_waste.current??0).toFixed(1)+"%":"--"} delta="-8.3% this week" up color={T.oee} accent={T.yield}/>
        <Kpi label="Rec. Adoption" value={cfg?.semanticKpi?.rec_adoption?.value?String(cfg.semanticKpi.rec_adoption.value)+"%":"--"} delta="+12% this month" up color={T.yield} accent={T.yield}/>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Card>
          <CH title="Yield Trend - 7 Days" sub="vs 85.2% baseline"/>
          <ResponsiveContainer width="100%" height={140}>
            <AreaChart data={oeeTrend2}>
              <defs><linearGradient id="ygg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={T.yield} stopOpacity={0.2}/><stop offset="95%" stopColor={T.yield} stopOpacity={0}/></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke={T.border}/>
              <XAxis dataKey="day" tick={{fill:T.m2,fontSize:10}}/><YAxis domain={[83,93]} tick={{fill:T.m2,fontSize:10}}/>
              <Tooltip {...tt}/>
              <Area type="monotone" dataKey="yld" stroke={T.yield} fill="url(#ygg)" strokeWidth={2} name="Yield %"/>
            </AreaChart>
          </ResponsiveContainer>
        </Card>
        <Card>
          <CH title="Live Process Parameters (OSIsoft PI)" sub="3.5s refresh - Semantic Layer blocks unsafe recs" right={<Bdg label="1 BLOCKED" color={T.red}/>}/>
          <div style={{display:'flex',flexDirection:'column',gap:7}}>
            {params.slice(0,4).map(p=>{
              const pct=Math.min(100,Math.max(0,Math.round(((p.val-p.min)/(p.max-p.min))*100)));
              const col=p.blocked?T.red:p.warn?T.amber:T.green;
              return(
                <div key={p.id} style={{display:'flex',alignItems:'center',gap:10,padding:'7px 11px',background:T.s2,border:`1px solid ${p.blocked?T.red+'30':T.border}`,borderRadius:8}}>
                  <div style={{fontSize:11,fontWeight:600,width:100,flexShrink:0}}>{p.name}</div>
                  <div style={{flex:1,height:4,background:T.border,borderRadius:2}}><div style={{height:4,width:`${pct}%`,background:col,borderRadius:2,transition:'width .5s'}}/></div>
                  <div style={{fontSize:14,fontWeight:800,color:col,width:60,textAlign:'right'}}>{p.val}<span style={{fontSize:10,color:T.m2}}> {p.unit}</span></div>
                  {p.blocked&&<Bdg label="BLOCKED" color={T.red} sm/>}
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  );
}
function YieldLims(){
  const{lims}=useApp();

  return(
    <div style={scroll}>
      <CH title="LIMS Results - LabVantage / STARLIMS" sub="REST API - Today's batch quality" right={<><Bdg label="4 PASS" color={T.green}/><Bdg label="1 FAIL" color={T.red}/></>}/>
      {lims.map(r=>(
        <div key={r.id} style={{background:T.surface,border:`1px solid ${r.status==='fail'?T.red+'40':T.border}`,borderLeft:`3px solid ${r.status==='fail'?T.red:T.green}`,borderRadius:10,padding:'13px 15px'}}>
          <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:8,flexWrap:'wrap'}}>
            <Bdg label={r.status.toUpperCase()} color={r.status==='pass'?T.green:T.red}/>
            <MTag text={r.id} color={r.status==='fail'?T.red:T.oee}/>
            <span style={{fontSize:13,fontWeight:700}}>{r.test}</span>
            <span style={{marginLeft:'auto',fontSize:11,color:T.m2}}>{r.time}</span>
          </div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
            {[['Batch',r.batch,T.txt],['Result',r.result,r.status==='fail'?T.red:T.green],['Limit',r.limit,T.txt],['Analyst',r.analyst,T.m2]].map(([k,v,c])=>(
              <div key={k}><div style={{fontSize:9,color:T.m2,textTransform:'uppercase',marginBottom:3}}>{k}</div><div style={{fontSize:12,fontWeight:600,color:c}}>{v}</div></div>
            ))}
          </div>
          {r.status==='fail'&&<div style={{marginTop:9,padding:'7px 11px',background:T.rDim,borderRadius:7,fontSize:11,color:T.red}}>Out of spec - Yield agent adjusted FIC-301 recommendation. QA team notified.</div>}
        </div>
      ))}
    </div>
  );
}
function YieldDcs(){
  const{dcs}=useApp();

  const[pts,setPts]=useState(DCS_INIT);
  const act=(tag,s)=>setPts(ps=>ps.map(p=>p.tag===tag?{...p,status:s}:p));
  const stCol={blocked:T.red,pending:T.amber,accepted:T.green,ok:T.border,rejected:T.red};
  return(
    <div style={scroll}>
      <CH title="DCS Set-points - Recommendation Engine" sub="ML prescribes optimal adjustments - OPC-UA write-back - Semantic Layer conflict check"
        right={<><Bdg label={`${pts.filter(p=>p.status==='pending').length} pending`} color={T.amber}/><Bdg label="1 blocked" color={T.red}/></>}/>
      <div style={{background:T.rDim,border:`1px solid ${T.red}30`,borderRadius:8,padding:'9px 13px',fontSize:11,color:T.red}}>
        Semantic Layer conflict active: DCS write blocked due to open PdM fault on linked asset. Resumes when maintenance work order closes.
      </div>
      {pts.map(p=>{
        const bc=stCol[p.status]||T.border;
        return(
          <div key={p.tag} style={{background:T.surface,border:`1px solid ${T.border}`,borderLeft:`3px solid ${bc}`,borderRadius:10,padding:'13px 15px'}}>
            <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:9,flexWrap:'wrap'}}>
              <MTag text={p.tag}/><span style={{fontSize:13,fontWeight:700}}>{p.desc}</span>
              <span style={{marginLeft:'auto'}}><Bdg label={p.status==='ok'?'AT TARGET':p.status.toUpperCase()} color={bc}/></span>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:9,marginBottom:8}}>
              {[['Current',`${p.cur} ${p.unit}`,T.txt],['Recommended',`${p.rec} ${p.unit}`,T.amber],['Delta',p.delta,parseFloat(p.delta)>0?T.green:T.oee],['Yield Impact',p.impact,T.yield]].map(([k,v,c])=>(
                <div key={k}><div style={{fontSize:9,color:T.m2,textTransform:'uppercase',marginBottom:3}}>{k}</div><div style={{fontSize:12,fontWeight:600,color:c}}>{v}</div></div>
              ))}
            </div>
            {p.status==='blocked'&&<div style={{padding:'7px 11px',background:T.rDim,borderRadius:7,fontSize:11,color:T.red}}>Blocked - {p.blockedBy} must close first.</div>}
            {p.status==='pending'&&<div style={{display:'flex',gap:7}}><Btn v="accept" sm onClick={()=>act(p.tag,'accepted')}>Accept & Push DCS</Btn><Btn sm onClick={()=>act(p.tag,'rejected')}>Reject</Btn></div>}
            {p.status==='accepted'&&<div style={{fontSize:11,color:T.green,fontWeight:700}}>Written to DCS via OPC-UA</div>}
            {p.status==='rejected'&&<div style={{fontSize:11,color:T.red,fontWeight:700}}>Rejected</div>}
          </div>
        );
      })}
    </div>
  );
}
function YieldSap(){
  const{sapOrders}=useApp();

  return(
    <div style={scroll}>
      <CH title="SAP PP - Production Orders" sub="SAP OData API - Plan vs actual yield"/>
      {sapOrders.map(o=>{
        const col=sc(o.status);
        return(
          <div key={o.id} style={{background:T.surface,border:`1px solid ${T.border}`,borderLeft:`3px solid ${col}`,borderRadius:10,padding:'13px 15px'}}>
            <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:9,flexWrap:'wrap'}}>
              <MTag text={o.id}/><Bdg label={o.status.toUpperCase()} color={col}/>
              <span style={{fontSize:13,fontWeight:700}}>{o.product}</span>
              <span style={{marginLeft:'auto',fontSize:11,color:T.m2}}>{o.start} → {o.end}</span>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:9}}>
              {[['Quantity',o.qty,T.txt],['Planned',`${o.plan}%`,T.m2],['Actual',o.actual?`${o.actual}%`:'--',o.actual?(o.actual>=o.plan?T.green:T.red):T.m2],['vs Plan',o.actual?`${(o.actual-o.plan).toFixed(1)}%`:'--',o.actual?(o.actual>=o.plan?T.green:T.red):T.m2]].map(([k,v,c])=>(
                <div key={k}><div style={{fontSize:9,color:T.m2,textTransform:'uppercase',marginBottom:3}}>{k}</div><div style={{fontSize:13,fontWeight:700,color:c}}>{v}</div></div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
function YieldBenchmark(){
  const{cfg:shCfg}=useSharedCfg();
  const trend=shCfg.benchmarkTrend??[];
  // Plant cards derived from benchmark trend last day — no hardcoded values
  const plants=trend.length?[
    {name:'Plant A',val:trend[trend.length-1]?.a??null,col:T.yield},
    {name:'Plant B',val:trend[trend.length-1]?.b??null,col:T.m3},
    {name:'Plant C',val:trend[trend.length-1]?.c??null,col:T.oee},
  ]:[];
  const best=plants.length?plants.reduce((b,p)=>p.val>b.val?p:b,plants[0]):null;
  return(
    <div style={scroll}>
      <CH title="Cross-Plant Benchmarking" sub="Semantic Layer governs yield, scrap rate, RM waste consistently" right={<Bdg label="Semantic Layer" color={T.sem}/>}/>
      <div style={{background:T.sDim,border:`1px solid ${T.sem}25`,borderRadius:9,padding:'10px 14px',fontSize:11,color:T.m2}}>
        AI Semantic Layer governs yield, scrap rate, process parameter, and raw material KPIs - consistent definitions across all plants enabling cross-plant benchmarking.
      </div>
      {plants.length>0&&<div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10}}>
        {plants.map(({name,val,col})=>(
          <div key={name} style={{background:T.surface,border:`1px solid ${name===best?.name?col+'50':T.border}`,borderTop:`3px solid ${col}`,borderRadius:11,padding:'14px 15px',boxShadow:'0 1px 4px rgba(0,0,0,.05)'}}>
            <div style={{display:'flex',justifyContent:'space-between',marginBottom:6}}><span style={{fontSize:12,fontWeight:700}}>{name}</span>{name===best?.name&&<Bdg label="BEST" color={col}/>}</div>
            <div style={{fontSize:30,fontWeight:800,color:col,letterSpacing:'-1px'}}>{val!=null?val.toFixed(1):'--'}<span style={{fontSize:13,color:T.m2,fontWeight:400}}>%</span></div>
          </div>
        ))}
      </div>}
      {trend.length>0&&<Card>
        <CH title="Weekly Yield Trend - All 3 Plants"/>
        <ResponsiveContainer width="100%" height={160}>
          <LineChart data={trend}>
            <CartesianGrid strokeDasharray="3 3" stroke={T.border}/>
            <XAxis dataKey="day" tick={{fill:T.m2,fontSize:10}}/><YAxis domain={[84,92]} tick={{fill:T.m2,fontSize:10}}/>
            <Tooltip {...tt}/>
            <Line type="monotone" dataKey="a" stroke={T.yield} strokeWidth={2} dot={{fill:T.yield,r:3}} name="Plant A"/>
            <Line type="monotone" dataKey="b" stroke={T.m3} strokeWidth={2} dot={false} name="Plant B"/>
            <Line type="monotone" dataKey="c" stroke={T.oee} strokeWidth={2} dot={false} name="Plant C"/>
            <Legend wrapperStyle={{fontSize:11}}/>
          </LineChart>
        </ResponsiveContainer>
      </Card>}
      {!trend.length&&<div style={{padding:20,textAlign:'center',color:T.m2,fontSize:12}}>Loading benchmark data from platform_config.csv...</div>}
    </div>
  );
}
function YieldModel(){
  const{cfg:shCfg,appCfg:shApp}=useSharedCfg();
  return(
    <div style={scroll}>
      <CH title="ML Model - Yield Optimisation" sub="XGBoost ensemble - OSIsoft PI + LIMS - Weekly retraining" right={<><Bdg label="v2.4 deployed" color={T.green}/><Bdg label="R2=0.961" color={T.yield}/></>}/>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:11}}>
        <Kpi label="R2 Score" value={shApp?.modelYield?.[0]?.r2!=null?String(shApp.modelYield[0].r2):"--"} delta="+0.007 vs prev" up color={T.green} accent={T.yield}/>
        <Kpi label="Training Samples" value={shApp?.modelYield?.[0]?.samples!=null?shApp.modelYield[0].samples.toLocaleString():"--"} delta="+130 this week" up color={T.oee} accent={T.yield}/>
        <Kpi label="MSE (holdout)" value={shApp?.modelYield?.[0]?.mse!=null?String(shApp.modelYield[0].mse):"--"} sub="vs 0.0038 prev" color={T.yield} accent={T.yield}/>
        <Kpi label="Next Retraining" value={shApp?.retraining?.yield_model?.nextVersion?"v"+shApp.retraining.yield_model.nextVersion+" ready":"--"} sub="Weekly cycle" color={T.amber} accent={T.yield}/>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Card><CH title="SHAP Feature Importance"/>{(shCfg.yieldFeats??YIELD_FEATS).map((f:any)=><FeatBar key={f.f} label={f.f} pct={f.v} col={T.yield}/>)}</Card>
        <Card>
          <CH title="Training History"/>
          {(shCfg.modelYield??MODEL_YIELD).map((r:any)=>(
            <div key={r.date} style={{background:T.s2,border:`1px solid ${T.border}`,borderLeft:`3px solid ${r.status==='deployed'?T.green:T.border}`,borderRadius:8,padding:'11px 14px',marginBottom:8}}>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}><span style={{fontSize:12,fontWeight:700}}>{r.date}</span><Bdg label={r.status.toUpperCase()} color={r.status==='deployed'?T.green:T.m2}/></div>
              <div style={{fontSize:11,color:T.m2}}>R2 {r.r2} - MSE {r.mse} - {r.samples.toLocaleString()} samples</div>
            </div>
          ))}
        </Card>
      </div>
      <Card><CH title="Manual Retraining" sub={shApp?.retraining?.yield_model?.sub??"PI + LIMS data - Est 18 min"}/>
        <RetBtn phases={['Loading PI historian data...','Preprocessing LIMS features...','Training XGBoost ensemble...','Validating holdout set...','Deploying v2.5...']} col={T.yield} label="v2.5 deployed R2=0.964"/>
      </Card>
    </div>
  );
}

/* PdM AGENT (includes Parts as tab 8) */
function PdmAgent(){
  const[tab,setTab]=useState('architecture');
  return(
    <AgentPage quarter="Q2-Q4" title="Predictive Maintenance Agent" tags={['v2.0','Jetson','IoT Hub','ADT']} target="Target: -40% unplanned downtime" accentCol={T.pdm}
      tabs={[['architecture','Architecture'],['assets','Asset Health'],['sensors','Sensor Feed'],['rul','RUL Forecast'],['workorders','Work Orders'],['shift','Shift Schedule'],['model','ML Model'],['parts','Parts Ordering']]} activeTab={tab} setActiveTab={setTab}>
      {tab==='architecture'&&<PdmArch/>}
      {tab==='assets'&&<PdmAssets/>}
      {tab==='sensors'&&<PdmSensors/>}
      {tab==='rul'&&<PdmRul/>}
      {tab==='workorders'&&<PdmWo/>}
      {tab==='shift'&&<PdmShift/>}
      {tab==='model'&&<PdmModel/>}
      {tab==='parts'&&<PdmParts/>}
    </AgentPage>
  );
}
function PdmArch(){
  const{agsMachines,baselines}=useApp();
  const{appCfg:shApp,baselines:shBase,techStacks:shTech}=useSharedCfg();
  const LAYERS=(shTech['pdm']??[{label:'DATA SOURCES',col:'#0369a1',items:['Vibration sensors','PI System','SAP PM']},{label:'EDGE AI LAYER',col:'#7c3aed',items:['NVIDIA Jetson','TinyML <10ms']},{label:'CLOUD AI ENGINE',col:'#ea580c',items:['Azure IoT Hub','Failure ML','RUL']},{label:'AGENT ACTIONS',col:'#d97706',items:['Work order auto-create','Parts reorder']},{label:'OUTCOMES',col:'#16a34a',items:['-40% downtime','ROI 8-12x']}]);
  return(
    <div style={scroll}>
      <div style={{fontSize:13,fontWeight:700,marginBottom:2}}>Predictive Maintenance - Deep Dive</div>
      <div style={{fontSize:11,color:T.m2,marginBottom:14}}>Anchor agent built Q2, iterated to v2.0 by Q4. Parts Ordering is a sub-function in the Parts tab.</div>
      <LayerBar layers={LAYERS}/>
      <Card>
        <CH title="Version Roadmap"/>
        <div style={{display:'flex',gap:0}}>
          {[{ver:'v1.0 (Q2)',items:'PI + SAP PM - Vibration anomaly - Alert workflow',col:T.m2},{ver:'v1.5 (Q3)',items:'+ Thermal vision - Edge AI on Jetson - Multi-sensor',col:T.pdm},{ver:'v2.0 (Q4)',items:'+ Digital twin sync - Auto work order - AR HMT',col:T.green}].map((r,i)=>(
            <div key={r.ver} style={{flex:1,background:r.col+'10',border:`1px solid ${r.col+'30'}`,borderBottom:`3px solid ${r.col}`,borderRadius:i===0?'8px 0 0 8px':i===2?'0 8px 8px 0':'0',padding:'11px 13px'}}>
              <div style={{fontSize:11,fontWeight:800,color:r.col,marginBottom:5}}>{r.ver}</div>
              <div style={{fontSize:10,color:T.m2,lineHeight:1.5}}>{r.items}</div>
            </div>
          ))}
        </div>
      </Card>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
        <Kpi label="Assets Monitored" value={(agsMachines as any[]).length?String((agsMachines as any[]).length):"--"} sub="8 prod + 6 utility" color={T.pdm} accent={T.pdm}/>
        <Kpi label="F1 Score" value={shApp?.modelPdm?.[0]?.f1!=null?String(shApp.modelPdm[0].f1):"--"} delta="+0.016 vs prev" up color={T.green} accent={T.pdm}/>
        <Kpi label="Edge Latency" value="<10ms" sub="NVIDIA Jetson TRT" color={T.parts} accent={T.pdm}/>
        <Kpi label="Unplanned Down" value={shBase?.unplanned_downtime?"-"+(shBase.unplanned_downtime.delta??0)+"%":"--"} delta={shBase?.unplanned_downtime?"vs "+shBase.unplanned_downtime.date?.slice(0,7):"vs pre-agent"} up color={T.green} accent={T.pdm}/>
      </div>
    </div>
  );
}
function PdmAssets(){
  const{mch,util}=useApp();

  const{machines:selMachines}=useStore();
  const firstMachine=(selMachines as any[])[0]?.id??'';
  const[sel,setSel]=useState(firstMachine);
  const[twinComps,setTwinComps]=useState(DT_COMPS);
  useEffect(()=>{fetchTwinComponents().then(d=>{if(Object.keys(d).length)setTwinComps(d as any);}).catch(()=>{});},[]);
  const all=[...mch,...util];const selA=all.find((a:any)=>a.id===sel);const dt=(twinComps as any)[sel];
  return(
    <div style={scroll}>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
        <div>
          <div style={{fontSize:11,fontWeight:700,color:T.m2,marginBottom:8,textTransform:'uppercase',letterSpacing:1}}>Production Assets (8)</div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:7}}>
            {mch.map((m:any)=>{
              const stC=sc(m.status);
              return(
                <div key={m.id} onClick={()=>setSel(m.id)} style={{background:T.surface,border:`1px solid ${sel===m.id?stC+'80':T.border}`,borderLeft:`3px solid ${stC}`,borderRadius:9,padding:'10px 12px',cursor:'pointer',boxShadow:sel===m.id?`0 0 0 2px ${stC}20`:'0 1px 3px rgba(0,0,0,.04)'}}>
                  <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:5}}><HR value={m.health} size={38}/><div><div style={{fontSize:10,fontWeight:700}}>{m.id}</div><Bdg label={m.status.toUpperCase()} color={stC} sm/></div></div>
                  <div style={{fontSize:9,color:T.m2}}>RUL: <span style={{color:m.rul<15?T.red:T.amber,fontWeight:700}}>{m.rul}d</span></div>
                </div>
              );
            })}
          </div>
        </div>
        <div>
          <div style={{fontSize:11,fontWeight:700,color:T.m2,marginBottom:8,textTransform:'uppercase',letterSpacing:1}}>Utility Assets (6)</div>
          <div style={{display:'flex',flexDirection:'column',gap:7}}>
            {util.map(a=>{
              const stC=sc(a.status);
              return(
                <div key={a.id} onClick={()=>setSel(a.id)} style={{background:T.surface,border:`1px solid ${sel===a.id?stC+'80':T.border}`,borderLeft:`3px solid ${stC}`,borderRadius:9,padding:'10px 12px',cursor:'pointer',display:'flex',alignItems:'center',gap:10}}>
                  <HR value={a.health} size={38}/>
                  <div style={{flex:1}}><div style={{fontSize:11,fontWeight:700}}>{a.name}</div><div style={{fontSize:9,color:T.m2}}>RUL: <span style={{color:a.rul<15?T.red:T.amber,fontWeight:700}}>{a.rul}d</span> <Bdg label={a.status.toUpperCase()} color={stC} sm/></div></div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      {selA&&(
        <Card>
          <CH title={`Digital Twin - ${selA.name}`} sub="Azure Digital Twins - component-level health breakdown" right={<Bdg label={selA.status.toUpperCase()} color={sc(selA.status)}/>}/>
          {dt?(
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:9}}>
              {dt.map(c=>(
                <div key={c.c} style={{background:T.s2,border:`1px solid ${c.a?T.red+'40':T.border}`,borderRadius:8,padding:'10px 12px'}}>
                  <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:5}}><div style={{fontSize:11,fontWeight:700}}>{c.c}</div>{c.a&&<Bdg label="ANOMALY" color={T.red} sm/>}</div>
                  <div style={{height:4,background:T.border,borderRadius:2,marginBottom:5}}><div style={{height:4,width:`${c.h}%`,background:hc(c.h),borderRadius:2}}/></div>
                  <div style={{fontSize:10,color:T.m2}}>Health <strong style={{color:hc(c.h)}}>{c.h}%</strong> - Temp <strong style={{color:c.t>85?T.red:T.txt}}>{c.t}C</strong> - Vib <strong>{c.v}</strong></div>
                </div>
              ))}
            </div>
          ):<div style={{fontSize:11,color:T.m2,textAlign:'center',padding:20}}>No Digital Twin components defined for this asset.</div>}
        </Card>
      )}
    </div>
  );
}
function PdmSensors(){
  const{mch,util}=useApp();

  const[data,setData]=useState(SENSOR_H);
  const{machines:assetMachines}=useStore();
  const firstAsset=(assetMachines as any[])[0]?.id??'';
  const[assetId,setAssetId]=useState(firstAsset);
  useEffect(()=>{if(assetId)fetchSensorHistory(assetId).then(d=>{if(d.length)setData(d as any);}).catch(()=>{});},[assetId]);
  const{machines:sensorMachines}=useStore();
  useEffect(()=>{
    const m=sensorMachines.find((m:any)=>m.id===assetId) as any;
    if(m){
      const h=new Date().getHours();
      setData(d=>[...d.slice(1),{t:String(h).padStart(2,'0')+':00',vib:+(m.vib||d[d.length-1]?.vib||0).toFixed(2),tmp:+(m.temp||d[d.length-1]?.tmp||0).toFixed(1)}]);
    }
  },[sensorMachines,assetId]);
  const last=data[data.length-1]||{};
  return(
    <div style={scroll}>
      <LayerBar layers={[{label:'Vibration Sensors',col:'#0369a1',items:['OPC-UA -> Jetson']},{label:'TinyML Edge <10ms',col:T.parts,items:['NVIDIA Jetson TRT']},{label:'Azure IoT Hub',col:T.oee,items:['Cloud ingest']},{label:'Multi-sensor Fusion',col:T.pdm,items:['Cloud AI Engine']},{label:'Alert / WO Action',col:T.energy,items:['Agent Action']}]}/>
      <div style={{display:'flex',gap:7,alignItems:'center',flexWrap:'wrap'}}>
        <span style={{fontSize:11,color:T.m2}}>Asset:</span>
        {[...mch,...util].filter((a:any)=>a.vib!=null).slice(0,8).map((a:any)=>(
          <button key={a.id} onClick={()=>setAssetId(a.id)} style={{fontSize:10,fontWeight:600,padding:'3px 10px',borderRadius:20,cursor:'pointer',border:`1px solid ${assetId===a.id?T.pdm:T.border}`,background:assetId===a.id?T.pDim:'transparent',color:assetId===a.id?T.pdm:T.m2}}>{a.id}</button>
        ))}
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:11}}>
        {[['Vibration RMS',`${last.vib} mm/s`,'ISO limit: 5.0',T.red,last.vib>5],['Temperature',`${last.tmp}C`,'Alarm: 85C',T.pdm,last.tmp>85],['Pressure','11.8 bar','Nominal: 11.0',T.oee,false]].map(([l,v,s,c,alert])=>(
          <div key={l} style={{background:T.surface,border:`1px solid ${alert?c+'40':T.border}`,borderRadius:11,padding:14}}>
            <div style={{fontSize:10,color:T.m2,fontWeight:700,textTransform:'uppercase',marginBottom:5}}>{l}{alert?' ALERT':''}</div>
            <div style={{fontSize:26,fontWeight:800,color:alert?c:T.txt}}>{v}</div>
            <div style={{fontSize:10,color:T.m2,marginTop:3}}>{s}</div>
          </div>
        ))}
      </div>
      <Card>
        <CH title={`Vibration 24h - ${assetId}`} sub="PI historian - 4s live refresh"/>
        <ResponsiveContainer width="100%" height={140}>
          <AreaChart data={data}>
            <defs><linearGradient id="vgg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={T.red} stopOpacity={0.2}/><stop offset="95%" stopColor={T.red} stopOpacity={0}/></linearGradient></defs>
            <CartesianGrid strokeDasharray="3 3" stroke={T.border}/>
            <XAxis dataKey="t" tick={{fill:T.m2,fontSize:9}} interval={3}/><YAxis tick={{fill:T.m2,fontSize:10}}/>
            <Tooltip {...tt}/><ReferenceLine y={5.0} stroke={T.amber} strokeDasharray="4 4" label={{value:'ISO limit 5.0',fill:T.amber,fontSize:9}}/>
            <Area type="monotone" dataKey="vib" stroke={T.red} fill="url(#vgg)" strokeWidth={2} name="Vibration mm/s"/>
          </AreaChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}
// [DEDUPLICATED: PdmRul]

// [DEDUPLICATED: PdmWo]

// [DEDUPLICATED: PdmShift]

function PdmRul(){
  const{mch,util,rulTrend,agsMachines}=useApp();

  const critList=[...mch,...util].filter((a:any)=>Number(a.rul??999)<55).sort((a:any,b:any)=>Number(a.rul)-Number(b.rul)).slice(0,6);
  return(
    <div style={scroll}>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10}}>
        {critList.map(a=>{
          const col=a.rul<15?T.red:a.rul<30?T.orange:T.amber;
          return(
            <div key={a.id} style={{background:T.surface,border:`1px solid ${col+'40'}`,borderRadius:12,padding:14}}>
              <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:9}}><HR value={a.health} size={44}/><div><div style={{fontSize:12,fontWeight:700}}>{a.name}</div><div style={{fontSize:9,color:T.m2}}>{a.id}</div></div></div>
              <div style={{fontSize:30,fontWeight:800,color:col,letterSpacing:'-1px'}}>{a.rul}<span style={{fontSize:12,fontWeight:400,color:T.m2}}> days</span></div>
              <div style={{height:4,background:T.s3,borderRadius:2,marginTop:7}}><div style={{height:4,width:`${Math.min(100,a.rul*2)}%`,background:col,borderRadius:2}}/></div>
            </div>
          );
        })}
      </div>
      <Card>
        <CH title="RUL Trend - Critical Assets (7 Days)" sub="14-day threshold triggers auto WO creation"/>
        <ResponsiveContainer width="100%" height={160}>
          <LineChart data={rulTrend}>
            <CartesianGrid strokeDasharray="3 3" stroke={T.border}/>
            <XAxis dataKey="d" tick={{fill:T.m2,fontSize:10}}/><YAxis tick={{fill:T.m2,fontSize:10}}/>
            <Tooltip {...tt}/><ReferenceLine y={14} stroke={T.red} strokeDasharray="4 4" label={{value:'Critical 14d',fill:T.red,fontSize:9}}/>
            {rul0?<Line type="monotone" dataKey="m3" stroke={T.red} strokeWidth={2} dot={{fill:T.red,r:3}} name={rul0}/>:null}
            {rul1?<Line type="monotone" dataKey="m6" stroke={T.orange} strokeWidth={2} dot={{fill:T.orange,r:3}} name={rul1}/>:null}
            <Line type="monotone" dataKey="cmp" stroke={T.pdm} strokeWidth={2} dot={false} name="CMP-001"/>
            <Legend wrapperStyle={{fontSize:11}}/>
          </LineChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}
function PdmWo(){
  const{wos:ctxWos,agsMachines,rulTrend}=useApp();
  const[wos,setWos]=useState<any[]>([]);
  // Sync from context on first load or when context updates
  if(wos.length===0&&ctxWos.length>0){setWos(ctxWos);}
  const rul0=(agsMachines as any[]).find((m:any)=>m.status==='critical'||(m.rul??999)<20)?.id??null;
  const rul1=(agsMachines as any[]).filter((m:any)=>(m.rul??999)<30)[1]?.id??null;
  const[shifts,setShifts]=useState(SHIFTS);

  const act=(id,s)=>setWos(ws=>ws.map(w=>w.id===id?{...w,status:s}:w));
  const pc={P1:T.red,P2:T.pdm,P3:T.amber};
  const stC={open:T.amber,in_progress:T.blue,completed:T.green,scheduled:T.m2};
  return(
    <div style={scroll}>
      <CH title="Work Orders - Auto-created by PdM Agent" sub="SAP PM OData - OEE-linked WOs tagged by Semantic Layer" right={<><Bdg label="2 open" color={T.amber}/><Bdg label="2 P1" color={T.red}/></>}/>
      {wos.map(w=>(
        <div key={w.id} style={{background:T.surface,border:`1px solid ${T.border}`,borderLeft:`4px solid ${pc[w.pri]}`,borderRadius:11,padding:'13px 15px',opacity:w.status==='completed'?0.6:1}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:9,flexWrap:'wrap'}}>
            <MTag text={w.id}/><Bdg label={w.pri} color={pc[w.pri]}/><Bdg label={w.type} color={T.oee}/><Bdg label={w.status.replace('_',' ').toUpperCase()} color={stC[w.status]}/>
            {w.oeeLink&&<Bdg label="OEE LINKED" color={T.sem} sm/>}
            <span style={{fontSize:12,fontWeight:700}}>{w.name}</span>
            <span style={{marginLeft:'auto',fontSize:11,color:T.m2}}>{w.asset}</span>
          </div>
          <div style={{fontSize:12,color:T.m2,lineHeight:1.5,marginBottom:w.status!=='completed'?9:0}}>{w.desc}</div>
          {w.status!=='completed'&&(
            <div style={{display:'flex',gap:7}}>
              {w.status==='open'&&<Btn v="amber" sm onClick={()=>act(w.id,'in_progress')}>Start Work</Btn>}
              {w.status==='in_progress'&&<Btn v="accept" sm onClick={()=>act(w.id,'completed')}>Complete</Btn>}
              <Btn sm>View SAP PM</Btn>
            </div>
          )}
          {w.status==='completed'&&<div style={{fontSize:11,color:T.green,fontWeight:700}}>Completed - SAP PM updated</div>}
        </div>
      ))}
    </div>
  );
}
function PdmShift(){
  const{wos,shifts}=useApp();

  return(
    <div style={scroll}>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
        <Kpi label="Active Technicians" value={String(new Set(wos.filter((w:any)=>w.status==="in_progress").map((w:any)=>w.assignee)).size||2)} color={T.green} accent={T.pdm}/>
        <Kpi label="Open WOs Today" value={String(wos.filter((w:any)=>w.status==="open"||w.status==="in_progress").length||3)} color={T.pdm} accent={T.pdm}/>
        <Kpi label="OEE-Linked WOs" value={String(wos.filter((w:any)=>w.oeeLink).length||3)} sub="Direct OEE impact" color={T.sem} accent={T.pdm}/>
        <Kpi label="Avg Response" value={wos.length?Math.round(wos.filter((w:any)=>w.status==="completed"||w.status==="closed").length*18/(wos.length||1)||0)+" min":"--"} delta="vs 47 min baseline" up color={T.oee} accent={T.pdm}/>
      </div>
      <Card>
        <CH title="Shift Schedule" sub="Agent-adjusted by asset criticality and RUL forecasts"/>
        {shifts.map(s=>{
          const col={active:T.green,upcoming:T.pdm,scheduled:T.m2}[s.status];
          return(
            <div key={s.shift} style={{background:T.s2,border:`1px solid ${T.border}`,borderLeft:`3px solid ${col}`,borderRadius:9,padding:'12px 14px',marginBottom:8,display:'flex',alignItems:'center',gap:12}}>
              <div style={{flex:1}}><div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}><span style={{fontSize:12,fontWeight:700}}>{s.shift}</span><Bdg label={s.status.toUpperCase()} color={col}/></div><div style={{fontSize:11,color:T.m2}}>{s.start}-{s.end} - {s.tech} - {s.role}</div></div>
              <div style={{textAlign:'center'}}><div style={{fontSize:22,fontWeight:800,color:T.pdm}}>{s.wos}</div><div style={{fontSize:10,color:T.m2}}>WOs</div></div>
              <div style={{textAlign:'center'}}><div style={{fontSize:22,fontWeight:800,color:T.oee}}>{s.assets}</div><div style={{fontSize:10,color:T.m2}}>Assets</div></div>
            </div>
          );
        })}
      </Card>
    </div>
  );
}
function PdmModel(){
  const{cfg:shCfg,appCfg:shApp}=useSharedCfg();
  return(
    <div style={scroll}>
      <CH title="Cloud AI Engine - Failure Prediction & RUL" sub="Azure IoT Hub - Multi-sensor fusion - TinyML edge + Cloud" right={<><Bdg label="v2.0 deployed" color={T.green}/><Bdg label="F1=0.934" color={T.pdm}/></>}/>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:11}}>
        <Kpi label="F1 Score" value={String(shApp?.modelPdm?.[0]?.f1??0)} delta="+0.016" up color={T.green} accent={T.pdm}/>
        <Kpi label="Precision" value={String(shApp?.modelPdm?.[0]?.prec??0)} sub="Low false alarms" color={T.pdm} accent={T.pdm}/>
        <Kpi label="Training Samples" value={(shApp?.modelPdm?.[0]?.samples??0).toLocaleString()} delta="+1,640" up color={T.oee} accent={T.pdm}/>
        <Kpi label="Edge Latency" value="<10ms" sub="Jetson TensorRT" color={T.parts} accent={T.pdm}/>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Card><CH title="SHAP Feature Importance"/>{(shCfg.pdmFeats??[]).map((f:any)=><FeatBar key={f.f} label={f.f} pct={f.v} col={T.pdm}/>)}</Card>
        <Card>
          <CH title="Training History"/>
          {(shCfg.modelPdm??[]).map((r:any)=>(
            <div key={r.date} style={{background:T.s2,border:`1px solid ${T.border}`,borderLeft:`3px solid ${r.status==='deployed'?T.green:T.border}`,borderRadius:8,padding:'11px 14px',marginBottom:8}}>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}><span style={{fontSize:12,fontWeight:700}}>{r.date}</span><Bdg label={r.status.toUpperCase()} color={r.status==='deployed'?T.green:T.m2}/></div>
              <div style={{fontSize:11,color:T.m2}}>F1 {r.f1} - Prec {r.prec} - {r.samples.toLocaleString()} samples</div>
            </div>
          ))}
        </Card>
      </div>
      <Card><CH title="Manual Retraining" sub="Deploys to cloud + all Jetson edge gateways - Est 22 min"/>
        <RetBtn phases={['Streaming PI historian data...','Extracting spectral features (FFT)...','Training failure prediction model...','Validating RUL estimates...','Syncing to Jetson edge gateways...']} col={T.pdm} label="v2.1 deployed to cloud + all edge gateways"/>
      </Card>
    </div>
  );
}
function PdmParts(){
  const{baselines,pdmRules}=useApp();
  const[orders,setOrders]=useState(PARTS_INIT);
  const[partsInv,setPartsInv]=useState(PARTS_INV);
  const[spendTrend,setSpendTrend]=useState(SPEND_TREND);
  useEffect(()=>{
    fetchParts().then(d=>{
      if(d.orders.length)setOrders(d.orders as any);
      if(d.inventory.length)setPartsInv(d.inventory as any);
    }).catch(()=>{});
    fetchEnergySpend().then(d=>{if(d.length)setSpendTrend(d as any);}).catch(()=>{});
  },[]);
  const approve=id=>setOrders(os=>os.map(o=>o.id===id?{...o,status:'ordered',po:`PO-${id.replace('ORD-','')}`}:o));
  const stC={escalated:T.red,pending_approval:T.amber,ordered:T.green,delivered:T.oee};
  return(
    <div style={scroll}>
      <div style={{background:T.pDim,border:`1px solid ${T.pdm}25`,borderRadius:10,padding:'10px 14px'}}>
        <div style={{fontSize:12,fontWeight:700,color:T.pdm,marginBottom:3}}>Autonomous Parts Ordering - PdM Sub-function</div>
        <div style={{fontSize:11,color:T.m2}}>RUL-triggered procurement - SAP MM - 7 business rules - -73% unplanned spend</div>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
        <Kpi label="Orders Today" value={orders.length} color={T.pdm} accent={T.pdm}/>
        <Kpi label="Needs Approval" value={orders.filter(o=>['pending_approval','escalated'].includes(o.status)).length} color={T.red} accent={T.pdm}/>
        <Kpi label="Auto-Approved" value={orders.filter(o=>o.status==='ordered').length} color={T.green} accent={T.pdm}/>
        <Kpi label="Unplanned Spend" value={baselines?.unplanned_spend?"-"+(baselines.unplanned_spend.delta??73)+"%":"-73%"} delta={baselines?.unplanned_spend?"vs "+baselines.unplanned_spend.date?.slice(0,7):"Nov to Apr"} up color={T.green} accent={T.pdm}/>
      </div>
      <Card>
        <CH title="7 Business Rules" sub="Evaluated every 15 minutes against RUL forecasts"/>
        <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
          {(pdmRules.length?pdmRules:[]).map(([r,d,c]:any)=>(
            <div key={r} style={{background:T.s2,border:`1px solid ${c+'30'}`,borderRadius:6,padding:'5px 10px',display:'flex',alignItems:'center',gap:6}}>
              <span style={{fontSize:10,fontWeight:800,color:c}}>{r}</span><span style={{fontSize:10,color:T.m2}}>{d}</span>
            </div>
          ))}
        </div>
      </Card>
      {orders.map(o=>{
        const col=stC[o.status]||T.m2;
        return(
          <div key={o.id} style={{background:T.surface,border:`1px solid ${col+'40'}`,borderLeft:`4px solid ${col}`,borderRadius:11,padding:'14px 16px'}}>
            <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:9,flexWrap:'wrap'}}>
              <MTag text={o.id} color={col}/><Bdg label={o.status.replace('_',' ').toUpperCase()} color={col}/>
              <span style={{fontSize:13,fontWeight:700}}>{o.part}</span>
              <span style={{marginLeft:'auto',fontSize:11,color:T.m2}}>Asset: <strong style={{color:T.pdm}}>{o.asset}</strong></span>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:9,marginBottom:o.status!=='ordered'?10:6}}>
              {[['Qty',String(o.qty),T.txt],['Total',`Rs${o.cost.toLocaleString()}`,o.cost>5000?T.red:T.green],['RUL trigger',`${o.rul}d`,o.rul<15?T.red:T.pdm],['Lead Time',`${o.lead}d`,T.txt],['Rules fired',o.rules,T.oee]].map(([k,v,c])=>(
                <div key={k}><div style={{fontSize:9,color:T.m2,textTransform:'uppercase',marginBottom:3}}>{k}</div><div style={{fontSize:11,fontWeight:600,color:c}}>{v}</div></div>
              ))}
            </div>
            {o.status==='pending_approval'&&<div style={{display:'flex',gap:7}}><Btn v="accept" sm onClick={()=>approve(o.id)}>Approve & Raise PO</Btn><Btn sm>Reject</Btn></div>}
            {o.status==='escalated'&&<div style={{display:'flex',gap:7,alignItems:'center'}}><Btn v="danger" sm onClick={()=>approve(o.id)}>Approve Emergency PO</Btn><span style={{fontSize:10,color:T.m2}}>Plant Manager required</span></div>}
            {o.status==='ordered'&&<div style={{fontSize:11,color:T.green,fontWeight:700}}>PO raised - {o.po||''}</div>}
          </div>
        );
      })}
      <Card>
        <CH title="Spend Trend - 6 Months" sub="Planned vs unplanned"/>
        <ResponsiveContainer width="100%" height={140}>
          <BarChart data={spendTrend}>
            <CartesianGrid strokeDasharray="3 3" stroke={T.border}/>
            <XAxis dataKey="m" tick={{fill:T.m2,fontSize:10}}/><YAxis tick={{fill:T.m2,fontSize:10}} tickFormatter={v=>`Rs${(v/1000).toFixed(0)}k`}/>
            <Tooltip {...tt}/>
            <Bar dataKey="planned" fill={T.green} opacity={0.75} radius={[3,3,0,0]} name="Planned" stackId="a"/>
            <Bar dataKey="unplanned" fill={T.red} opacity={0.65} radius={[3,3,0,0]} name="Unplanned" stackId="a"/>
            <Legend wrapperStyle={{fontSize:11}}/>
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}

/* QUALITY VISION AGENT */
function QualityAgent(){
  const[tab,setTab]=useState('dashboard');
  return(
    <AgentPage quarter="Q3" title="Quality Vision Agent" tags={['Industrial cameras','NVIDIA Jetson ONNX','SAP QM']} target="Target: -60% defect escape, -35% inspection labour" accentCol={T.quality}
      tabs={[['dashboard','Dashboard'],['defects','Defect Log'],['lines','Line Quality'],['model','ML Model']]} activeTab={tab} setActiveTab={setTab}>
      {tab==='dashboard'&&<QualityDash/>}
      {tab==='defects'&&<QualityDefects/>}
      {tab==='lines'&&<QualityLines/>}
      {tab==='model'&&<QualityModel/>}
    </AgentPage>
  );
}
function QualityDash(){
  const{qualityLines,baselines,defectTrend,defectLog}=useApp();
  return(
    <div style={scroll}>
      <div style={{background:T.quDim,border:`1px solid ${T.quality}25`,borderRadius:10,padding:'12px 16px'}}>
        <div style={{fontSize:12,fontWeight:700,color:T.quality,marginBottom:6}}>How It Works</div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:10}}>
          {[['Edge Capture','Industrial cameras stream frames to NVIDIA Jetson. ONNX-optimised defect detection runs at <10ms.'],['AI Classification','Defect classified, part rejected or flagged, quality data logged to MES in real-time.'],['Federated Learning','Model retraining across plants without raw image data leaving site. SAP QM non-conformance auto-created.']].map(([t,d])=>(
            <div key={t} style={{background:T.surface,borderRadius:8,padding:'10px 12px',border:`1px solid ${T.border}`}}>
              <div style={{fontSize:11,fontWeight:700,color:T.quality,marginBottom:4}}>{t}</div>
              <div style={{fontSize:11,color:T.m2,lineHeight:1.5}}>{d}</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
        <Kpi label="Plant Quality Rate" value={qualityLines.length?+(qualityLines.reduce((s:number,l:any)=>s+Number(l.rate??0),0)/qualityLines.length).toFixed(1)+"%":"--"} delta="+1.4% vs baseline" up color={T.green} accent={T.quality}/>
        <Kpi label="Defect Escape Rate" value={baselines?.defect_escape?"-"+(baselines.defect_escape.delta??62)+"%":"-62%"} delta={baselines?.defect_escape?"target "+(-baselines.defect_escape.target)+"%":"target -60%"} up color={T.green} accent={T.quality}/>
        <Kpi label="Defects Today" value={String(qualityLines.reduce((s:number,l:any)=>s+Number(l.defects??0),0)||'--')} sub="4 lines" color={T.red} accent={T.quality}/>
        <Kpi label="Inspection Labour" value={baselines?.inspection_labour?"-"+(baselines.inspection_labour.delta??38)+"%":"-38%"} delta={baselines?.inspection_labour?"target "+(-baselines.inspection_labour.target)+"%":"target -35%"} up color={T.green} accent={T.quality}/>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Card>
          <CH title="Defect Trend - Today (Hourly)" sub="Real-time MES logging"/>
          <ResponsiveContainer width="100%" height={140}>
            <BarChart data={defectTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke={T.border}/>
              <XAxis dataKey="h" tick={{fill:T.m2,fontSize:10}}/><YAxis tick={{fill:T.m2,fontSize:10}}/>
              <Tooltip {...tt}/>
              <Bar dataKey="defects" fill={T.quality} opacity={0.8} radius={[3,3,0,0]} name="Defects"/>
            </BarChart>
          </ResponsiveContainer>
        </Card>
        <Card>
          <CH title="Defect Types Detected" sub="ONNX model - <10ms edge inference"/>
          {(()=>{
            // Build defect type breakdown from live quality_defects.csv data
            const colMap:Record<string,string>={
              'Surface cracks':T.red,'Dimensional tolerance':T.amber,
              'Assembly misalignment':T.quality,'Foreign object':'#ca8a04','Colour / coating':T.m2
            };
            const counts:Record<string,number>={};
            for(const d of defectLog as any[]){
              const t=d.type??d.defect_type??'Other';
              counts[t]=(counts[t]||0)+1;
            }
            const total=Object.values(counts).reduce((s:number,n:any)=>s+Number(n),0)||1;
            const rows=Object.entries(counts)
              .sort((a,b)=>Number(b[1])-Number(a[1]))
              .slice(0,5)
              .map(([type,n])=>({type,pct:Math.round(Number(n)/total*100),col:colMap[type]||T.m2}));
            // If no data yet show loading placeholder
            if(!rows.length) return <div style={{fontSize:11,color:T.m2,padding:'8px 0'}}>Loading defect data...</div>;
            return rows.map(({type,pct,col})=>(
              <div key={type} style={{marginBottom:7}}>
                <div style={{display:'flex',justifyContent:'space-between',fontSize:11,marginBottom:3}}><span style={{fontWeight:600}}>{type}</span><span style={{color:col,fontWeight:700}}>{pct}%</span></div>
                <div style={{height:5,background:T.s3,borderRadius:3}}><div style={{height:5,width:`${pct}%`,background:col,borderRadius:3}}/></div>
              </div>
            ));
          })()}
        </Card>
      </div>
      <div style={{background:T.sDim,border:`1px solid ${T.sem}25`,borderRadius:9,padding:'10px 14px',fontSize:11,color:T.m2}}>
        AI Semantic Layer maps defect type, component, production line, and quality event entities - enabling natural language queries like "Which component has the highest defect rate across all plants this week?" without SQL.
      </div>
    </div>
  );
}
// [DEDUPLICATED: QualityDefects]

// [DEDUPLICATED: QualityLines]



function QualityDefects(){
  const{defectLog}=useApp();
  return(
    <div style={scroll}>
      <CH title="Defect Log - Real-time" sub="Industrial camera → Jetson → MES - SAP QM non-conformance auto-created" right={<Bdg label="3 major today" color={T.red}/>}/>
      {defectLog.map((d:any)=>{
        const col=d.severity==='major'?T.red:T.amber;
        return(
          <div key={d.id} style={{background:T.surface,border:`1px solid ${col+'40'}`,borderLeft:`4px solid ${col}`,borderRadius:11,padding:'13px 15px'}}>
            <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:9,flexWrap:'wrap'}}>
              <MTag text={d.id} color={col}/><Bdg label={d.severity.toUpperCase()} color={col}/>
              <Bdg label={d.type} color={T.quality}/><Bdg label={d.action} color={d.action==='Rejected'?T.red:T.amber}/>
              <span style={{fontSize:12,fontWeight:700}}>{d.component}</span>
              <span style={{marginLeft:'auto',fontSize:11,color:T.m2}}>{d.time} - {d.line}</span>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10}}>
              {[['Defect Type',d.type,T.txt],['Action',d.action,col],['AI Confidence',`${(d.confidence*100).toFixed(0)}%`,d.confidence>0.95?T.green:T.amber]].map(([k,v,c])=>(
                <div key={k}><div style={{fontSize:9,color:T.m2,textTransform:'uppercase',marginBottom:3}}>{k}</div><div style={{fontSize:12,fontWeight:600,color:c}}>{v}</div></div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
function QualityLines(){
  const{qualityLines}=useApp();
  return(
    <div style={scroll}>
      <CH title="Line Quality Dashboard" sub="All 4 production lines - Federated model retraining across plants"/>
      <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:12}}>
        {qualityLines.map((l:any)=>{
          const col=l.rate>=99?T.green:l.rate>=98?T.amber:T.red;
          return(
            <Card key={l.line}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:10}}>
                <span style={{fontSize:13,fontWeight:700}}>{l.line}</span>
                <Bdg label={`Model ${l.model}`} color={T.quality}/>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:9,marginBottom:10}}>
                {[['Quality Rate',`${l.rate}%`,col],['Defects Today',String(l.defects),l.defects>10?T.red:T.amber],['Escapes',String(l.escapes),l.escapes>0?T.red:T.green]].map(([k,v,c])=>(
                  <div key={k} style={{background:T.s2,borderRadius:8,padding:'8px 10px',border:`1px solid ${T.border}`,textAlign:'center'}}>
                    <div style={{fontSize:9,color:T.m2,textTransform:'uppercase',marginBottom:3}}>{k}</div>
                    <div style={{fontSize:18,fontWeight:800,color:c}}>{v}</div>
                  </div>
                ))}
              </div>
              <div style={{height:6,background:T.s3,borderRadius:3}}><div style={{height:6,width:`${l.rate}%`,background:col,borderRadius:3}}/></div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
function QualityModel(){
  const{appCfg:shApp}=useSharedCfg();
  const MQ=shApp?.qualityModel??[];
  const FQ=shApp?.qualityFeats??[];
  return(
    <div style={scroll}>
      <CH title="Vision ML Model - ONNX Edge Inference" sub="Federated retraining - NVIDIA Jetson TensorRT - SAP QM trigger" right={<><Bdg label="v3.1 deployed" color={T.green}/><Bdg label="mAP=0.964" color={T.quality}/></>}/>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:11}}>
        <Kpi label="mAP Score" value={String(shApp?.qualityKpis?.map_score??0)} delta="+0.016 vs prev" up color={T.green} accent={T.quality}/>
        <Kpi label="Precision" value={String(shApp?.qualityKpis?.precision??0)} sub="Low false positives" color={T.quality} accent={T.quality}/>
        <Kpi label="Edge Latency" value="<10ms" sub="ONNX TensorRT" color={T.parts} accent={T.quality}/>
        <Kpi label="Defect Types" value={String(shApp?.qualityFeats?.length??0)} sub="Federated retraining" color={T.oee} accent={T.quality}/>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Card><CH title="Feature Importance"/>{FQ.map(f=><FeatBar key={f.f} label={f.f} pct={f.v} col={T.quality}/>)}</Card>
        <Card>
          <CH title="Training History"/>
          {MQ.map(r=>(
            <div key={r.date} style={{background:T.s2,border:`1px solid ${T.border}`,borderLeft:`3px solid ${r.status==='deployed'?T.green:T.border}`,borderRadius:8,padding:'11px 14px',marginBottom:8}}>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}><span style={{fontSize:12,fontWeight:700}}>{r.date}</span><Bdg label={r.status.toUpperCase()} color={r.status==='deployed'?T.green:T.m2}/></div>
              <div style={{fontSize:11,color:T.m2}}>mAP {r.mAP} - Prec {r.precision} - {r.samples.toLocaleString()} samples</div>
            </div>
          ))}
        </Card>
      </div>
      <Card><CH title="Federated Retraining" sub="Raw images never leave plant - gradient aggregation only"/>
        <RetBtn phases={['Local feature extraction on Jetson gateways...','Federated gradient aggregation...','Central model update...','ONNX quantisation (INT8)...','Edge deployment to all Jetson gateways...']} col={T.quality} label="v3.2 deployed mAP=0.967"/>
      </Card>
    </div>
  );
}

/* ENERGY OPTIMISATION AGENT */
function EnergyAgent(){
  const[tab,setTab]=useState('dashboard');
  return(
    <AgentPage quarter="Q3" title="Energy Optimisation Agent" tags={['Smart meters','SCADA','Grid pricing API']} target="Target: -15% energy cost, -12% carbon intensity" accentCol={T.energy}
      tabs={[['dashboard','Dashboard'],['waste','Waste Detection'],['dispatch','Load Dispatch'],['iso50001','ISO 50001']]} activeTab={tab} setActiveTab={setTab}>
      {tab==='dashboard'&&<EnergyDash/>}
      {tab==='waste'&&<EnergyWaste/>}
      {tab==='dispatch'&&<EnergyDispatch/>}
      {tab==='iso50001'&&<EnergyISO/>}
    </AgentPage>
  );
}
function EnergyDash(){
  const{energyTrend,energyAssets,carbonTrend,baselines,energyWaste}=useApp();
  return(
    <div style={scroll}>
      <div style={{background:T.enDim,border:`1px solid ${T.energy}25`,borderRadius:10,padding:'12px 16px'}}>
        <div style={{fontSize:12,fontWeight:700,color:T.energy,marginBottom:6}}>How It Works</div>
        <div style={{fontSize:11,color:T.m2,lineHeight:1.6}}>Smart meters, SCADA, and grid pricing APIs stream energy data to an AI engine profiling load by asset and shift. The model identifies demand flexibility and dispatches load adjustments autonomously. Carbon intensity feeds ESG reporting pipelines automatically.</div>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
        <Kpi label="Energy Cost" value={baselines?.energy_cost?"-"+(baselines.energy_cost.delta??13.2)+"%":"-13.2%"} delta={baselines?.energy_cost?"target "+(-baselines.energy_cost.target)+"%":"target -15%"} up color={T.green} accent={T.energy}/>
        <Kpi label="Carbon Intensity" value={(carbonTrend.length?Number(carbonTrend[carbonTrend.length-1].v??0.69).toFixed(2):0.69)+" kg"} sub="kgCO2/unit, -12% vs Nov" color={T.supply} accent={T.energy}/>
        <Kpi label="Peak Demand" value={(energyAssets.length?energyAssets.reduce((s:number,a:any)=>s+Number(a.kw??0),0).toLocaleString():"1,612")+" kW"} delta="+4% above target" up={false} color={T.red} accent={T.energy}/>
        <Kpi label="Waste Patterns" value={String(energyWaste.length||5)} sub={"Rs "+energyWaste.reduce((s:number,w:any)=>s+Number(w.cost??0),0).toLocaleString()+" today"} color={T.amber} accent={T.energy}/>
      </div>
      <Card>
        <CH title="Plant Energy Load - 24h" sub="Smart meters + SCADA - anomalies flagged within 15 minutes"/>
        <ResponsiveContainer width="100%" height={160}>
          <AreaChart data={energyTrend}>
            <defs><linearGradient id="egg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={T.energy} stopOpacity={0.2}/><stop offset="95%" stopColor={T.energy} stopOpacity={0}/></linearGradient></defs>
            <CartesianGrid strokeDasharray="3 3" stroke={T.border}/>
            <XAxis dataKey="h" tick={{fill:T.m2,fontSize:10}} interval={2}/><YAxis tick={{fill:T.m2,fontSize:10}} tickFormatter={v=>`${v}kW`}/>
            <Tooltip {...tt}/><ReferenceLine y={1600} stroke={T.red} strokeDasharray="4 4" label={{value:'Peak penalty threshold',fill:T.red,fontSize:9}}/>
            <Area type="monotone" dataKey="kw" stroke={T.energy} fill="url(#egg)" strokeWidth={2} name="Load kW"/>
          </AreaChart>
        </ResponsiveContainer>
      </Card>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Card>
          <CH title="Asset-Level Energy Profile" sub="kW by machine - anomalies flagged"/>
          {energyAssets.map(a=>(
            <div key={a.id} style={{display:'flex',alignItems:'center',gap:10,padding:'7px 0',borderBottom:`1px solid ${T.border}`}}>
              <div style={{flex:1}}><div style={{fontSize:11,fontWeight:600}}>{a.name}</div><div style={{fontSize:9,color:T.m2}}>{a.id}</div></div>
              <div style={{fontSize:13,fontWeight:700,color:a.anomaly?T.red:T.txt}}>{a.kw} kW</div>
              {a.anomaly&&<Bdg label="ANOMALY" color={T.red} sm/>}
            </div>
          ))}
        </Card>
        <Card>
          <CH title="Carbon Intensity Trend" sub="kgCO2/unit - ISO 50001 target"/>
          <ResponsiveContainer width="100%" height={150}>
            <LineChart data={carbonTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke={T.border}/>
              <XAxis dataKey="m" tick={{fill:T.m2,fontSize:10}}/><YAxis domain={[0.6,0.9]} tick={{fill:T.m2,fontSize:10}}/>
              <Tooltip {...tt}/>
              <Line type="monotone" dataKey="v" stroke={T.supply} strokeWidth={2} dot={{fill:T.supply,r:3}} name="kgCO2/unit"/>
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>
      <div style={{background:T.sDim,border:`1px solid ${T.sem}25`,borderRadius:9,padding:'10px 14px',fontSize:11,color:T.m2}}>
        Energy KPIs (kWh/unit, carbon intensity, peak demand %) governed consistently across all plants via Semantic Layer - enabling cross-plant benchmarking and ISO 50001 automated reporting without per-plant data reconciliation.
      </div>
    </div>
  );
}
function EnergyWaste(){
  const{energyWaste}=useApp();
  return(
    <div style={scroll}>
      <CH title="Energy Waste Patterns Detected" sub="Anomaly detection within 15 minutes - root-cause attribution to specific asset" right={<Bdg label={`Rs${energyWaste.reduce((s:number,w:any)=>s+w.cost,0).toLocaleString()} today`} color={T.red}/>}/>
      <div style={{background:T.enDim,border:`1px solid ${T.energy}25`,borderRadius:9,padding:'10px 14px',fontSize:11,color:T.m2}}>
        Patterns monitored: Idle phantom loads - Peak demand spikes - Compressed air leakage - HVAC overcooling - Motor inefficiency from voltage imbalance - Furnace heat cycling - Lighting outside production windows
      </div>
      {energyWaste.map((w:any)=>(
        <div key={w.type} style={{background:T.surface,border:`1px solid ${T.red+'30'}`,borderLeft:`4px solid ${T.energy}`,borderRadius:11,padding:'13px 15px'}}>
          <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:9}}>
            <Bdg label="WASTE DETECTED" color={T.energy}/><span style={{fontSize:13,fontWeight:700}}>{w.type}</span>
            <span style={{marginLeft:'auto',fontSize:11,color:T.m2}}>Asset: <strong style={{color:T.pdm}}>{w.asset}</strong></span>
          </div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:9}}>
            {[['Energy Wasted',`${w.kwh} kWh`,T.amber],['Cost Today',`Rs${w.cost.toLocaleString()}`,T.red],['Root Asset',w.asset,T.energy]].map(([k,v,c])=>(
              <div key={k}><div style={{fontSize:9,color:T.m2,textTransform:'uppercase',marginBottom:3}}>{k}</div><div style={{fontSize:14,fontWeight:700,color:c}}>{v}</div></div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
function EnergyDispatch(){
  const[actions,setActions]=useState<any[]>([]);
  useEffect(()=>{fetchEnergyDispatch().then(d=>{if(d.length)setActions(d);}).catch(()=>{});},[]);
  const dispatch=id=>setActions(as=>as.map(a=>a.id===id?{...a,status:'dispatched'}:a));
  return(
    <div style={scroll}>
      <CH title="Autonomous Load Dispatch" sub="Grid price signal response - SCADA set-point write-back - closed-loop autonomous dispatch"/>
      {actions.map(a=>{
        const col=a.status==='dispatched'?T.green:T.energy;
        return(
          <div key={a.id} style={{background:T.surface,border:`1px solid ${T.border}`,borderLeft:`4px solid ${col}`,borderRadius:11,padding:'13px 15px'}}>
            <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:9}}>
              <Bdg label={a.type} color={T.energy}/><span style={{fontSize:13,fontWeight:700}}>{a.asset}</span>
              <Bdg label={a.status.toUpperCase()} color={col}/><span style={{marginLeft:'auto',fontSize:11,color:T.green,fontWeight:700}}>{a.saving}</span>
            </div>
            <div style={{fontSize:12,color:T.m2,marginBottom:a.status==='pending'?9:0}}>{a.action}</div>
            {a.status==='pending'&&<div style={{display:'flex',gap:7}}><Btn v="primary" sm onClick={()=>dispatch(a.id)}>Dispatch via SCADA</Btn><Btn sm>Schedule Later</Btn></div>}
            {a.status==='dispatched'&&<div style={{fontSize:11,color:T.green,fontWeight:700}}>Dispatched via SCADA set-point write-back</div>}
          </div>
        );
      })}
    </div>
  );
}
function EnergyISO(){
  const{carbonTrend,baselines}=useApp();
  return(
    <div style={scroll}>
      <CH title="ISO 50001 Compliance Reporting" sub="Automated - no manual pack preparation - Carbon intensity feeds ESG pipelines" right={<Bdg label="Automated" color={T.green}/>}/>
      <div style={{background:T.suDim,border:`1px solid ${T.supply}25`,borderRadius:9,padding:'12px 16px'}}>
        <div style={{fontSize:12,fontWeight:700,color:T.supply,marginBottom:6}}>ISO 50001 Status</div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
          {[
            ['EnPI (kWh/unit)', carbonTrend.length?Number(carbonTrend[carbonTrend.length-1].v??0.69).toFixed(2):'--', baselines?.energy_enpi_target?'Target: '+baselines.energy_enpi_target.target:'Target: 2.30', T.amber],
            ['Carbon Intensity', carbonTrend.length?Number(carbonTrend[carbonTrend.length-1].v??0).toFixed(2)+' kg':'--', baselines?.carbon_target?'Target: '+baselines.carbon_target.target:'Target: 0.65', T.amber],
            ['Energy Review', 'Automated', 'Continuous via Semantic Layer', T.green],
            ['Report Status', baselines?.energy_report_status?baselines.energy_report_status.current??'On track':'On track', 'ISO 50001', T.green],
          ].map(([k,v,s,c])=>(
            <div key={k} style={{background:T.surface,borderRadius:8,padding:'10px 12px',border:`1px solid ${T.border}`}}>
              <div style={{fontSize:9,color:T.m2,textTransform:'uppercase',marginBottom:3}}>{k}</div>
              <div style={{fontSize:18,fontWeight:800,color:c}}>{v}</div>
              <div style={{fontSize:10,color:T.m2,marginTop:3}}>{s}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* SUPPLY CHAIN RESILIENCE AGENT */
function SupplyAgent(){
  const[tab,setTab]=useState('dashboard');
  return(
    <AgentPage quarter="Q3" title="Supply Chain Resilience Agent" tags={['ERP','External risk signals','SAP MM','Oracle']} target="Target: -20% inventory cost, -35% disruptions" accentCol={T.supply}
      tabs={[['dashboard','Dashboard'],['risks','Risk Monitor'],['forecast','Demand Forecast'],['inventory','Inventory']]} activeTab={tab} setActiveTab={setTab}>
      {tab==='dashboard'&&<SupplyDash/>}
      {tab==='risks'&&<SupplyRisks/>}
      {tab==='forecast'&&<SupplyForecast/>}
      {tab==='inventory'&&<SupplyInventory/>}
    </AgentPage>
  );
}
function SupplyDash(){
  const{supplyRisksData,baselines}=useApp();
  return(
    <div style={scroll}>
      <div style={{background:T.suDim,border:`1px solid ${T.supply}25`,borderRadius:10,padding:'12px 16px'}}>
        <div style={{fontSize:12,fontWeight:700,color:T.supply,marginBottom:6}}>How It Works</div>
        <div style={{fontSize:11,color:T.m2,lineHeight:1.6}}>ERP orders and inventory are fused with external risk signals (supplier health, weather, port congestion). ML model predicts supply shortfalls 4-8 weeks ahead and generates ranked recommendations: autonomous reorder, alternate sourcing, or safety stock adjustment.</div>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
        <Kpi label="High-Risk Suppliers" value={String(supplyRisksData.filter((r:any)=>r.risk==="critical"||r.risk==="high").length||2)} delta="shortfall predicted" up={false} color={T.red} accent={T.supply}/>
        <Kpi label="Inventory Cost" value={baselines?.inventory_cost?"-"+baselines.inventory_cost.delta+"%":"-18%"} delta="target -20%" up color={T.green} accent={T.supply}/>
        <Kpi label="Forecast Accuracy" value={baselines?.forecast_accuracy?"+"+(baselines.forecast_accuracy.delta??17.4)+"%":"+17.4%"} delta={baselines?.forecast_accuracy?"target +"+baselines.forecast_accuracy.target+"%":"target +18%"} up color={T.green} accent={T.supply}/>
        <Kpi label="Disruption Events" value={baselines?.disruption_events?"-"+(baselines.disruption_events.delta??32)+"%":"-32%"} delta={baselines?.disruption_events?"target "+(-baselines.disruption_events.target)+"%":"target -35%"} up color={T.green} accent={T.supply}/>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Card>
          <CH title="Supply Risk Signals Monitored" sub="Continuous external signal feed"/>
          {(()=>{
            // Compute signal counts from live supply_risks.csv data
            const sr=supplyRisksData as any[];
            const signals=[
              {signal:'Supplier financial distress',count:sr.filter(r=>r.reason==='Financial distress').length,col:T.red,unit:'flagged'},
              {signal:'Single-source dependency',count:sr.filter(r=>r.singleSource).length,col:T.amber,unit:'SKUs'},
              {signal:'Lead time drift vs SLAs',count:sr.filter(r=>Number(r.leadDrift??0)>5).length,col:T.energy,unit:'suppliers'},
              {signal:'Critical stock level',count:sr.filter(r=>Number(r.stockDays??0)<14).length,col:T.red,unit:'critical'},
              {signal:'High-risk suppliers',count:sr.filter(r=>r.risk==='high'||r.risk==='critical').length,col:T.amber,unit:'high risk'},
              {signal:'Geopolitical risk',count:sr.filter(r=>r.reason==='Geopolitical risk').length,col:T.red,unit:'regions'},
            ];
            if(!sr.length) return <div style={{fontSize:11,color:T.m2,padding:'8px 0'}}>Loading supply risk data...</div>;
            return signals.map(({signal,count,col,unit})=>(
              <div key={signal} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'7px 0',borderBottom:`1px solid ${T.border}`}}>
                <span style={{fontSize:11,fontWeight:600}}>{signal}</span>
                <Bdg label={count>0?`${count} ${unit}`:'0 '+unit} color={count>0?col:T.m2}/>
              </div>
            ));
          })()}
        </Card>
        <Card>
          <CH title="Shortfall Predictions 4-8 Week Horizon" sub="ML model - autonomous reorder trigger in SAP MM"/>
          {supplyRisksData.filter((r:any)=>r.risk!=='low').map((r:any)=>{
            const col={high:T.red,medium:T.amber}[r.risk]||T.m2;
            return(
              <div key={r.supplier} style={{background:T.s2,border:`1px solid ${col+'30'}`,borderLeft:`3px solid ${col}`,borderRadius:8,padding:'9px 11px',marginBottom:7}}>
                <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:4}}><Bdg label={r.risk.toUpperCase()} color={col} sm/><span style={{fontSize:11,fontWeight:700}}>{r.supplier}</span><span style={{marginLeft:'auto',fontSize:10,color:T.m2}}>{r.exposure}</span></div>
                <div style={{fontSize:10,color:T.m2}}>{r.reason} - Lead drift: +{r.leadDrift}d</div>
                <div style={{fontSize:10,color:T.supply,fontWeight:700,marginTop:4}}>→ {r.action}</div>
              </div>
            );
          })}
        </Card>
      </div>
      <div style={{background:T.sDim,border:`1px solid ${T.sem}25`,borderRadius:9,padding:'10px 14px',fontSize:11,color:T.m2}}>
        Supplier, SKU, inventory, demand, and risk event entities normalised across all ERP instances via Semantic Layer. NL query: "Which top 20 suppliers have financial distress AND &gt;30-day lead time drift this quarter?" with no SQL.
      </div>
    </div>
  );
}
function SupplyRisks(){
  const{supplyRisksData}=useApp();
  return(
    <div style={scroll}>
      <CH title="Supplier Risk Monitor" sub="Continuous external signal fusion - shortfall predicted 4-8 weeks ahead"/>
      {supplyRisksData.map((r:any)=>{
        const col={high:T.red,medium:T.amber,low:T.green}[r.risk];
        return(
          <div key={r.supplier} style={{background:T.surface,border:`1px solid ${col+'40'}`,borderLeft:`4px solid ${col}`,borderRadius:11,padding:'13px 15px'}}>
            <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:9}}>
              <Bdg label={r.risk.toUpperCase()} color={col}/><span style={{fontSize:13,fontWeight:700}}>{r.supplier}</span>
              <MTag text={r.sku} color={T.supply}/><span style={{marginLeft:'auto',fontSize:12,fontWeight:700,color:T.red}}>{r.exposure}</span>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:9,marginBottom:r.risk!=='low'?9:0}}>
              {[['Risk Signal',r.reason,col],['Lead Drift',`+${r.leadDrift}d`,r.leadDrift>10?T.red:T.amber],['Exposure',r.exposure,T.txt],['Action',r.action,T.supply]].map(([k,v,c])=>(
                <div key={k}><div style={{fontSize:9,color:T.m2,textTransform:'uppercase',marginBottom:3}}>{k}</div><div style={{fontSize:11,fontWeight:600,color:c}}>{v}</div></div>
              ))}
            </div>
            {r.risk!=='low'&&<Btn v="blue" sm>Trigger SAP MM Reorder</Btn>}
          </div>
        );
      })}
    </div>
  );
}
function SupplyForecast(){
  const{demandForecast}=useApp();
  return(
    <div style={scroll}>
      <CH title="Demand Sensing - 4-8 Week Forecast" sub="Fuses historical + real-time market signals - +17.4% accuracy vs baseline"/>
      <Card>
        <CH title="Demand Forecast - Compound X-12 (kg/week)" sub="Actual + forecast"/>
        <ResponsiveContainer width="100%" height={200}>
          <ComposedChart data={demandForecast}>
            <CartesianGrid strokeDasharray="3 3" stroke={T.border}/>
            <XAxis dataKey="w" tick={{fill:T.m2,fontSize:10}}/><YAxis domain={[2200,2800]} tick={{fill:T.m2,fontSize:10}}/>
            <Tooltip {...tt}/>
            <Bar dataKey="actual" fill={T.supply} opacity={0.7} name="Actual" radius={[3,3,0,0]}/>
            <Line type="monotone" dataKey="forecast" stroke={T.amber} strokeWidth={2} strokeDasharray="6 3" dot={{fill:T.amber,r:3}} name="Forecast"/>
            <Legend wrapperStyle={{fontSize:11}}/>
          </ComposedChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}
function SupplyInventory(){
  const{supplyRisksData}=useApp();
  return(
    <div style={scroll}>
      <CH title="Inventory Optimisation" sub="Safety stock recommendations - -20% carrying cost target"/>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10}}>
        {[
          ['Total SKUs Monitored', String(supplyRisksData.length||'--'), T.supply, 'Across tracked suppliers'],
          ['High-Risk Suppliers', String(supplyRisksData.filter((r:any)=>r.risk==='critical'||r.risk==='high').length||0), T.amber, 'Critical or high risk'],
          ['Actions Required', String(supplyRisksData.filter((r:any)=>r.risk==='critical').length||0), T.green, 'Emergency PO or expedite'],
        ].map(([l,v,c,s])=>(
          <div key={l} style={{background:T.surface,border:`1px solid ${T.border}`,borderTop:`3px solid ${c}`,borderRadius:11,padding:'14px 15px',boxShadow:'0 1px 4px rgba(0,0,0,.05)'}}>
            <div style={{fontSize:11,color:T.m2,marginBottom:6}}>{l}</div>
            <div style={{fontSize:28,fontWeight:800,color:c}}>{v}</div>
            <div style={{fontSize:10,color:T.m3,marginTop:4}}>{s}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* DIGITAL TWIN OPERATIONS AGENT */
function TwinAgent(){
  const[tab,setTab]=useState('dashboard');
  return(
    <AgentPage quarter="Q4" title="Digital Twin Operations Agent" tags={['AVEVA/Bentley iTwin','OSIsoft PI','IIoT']} target="Target: 96h divergence detection, +6-10% throughput" accentCol={T.twin}
      tabs={[['dashboard','Dashboard'],['scenarios','Scenarios'],['divergence','Divergence'],['calibration','Calibration']]} activeTab={tab} setActiveTab={setTab}>
      {tab==='dashboard'&&<TwinDash/>}
      {tab==='scenarios'&&<TwinScenarios/>}
      {tab==='divergence'&&<TwinDivergence/>}
      {tab==='calibration'&&<TwinCalibration/>}
    </AgentPage>
  );
}
function TwinDash(){
  const{twinScenarios,divergenceLog,baselines}=useApp();
  return(
    <div style={scroll}>
      <div style={{background:T.twDim,border:`1px solid ${T.twin}25`,borderRadius:10,padding:'12px 16px'}}>
        <div style={{fontSize:12,fontWeight:700,color:T.twin,marginBottom:6}}>How It Works</div>
        <div style={{fontSize:11,color:T.m2,lineHeight:1.6}}>A physics-accurate digital replica is built on AVEVA/Bentley iTwin and synchronised with live PI System and IIoT data. The AI layer runs divergence detection, what-if scenario simulation, and prescriptive set-point recommendations optimising throughput and energy.</div>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
        <Kpi label="Twin Sync Status" value="Live" sub="Updated every 30s" color={T.green} accent={T.twin}/>
        <Kpi label="Diverging KPIs" value={String(divergenceLog.filter((d:any)=>d.status==="diverging").length||4)} delta="divergence detected" up={false} color={T.red} accent={T.twin}/>
        <Kpi label="Active Scenarios" value={String(twinScenarios.filter((s:any)=>s.status==="running"||s.status==="pending").length||3)} sub="1 running, 2 queued" color={T.twin} accent={T.twin}/>
        <Kpi label="Throughput Uplift" value={baselines?.throughput_uplift?"+"+(baselines.throughput_uplift.current??7.2)+"%":"+7.2%"} delta={baselines?.throughput_uplift?baselines.throughput_uplift.note?.slice(0,20)??"from scenario optim.":"from scenario optim."} up color={T.green} accent={T.twin}/>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Card>
          <CH title="Active Scenarios" sub="Simulation results"/>
          {twinScenarios.map((s:any)=>{
            const col={running:T.twin,complete:T.green,pending:T.amber}[s.status];
            return(
              <div key={s.id} style={{background:T.s2,border:`1px solid ${col+'30'}`,borderLeft:`3px solid ${col}`,borderRadius:8,padding:'10px 12px',marginBottom:8}}>
                <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:5}}><Bdg label={s.status.toUpperCase()} color={col}/><span style={{fontSize:11,fontWeight:700}}>{s.name}</span></div>
                <div style={{fontSize:11,color:T.green,fontWeight:700,marginBottom:3}}>{s.impact}</div>
                <div style={{fontSize:10,color:T.m2}}>Confidence: {(s.confidence*100).toFixed(0)}% - Horizon: {s.horizon}</div>
              </div>
            );
          })}
        </Card>
        <Card>
          <CH title="Multi-Agent Hub Connections" sub="Receives from PdM, feeds Yield, shares Energy"/>
          {[['pdm','PdM Agent','RUL forecasts -> twin degradation model',T.pdm],['yield','Yield Agent','Twin recommends set-points -> DCS',T.yield],['energy','Energy Agent','Twin energy model -> load schedules',T.energy],['oee','OEE Agent','Twin OEE simulation -> gap attribution',T.oee]].map(([id,agent,flow,col])=>(
            <div key={id} style={{display:'flex',alignItems:'center',gap:10,padding:'7px 0',borderBottom:`1px solid ${T.border}`}}>
              <AgChip agent={id}/><div style={{flex:1}}><div style={{fontSize:10,fontWeight:700}}>{agent}</div><div style={{fontSize:10,color:T.m2}}>{flow}</div></div>
            </div>
          ))}
        </Card>
      </div>
      <div style={{background:T.sDim,border:`1px solid ${T.sem}25`,borderRadius:9,padding:'10px 14px',fontSize:11,color:T.m2}}>
        Twin state, scenario outputs, and scheduled events published via semantic layer - every downstream agent consumes twin data with consistent entity references, eliminating cross-agent semantic drift.
      </div>
    </div>
  );
}
function TwinScenarios(){
  const[scenarios,setScenarios]=useState<any[]>([]);
  useEffect(()=>{fetchTwinScenarios().then(d=>{if(Array.isArray(d)&&d.length)setScenarios(d);}).catch(()=>{});},[]);
  return(
    <div style={scroll}>
      <CH title="Operational Scenarios Simulated" sub="Physics-accurate digital twin - prescriptive recommendations - continuous self-calibration"/>
      {!scenarios.length&&<div style={{padding:20,textAlign:'center',color:T.m2,fontSize:12}}>Loading scenarios from twin_scenarios.csv...</div>}
      {scenarios.map((s:any)=>{
        const col=({complete:T.green,running:T.twin,pending:T.amber} as any)[s.status]||T.m2;
        return(
          <div key={s.name} style={{background:T.surface,border:`1px solid ${T.border}`,borderLeft:`4px solid ${col}`,borderRadius:11,padding:'13px 15px'}}>
            <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:9}}><Bdg label={s.type||s.scenario_type||'Scenario'} color={T.twin}/><Bdg label={(s.status||'pending').toUpperCase()} color={col}/><span style={{fontSize:13,fontWeight:700}}>{s.name||s.scenario_name}</span></div>
            <div style={{fontSize:12,color:T.m2,lineHeight:1.5,marginBottom:7}}>{s.desc||s.description||s.scenario_desc||''}</div>
            {s.status!=='pending'&&s.result&&<div style={{fontSize:12,color:T.green,fontWeight:700}}>Result: {s.result}</div>}
            {s.status==='pending'&&<Btn v="primary" sm>Run Simulation</Btn>}
            {s.confidence&&<div style={{fontSize:10,color:T.m2,marginTop:4}}>Confidence: {(s.confidence*100).toFixed(0)}%</div>}
          </div>
        );
      })}
    </div>
  );
}
function TwinDivergence(){
  const{divergenceLog}=useApp();
  return(
    <div style={scroll}>
      <CH title="Divergence Detection - 96h Ahead of Threshold" sub="Live PI System vs Digital Twin - alert before threshold breach" right={<Bdg label="96h ahead" color={T.green}/>}/>
      {divergenceLog.map((d:any)=>{
        const col={critical:T.red,diverging:T.amber,aligned:T.green}[d.status];
        return(
          <div key={d.kpi} style={{background:T.surface,border:`1px solid ${col+'40'}`,borderLeft:`4px solid ${col}`,borderRadius:10,padding:'13px 15px'}}>
            <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:9}}>
              <Bdg label={d.status.toUpperCase()} color={col}/><span style={{fontSize:13,fontWeight:700}}>{d.kpi}</span>
              <span style={{marginLeft:'auto',fontSize:10,color:T.m2}}>{d.time}</span>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:9}}>
              {[['Actual',String(d.actual),T.txt],['Twin Expected',String(d.twin),T.twin],['Delta',d.delta,d.delta!=='0'?col:T.green],['Status',d.status,col]].map(([k,v,c])=>(
                <div key={k}><div style={{fontSize:9,color:T.m2,textTransform:'uppercase',marginBottom:3}}>{k}</div><div style={{fontSize:13,fontWeight:700,color:c}}>{v}</div></div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
function TwinCalibration(){
  const{divergenceLog,baselines}=useApp();
  return(
    <div style={scroll}>
      <CH title="Continuous Self-Calibration" sub="Live sensor feeds improve twin accuracy without re-parameterisation"/>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10}}>
        {[
          ['Twin Accuracy', baselines?.twin_accuracy?String(baselines.twin_accuracy.current)+'%':'--', 'vs deployment baseline', T.green],
          ['Sync Frequency', '30s', 'Auto-sync from PI + IoT Hub', T.twin],
          ['Diverging KPIs', String(divergenceLog.filter((d:any)=>d.status==='diverging').length), 'vs digital twin model', T.oee],
        ].map(([l,v,s,c])=>(
          <div key={l} style={{background:T.surface,border:`1px solid ${T.border}`,borderTop:`3px solid ${c}`,borderRadius:11,padding:'14px',boxShadow:'0 1px 4px rgba(0,0,0,.05)'}}>
            <div style={{fontSize:11,color:T.m2,marginBottom:6}}>{l}</div>
            <div style={{fontSize:26,fontWeight:800,color:c}}>{v}</div>
            <div style={{fontSize:10,color:T.m3,marginTop:4}}>{s}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* SAFETY & COMPLIANCE AGENT */
function SafetyAgent(){
  const[tab,setTab]=useState('dashboard');
  return(
    <AgentPage quarter="Q4" title="Safety & Compliance Agent" tags={['Gas detectors','Pressure & vibration monitors','CMMS']} target="Target: -30% near-miss, Zero PTW violations, -60% report prep" accentCol={T.safety}
      tabs={[['dashboard','Dashboard'],['events','Safety Events'],['ptw','Permit-to-Work'],['compliance','Compliance']]} activeTab={tab} setActiveTab={setTab}>
      {tab==='dashboard'&&<SafetyDash/>}
      {tab==='events'&&<SafetyEvents/>}
      {tab==='ptw'&&<SafetyPtw/>}
      {tab==='compliance'&&<SafetyCompliance/>}
    </AgentPage>
  );
}
function SafetyDash(){
  const{safetyEvents,ptwList,baselines,critical}=useApp();
  return(
    <div style={scroll}>
      <div style={{background:T.sfDim,border:`1px solid ${T.safety}25`,borderRadius:10,padding:'12px 16px'}}>
        <div style={{fontSize:12,fontWeight:700,color:T.safety,marginBottom:6}}>How It Works</div>
        <div style={{fontSize:11,color:T.m2,lineHeight:1.6}}>Sensor streams - gas detectors, pressure and vibration monitors - are monitored for safety anomaly patterns. The agent predicts near-miss precursors 20-40 minutes before threshold breaches and triggers interventions, while automating permit-to-work validation and OSHA/ISO 45001 reports.</div>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
        <Kpi label="Open Safety Events" value={String(safetyEvents.filter((e:any)=>e.status==="open").length||1)} delta="1 critical" up={false} color={T.red} accent={T.safety}/>
        <Kpi label="Near-Miss Rate" value={baselines?.near_miss_rate?"-"+(baselines.near_miss_rate.delta??28)+"%":"-28%"} delta={baselines?.near_miss_rate?"target "+(-baselines.near_miss_rate.target)+"%":"target -30%"} up color={T.green} accent={T.safety}/>
        <Kpi label="PTW Compliance" value={ptwList.length?+((ptwList.filter((p:any)=>p.status!=="rejected").length/ptwList.length)*100).toFixed(1)+"%":"--"} sub="Zero violations this month" color={T.green} accent={T.safety}/>
        <Kpi label="Report Prep Time" value={baselines?.report_prep_time?"-"+(baselines.report_prep_time.delta??61)+"%":"-61%"} delta={baselines?.report_prep_time?"target "+(-baselines.report_prep_time.target)+"%":"target -60%"} up color={T.green} accent={T.safety}/>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Card>
          <CH title="Safety Event Signatures Detected" sub="Gas leak precursors - thermal runaway - LOTO deviations"/>
          {[['Gas leak precursors','Pressure & flow anomalies H2S sensor',T.red],['Thermal runaway patterns','Preceding fire risk — critical assets',T.safety],['Confined space hazards','Atmospheric indicators — confined zones',T.amber],['LOTO deviations','Procedure signals — open work orders',T.amber],['Structural vibration','Near fatigue limits — high-vib assets',T.energy],['Proximity alerts','Human-machine zone AMR',T.amber]].map(([type,desc,col])=>(
            <div key={type} style={{display:'flex',gap:9,alignItems:'flex-start',padding:'7px 0',borderBottom:`1px solid ${T.border}`}}>
              <div style={{width:8,height:8,borderRadius:'50%',background:col,flexShrink:0,marginTop:3}}/>
              <div><div style={{fontSize:11,fontWeight:600}}>{type}</div><div style={{fontSize:10,color:T.m2}}>{desc}</div></div>
            </div>
          ))}
        </Card>
        <Card>
          <CH title="Precursor Detection Timeline" sub="20-40 minutes before threshold breach"/>
          {((safetyEvents as any[]).length>0?(safetyEvents as any[]).slice(0,3).map((e:any)=>[e.event_type??e.zone,e.ts?new Date(e.ts).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'})+' - '+(e.resolved_at?'Resolved':'Detected'):'Recent',T.red,!e.resolved_at]):[['No recent events','--',T.amber,false]]).map(([desc,time,col,open])=>(
            <div key={desc} style={{display:'flex',gap:9,alignItems:'center',padding:'9px 11px',background:T.s2,borderRadius:8,border:`1px solid ${col+'30'}`,borderLeft:`3px solid ${col}`,marginBottom:7}}>
              <div style={{flex:1}}><div style={{fontSize:11,fontWeight:600}}>{desc}</div><div style={{fontSize:10,color:T.m2}}>{time}</div></div>
              <Bdg label={open?'OPEN':'RESOLVED'} color={open?T.red:T.green}/>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}
function SafetyEvents(){
  const{safetyEvents}=useApp();
  return(
    <div style={scroll}>
      <CH title="Safety Events - Precursor Detection 20-40 min Advance Warning" right={<><Bdg label="1 open critical" color={T.red}/><Bdg label="2 resolved" color={T.green}/></>}/>
      {safetyEvents.map((e:any)=>{
        const col={critical:T.red,high:T.safety,medium:T.amber}[e.severity];
        return(
          <div key={e.id} style={{background:T.surface,border:`1px solid ${col+'40'}`,borderLeft:`4px solid ${col}`,borderRadius:11,padding:'13px 15px'}}>
            <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:9,flexWrap:'wrap'}}>
              <MTag text={e.id} color={col}/><Bdg label={e.severity.toUpperCase()} color={col}/><Bdg label={e.type} color={T.safety}/>
              <span style={{fontSize:12,fontWeight:700}}>{e.zone}</span>
              <Bdg label={e.status.toUpperCase()} color={e.status==='open'?T.red:T.green}/>
              <span style={{marginLeft:'auto',fontSize:10,color:T.m2}}>{e.time}</span>
            </div>
            <div style={{fontSize:12,color:T.m2,marginBottom:7}}>{e.signal}</div>
            <div style={{fontSize:12,color:T.safety,fontWeight:700}}>{e.action}</div>
          </div>
        );
      })}
    </div>
  );
}
function SafetyPtw(){
  const{ptwList}=useApp();
  return(
    <div style={scroll}>
      <CH title="Permit-to-Work Automation" sub="JHA validation - isolation verification - contractor competency vs live plant state - zero violations"/>
      {ptwList.map((p:any)=>{
        const col={approved:T.green,pending:T.amber,rejected:T.red}[p.status];
        return(
          <div key={p.id} style={{background:T.surface,border:`1px solid ${col+'40'}`,borderLeft:`4px solid ${col}`,borderRadius:11,padding:'13px 15px'}}>
            <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:9,flexWrap:'wrap'}}>
              <MTag text={p.id} color={col}/><Bdg label={p.type} color={T.safety}/><Bdg label={p.status.toUpperCase()} color={col}/>
              <span style={{fontSize:12,fontWeight:700}}>{p.asset}</span>
              <span style={{marginLeft:'auto',fontSize:11,color:T.m2}}>Tech: {p.tech}</span>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:9}}>
              {[['JHA',p.jha,p.jha==='Complete'?T.green:T.red],['Isolation',p.isolation,p.isolation==='Verified'?T.green:T.amber],['Competency',p.competency,T.green]].map(([k,v,c])=>(
                <div key={k}><div style={{fontSize:9,color:T.m2,textTransform:'uppercase',marginBottom:3}}>{k}</div><div style={{fontSize:12,fontWeight:600,color:c}}>{v}</div></div>
              ))}
            </div>
            {p.status==='rejected'&&<div style={{marginTop:9,padding:'6px 10px',background:T.rDim,borderRadius:6,fontSize:11,color:T.red}}>PTW rejected - JHA incomplete. Work cannot proceed until all validations pass.</div>}
          </div>
        );
      })}
    </div>
  );
}
function SafetyCompliance(){
  const{baselines}=useApp();
  return(
    <div style={scroll}>
      <CH title="OSHA / ISO 45001 Compliance Reporting" sub="Automatic - no manual pack preparation - Semantic Layer governs safety event entities" right={<Bdg label="Automated" color={T.green}/>}/>
      <div style={{background:T.sfDim,border:`1px solid ${T.safety}25`,borderRadius:9,padding:'12px 16px'}}>
        <div style={{fontSize:12,fontWeight:700,color:T.safety,marginBottom:6}}>Compliance Status</div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10}}>
          {[
            ['OSHA 300 Log', 'Auto-populated', 'Zero manual entries required', T.green],
            ['ISO 45001 Report', baselines?.safety_report_status?baselines.safety_report_status.current??'On track':'On track', 'Next submission: end of quarter', T.green],
            ['Report Prep Time', baselines?.report_prep_time?'-'+baselines.report_prep_time.delta+'%':'--', baselines?.report_prep_time?'vs '+baselines.report_prep_time.baseline+' min baseline':'vs manual baseline', T.green],
          ].map(([k,v,s,c])=>(
            <div key={k} style={{background:T.surface,borderRadius:8,padding:'10px 12px',border:`1px solid ${T.border}`}}>
              <div style={{fontSize:9,color:T.m2,textTransform:'uppercase',marginBottom:3}}>{k}</div>
              <div style={{fontSize:16,fontWeight:700,color:c}}>{v}</div>
              <div style={{fontSize:10,color:T.m2,marginTop:3}}>{s}</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{background:T.sDim,border:`1px solid ${T.sem}25`,borderRadius:9,padding:'10px 14px',fontSize:11,color:T.m2}}>
        Safety event, permit type, compliance obligation, and contractor competency entities mapped via Semantic Layer - enabling automatic OSHA and ISO 45001 report generation with zero manual aggregation.
      </div>
    </div>
  );
}

/* UNIFIED AI CHAT */
function UnifiedAI(){
  const{supplyRisksData,divergenceLog,energyWaste,qualityLines,twinScenarios,ptwList,crossEvents}=useApp();
  const{machines:aiMachines,yieldParams:aiYield,crossEvents:aiEvents}=useStore();
  const buildSysPrompt=()=>{
    const ms=aiMachines as any[];
    const ys=aiYield as any[];
    const avgOee=ms.length?+(ms.reduce((s,m)=>s+Number(m.oee??0),0)/ms.length).toFixed(1):0;
    const crit=ms.filter(m=>m.status==='critical').map(m=>m.id+' '+Number(m.oee??0).toFixed(1)+'%').join(', ')||'none';
    const minRul=ms.reduce((n,m)=>Math.min(n,Number(m.rul??999)),999);
    const critA=ms.find(m=>Number(m.rul??999)===minRul);
    const openEvts=(aiEvents as any[]).filter((e:any)=>!e.resolved).length;
    const hiRisk=supplyRisksData.filter((r:any)=>r.risk==='critical'||r.risk==='high').length;
    const divKpis=divergenceLog.filter((d:any)=>d.status==='diverging').length;
    const wasteRs=energyWaste.reduce((s:number,w:any)=>s+Number(w.cost??0),0);
    const warnParams=ys.filter((p:any)=>p.warn).length;
    const defToday=qualityLines.reduce((s:number,l:any)=>s+Number(l.defects??0),0);
    return 'You are ManuAI Unified AI across ALL NINE agents governed by the Semantic Layer. Concise, data-driven. Max 130 words.'
      +'\nOEE: Plant '+avgOee+'% (target 85%, gap '+(avgOee-85).toFixed(1)+'%). Critical: '+crit+'.'
      +'\nPdM: Min RUL '+minRul+'d ('+(critA?.id??'none')+'). '+ms.filter(m=>Number(m.rul??999)<30).length+' assets <30d.'
      +'\nYIELD: '+warnParams+' params in warning. '+ys.length+' active parameters.'
      +'\nQUALITY: '+qualityLines.length+' lines. '+defToday+' defects today.'
      +'\nENERGY: '+energyWaste.length+' waste patterns = Rs'+wasteRs.toLocaleString()+'/day.'
      +'\nSUPPLY: '+hiRisk+' high-risk suppliers. '+supplyRisksData.filter((r:any)=>Number(r.stockDays??0)<14).length+' critical stock.'
      +'\nTWIN: '+divKpis+' KPIs diverging. '+twinScenarios.filter((s:any)=>s.status==='running').length+' scenarios running.'
      +'\nSAFETY: '+openEvts+' open events. '+ptwList.filter((p:any)=>p.status==='pending').length+' PTWs pending.';
  };
  const SYS=buildSysPrompt();
  const[msgs,setMsgs]=useState([{role:'assistant',content:'Hi! I have live context across all 9 agents and the Semantic Layer. Ask me anything about the plant.\n\nTry:\n* Which single action has highest combined OEE + yield + energy impact today?\n* Which DCS parameter is farthest from target right now?\n* Which supplier poses the highest risk this week?\n* Which safety event is affecting the current maintenance window?'}]);
  const[input,setInput]=useState('');const[loading,setLoading]=useState(false);
  const bottomRef=useRef(null);
  useEffect(()=>{bottomRef.current?.scrollIntoView({behavior:'smooth'});},[msgs]);
  const send=useCallback(async()=>{
    const q=input.trim();if(!q||loading)return;setInput('');
    const updated=[...msgs,{role:'user',content:q}];setMsgs(updated);setLoading(true);
    try{
      const data=await aiApi.chat(updated.map(m=>({role:m.role as 'user'|'assistant',content:m.content})));
      setMsgs(prev=>[...prev,{role:'assistant',content:data.reply||'No response.'}]);
    }catch{setMsgs(prev=>[...prev,{role:'assistant',content:'Connection error.'}]);}
    setLoading(false);
  },[input,loading,msgs]);
  return(
    <div style={{display:'flex',flexDirection:'column',height:'100%',background:T.bg}}>
      <div style={{padding:'10px 14px',borderBottom:`1px solid ${T.border}`,flexShrink:0,background:T.surface}}>
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <span style={{width:8,height:8,borderRadius:'50%',background:T.green,display:'inline-block'}}/>
          <span style={{fontSize:12,fontWeight:700,color:T.txt}}>Unified AI</span>
          <span style={{marginLeft:'auto',fontSize:10,color:T.m2,background:T.s2,padding:'2px 7px',borderRadius:4,border:`1px solid ${T.border}`}}>9-agent context</span>
        </div>
        <div style={{display:'flex',gap:3,marginTop:7,flexWrap:'wrap'}}>
          {[['OEE',T.oee],['Yield',T.yield],['PdM',T.pdm],['Quality',T.quality],['Energy',T.energy],['Supply',T.supply],['Twin',T.twin],['Safety',T.safety],['Semantic',T.sem]].map(([l,c])=>(
            <span key={l} style={{fontSize:9,fontWeight:700,padding:'2px 6px',borderRadius:10,background:c+'12',color:c,border:`1px solid ${c}25`}}>{l}</span>
          ))}
        </div>
      </div>
      <div style={{flex:1,overflowY:'auto',padding:12,display:'flex',flexDirection:'column',gap:9,background:T.bg}}>
        {msgs.map((m,i)=>(
          <div key={i} style={{alignSelf:m.role==='user'?'flex-end':'flex-start',maxWidth:'91%',background:m.role==='user'?T.twin:T.surface,border:m.role==='assistant'?`1px solid ${T.border}`:'none',borderRadius:m.role==='user'?'12px 12px 3px 12px':'12px 12px 12px 3px',padding:'9px 12px',fontSize:12,lineHeight:1.6,color:m.role==='user'?'#fff':T.txt,whiteSpace:'pre-wrap',boxShadow:m.role==='assistant'?'0 1px 4px rgba(0,0,0,.06)':'none'}}>
            {m.role==='assistant'&&<div style={{fontSize:10,fontWeight:800,color:T.sem,marginBottom:4,letterSpacing:1}}>MANUAI UNIFIED AI</div>}
            {m.content}
          </div>
        ))}
        {loading&&<div style={{alignSelf:'flex-start',background:T.surface,border:`1px solid ${T.border}`,borderRadius:'12px 12px 12px 3px',padding:'10px 14px',display:'flex',gap:5}}>
          {[T.oee,T.yield,T.pdm,T.quality,T.energy,T.supply,T.twin,T.safety,T.sem].map((c,i)=><span key={i} style={{width:6,height:6,borderRadius:'50%',background:c,display:'inline-block',opacity:0.7}}/>)}
        </div>}
        <div ref={bottomRef}/>
      </div>
      {msgs.length<3&&(
        <div style={{padding:'0 12px 8px',display:'flex',flexWrap:'wrap',gap:5,background:T.bg}}>
          {(['Highest combined OEE+yield impact?','Lowest RUL asset right now?','Supply risk this week?','Which DCS param needs attention?']).map(s=>(
            <button key={s} onClick={()=>setInput(s)} style={{fontSize:10,padding:'4px 10px',borderRadius:20,background:T.surface,border:`1px solid ${T.border}`,color:T.m2,cursor:'pointer'}}>{s}</button>
          ))}
        </div>
      )}
      <div style={{padding:'10px 12px',borderTop:`1px solid ${T.border}`,display:'flex',gap:8,flexShrink:0,background:T.surface}}>
        <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()} placeholder="Ask across all 9 agents..." style={{flex:1,background:T.s2,border:`1px solid ${T.border}`,borderRadius:8,padding:'8px 12px',fontSize:12,color:T.txt,outline:'none'}}/>
        <button onClick={send} style={{background:T.sem,border:'none',color:'#fff',padding:'8px 14px',borderRadius:8,cursor:'pointer',fontSize:13,fontWeight:700}}>Send</button>
      </div>
    </div>
  );
}

/* UNIFIED INSIGHTS PANEL */
function UnifiedInsights(){
  const{crossEvents}=useApp();
  const{yieldParams:liveParams}=useStore();
  // Build recs from live params — blocked recs come from cross-agent conflict
  const buildRecs=(ps:any[])=>ps.filter((p:any)=>p.warn||p.blocked).slice(0,3).map((p:any,i:number)=>({
    id:i+1,
    pri:p.blocked?'High':i===0?'Medium':'Info',
    param:p.name??p.id,
    delta:p.tgt&&p.val?(p.val<p.tgt?'+':'')+((p.tgt-p.val)/p.tgt*100).toFixed(1)+'% yield':'--',
    desc:`${p.val??'--'} → ${p.tgt??'--'} ${p.unit??''}. ${p.blocked?'BLOCKED — semantic conflict active.':'Safe to execute.'}`,
    status:p.blocked?'blocked':'pending',
  }));
  const[yRecs,setYRecs]=useState<any[]>([]);
  useEffect(()=>{const ps=liveParams as any[];if(ps.length)setYRecs(buildRecs(ps));},[liveParams]);
  const act=(id,s)=>setYRecs(rs=>rs.map(r=>r.id===id?{...r,status:s}:r));
  const pc={High:T.green,Medium:T.amber,Info:T.oee};
  const sc2={blocked:T.red,pending:T.amber,accepted:T.green,rejected:T.red};
  const evCol={critical:T.red,warning:T.amber,info:T.sem};
  return(
    <div style={{overflowY:'auto',padding:12,display:'flex',flexDirection:'column',gap:9,height:'100%',background:T.bg}}>
      <div style={{background:T.sDim,border:`1px solid ${T.sem}30`,borderRadius:8,padding:'8px 12px'}}>
        <div style={{fontSize:10,fontWeight:800,color:T.sem,letterSpacing:1}}>SEMANTIC LAYER ACTIVE</div>
        {(()=>{const blocked=yRecs.filter((r:any)=>r.status==='blocked').length;return(<div style={{fontSize:10,color:T.m2,marginTop:3}}><strong style={{color:T.red}}>{blocked} rec{blocked!==1?'s':''} blocked</strong> - <strong>9 agents governed</strong></div>);})()}
      </div>
      <Divider label="Yield Recommendations" col={T.yield}/>
      {yRecs.map(r=>(
        <div key={r.id} style={{background:T.surface,border:`1px solid ${r.status==='blocked'?T.red+'40':T.border}`,borderLeft:`3px solid ${sc2[r.status]}`,borderRadius:9,padding:'10px 12px',opacity:['accepted','rejected'].includes(r.status)?0.6:1,boxShadow:'0 1px 3px rgba(0,0,0,.04)'}}>
          <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:5,flexWrap:'wrap'}}>
            <Bdg label={r.pri} color={pc[r.pri]}/><span style={{fontSize:12,fontWeight:700}}>{r.param}</span>
            <span style={{marginLeft:'auto',fontSize:12,fontWeight:800,color:T.green}}>{r.delta}</span>
          </div>
          <div style={{fontSize:11,color:T.m2,lineHeight:1.5,marginBottom:r.status==='pending'?8:4}}>{r.desc}</div>
          {r.status==='blocked'&&<div style={{fontSize:10,color:T.red,fontWeight:700,padding:'4px 8px',background:T.rDim,borderRadius:4,marginBottom:4}}>Semantic Layer block active</div>}
          {r.status==='pending'&&<div style={{display:'flex',gap:5}}><Btn v="accept" sm onClick={()=>act(r.id,'accepted')}>Push DCS</Btn><Btn sm onClick={()=>act(r.id,'rejected')}>Dismiss</Btn></div>}
          {r.status==='accepted'&&<div style={{fontSize:10,color:T.green,fontWeight:700}}>Written to DCS</div>}
          {r.status==='rejected'&&<div style={{fontSize:10,color:T.red,fontWeight:700}}>Dismissed</div>}
        </div>
      ))}
      <Divider label="Safety Alert" col={T.safety}/>
      <div style={{background:T.surface,border:`1px solid ${T.red+'40'}`,borderLeft:`3px solid ${T.red}`,borderRadius:8,padding:'9px 11px'}}>
        <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:5}}><Bdg label="CRITICAL" color={T.red}/><span style={{fontSize:11,fontWeight:700}}>Gas leak precursor Zone C</span></div>
        <div style={{fontSize:10,color:T.m2}}>H2S sensor 3 pressure anomaly 09:30. Evacuation alert issued.</div>
      </div>
      <Divider label="Cross-Agent Events" col={T.sem}/>
      {(crossEvents as any[]).slice(0,4).map((e:any)=>{
        const col=evCol[e.sev]||T.m2;
        return(
          <div key={e.id} style={{background:T.surface,border:`1px solid ${col+'30'}`,borderLeft:`3px solid ${col}`,borderRadius:8,padding:'9px 11px'}}>
            <div style={{display:'flex',alignItems:'center',gap:5,marginBottom:5,flexWrap:'wrap'}}>
              <AgChip agent={e.from}/><span style={{fontSize:9,color:T.m2}}>→</span><AgChip agent={e.to}/>
              <Bdg label={e.type.replace(/_/g,' ')} color={col} sm/>
              <span style={{marginLeft:'auto',fontSize:10,color:T.m2}}>{e.ts}</span>
            </div>
            <div style={{fontSize:10,color:T.m2,lineHeight:1.5,marginBottom:3}}>{e.msg}</div>
            <div style={{fontSize:10,fontWeight:700,color:col}}>{e.impact}</div>
          </div>
        );
      })}
    </div>
  );
}

/* ROOT APP */
function AppShell(){
  const{initWebSocket,crossEvents}=useStore();
  const{critical,agsOee,agsMachines,qualityLines}=useApp();

  useEffect(()=>{
    initWebSocket();
    subscribeChannels(['oee','yield','pdm','quality','energy','supply','twin','safety','semantic','alerts']);
  },[]);
  const[page,setPage]=useState('overview');
  const[rp,setRp]=useState('insights');
  const[plant,setPlant]=useState('All Plants');
  const renderPage=()=>({
    overview:<UnifiedOverview/>,semantic:<SemanticLayer/>,
    oee:<OeeAgent/>,yield:<YieldAgent/>,pdm:<PdmAgent/>,quality:<QualityAgent/>,
    energy:<EnergyAgent/>,supply:<SupplyAgent/>,twin:<TwinAgent/>,safety:<SafetyAgent/>,
  }[page]);
  return(
    <div style={{background:T.bg,color:T.txt,fontFamily:"'Inter','Segoe UI',system-ui,sans-serif",height:'100vh',display:'grid',gridTemplateRows:'52px 1fr',overflow:'hidden'}}>
      {/* Header */}
      <div style={{background:T.surface,borderBottom:`1px solid ${T.border}`,display:'flex',alignItems:'center',padding:'0 18px',gap:12,boxShadow:'0 1px 4px rgba(0,0,0,.06)'}}>
        <div style={{fontSize:15,fontWeight:900,letterSpacing:0.5,flexShrink:0}}>
          <span style={{color:T.oee}}>Manu</span><span style={{color:T.yield}}>AI</span>
        </div>
        <div style={{color:T.border,fontSize:16}}>|</div>
        <div style={{fontSize:12,fontWeight:700,color:T.txt}}>Unified Manufacturing Intelligence Platform</div>
        <span style={{width:7,height:7,borderRadius:'50%',background:T.green,display:'inline-block'}}/>
        <span style={{fontSize:10,color:T.m2}}>Live - 9 agents - 2 plants</span>
        <div style={{display:'flex',gap:3,marginLeft:4,flexWrap:'wrap'}}>
          {[['OEE',T.oee],['Yield',T.yield],['PdM+Parts',T.pdm],['Quality',T.quality],['Energy',T.energy],['Supply',T.supply],['Twin',T.twin],['Safety',T.safety],['Semantic',T.sem]].map(([l,c])=>(
            <span key={l} style={{fontSize:9,fontWeight:700,padding:'2px 7px',borderRadius:10,background:c+'12',color:c,border:`1px solid ${c}25`}}>{l}</span>
          ))}
        </div>
        <div style={{display:'flex',gap:4,marginLeft:4}}>
          {['All Plants','Plant 1','Plant 2'].map(p=>(
            <button key={p} onClick={()=>setPlant(p)} style={{fontSize:10,padding:'3px 9px',borderRadius:20,cursor:'pointer',fontWeight:600,border:`1px solid ${plant===p?T.sem:T.border}`,background:plant===p?T.sDim:'transparent',color:plant===p?T.sem:T.m2}}>{p}</button>
          ))}
        </div>
        <div style={{marginLeft:'auto',display:'flex',gap:6}}>
          <Bdg label={`${critical} CRITICAL`} color={T.red}/>
          <Bdg label="1 SAFETY" color={T.safety}/>
          {agsOee>0?<Bdg label={`OEE ${agsOee}%`} color={T.oee}/>:null}
          <Bdg label="Semantic Layer" color={T.sem}/>
        </div>
      </div>
      {/* Body: sidebar + main + right panel */}
      <div style={{display:'grid',gridTemplateColumns:'190px 1fr 290px',overflow:'hidden'}}>
        {/* Sidebar */}
        <div style={{background:T.surface,borderRight:`1px solid ${T.border}`,display:'flex',flexDirection:'column',overflow:'hidden',boxShadow:'1px 0 4px rgba(0,0,0,.04)'}}>
          <div style={{flex:1,overflowY:'auto',padding:'8px 0'}}>
            {SECS.map(sec=>{
              const items=NAV.filter(n=>n.section===sec);
              return(
                <div key={sec}>
                  <div style={{padding:'8px 14px 3px',fontSize:9,fontWeight:800,color:SEC_COLS[sec],letterSpacing:1.5,textTransform:'uppercase',marginTop:6}}>{sec}</div>
                  {items.map(item=>(
                    <div key={item.id} onClick={()=>setPage(item.id)} style={{display:'flex',alignItems:'center',gap:9,padding:'8px 14px',cursor:'pointer',fontSize:12,fontWeight:600,color:page===item.id?item.accent:T.m2,background:page===item.id?item.accent+'10':'transparent',borderLeft:`3px solid ${page===item.id?item.accent:'transparent'}`,transition:'all 0.15s'}}>
                      <span>{item.icon}</span>{item.label}
                      {item.id==='oee'&&critical>0&&<span style={{marginLeft:'auto',minWidth:18,height:18,borderRadius:9,background:T.red,color:'#fff',fontSize:10,fontWeight:800,display:'flex',alignItems:'center',justifyContent:'center'}}>{critical}</span>}
                      {item.id==='safety'&&<span style={{marginLeft:'auto',minWidth:18,height:18,borderRadius:9,background:T.safety,color:'#fff',fontSize:10,fontWeight:800,display:'flex',alignItems:'center',justifyContent:'center'}}>1</span>}
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
          {/* Mini KPI strip */}
          <div style={{padding:10,borderTop:`1px solid ${T.border}`,display:'flex',flexDirection:'column',gap:5}}>
            {[['OEE',(agsMachines as any[]).length?agsOee+'%':'--',T.oee],['Yield','--',T.yield],['Quality',qualityLines.length?+(qualityLines.reduce((s:number,l:any)=>s+Number(l.rate??0),0)/qualityLines.length).toFixed(1)+'%':'--',T.quality],['Events',(crossEvents as any[]).filter((e:any)=>e.sev==='critical'||e.severity==='critical').length+' crit',T.sem]].map(([l,v,c])=>(
              <div key={l} style={{background:T.s2,border:`1px solid ${T.border}`,borderRadius:8,padding:'7px 10px',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
                <div style={{fontSize:9,color:T.m2,textTransform:'uppercase',letterSpacing:'0.5px'}}>{l}</div>
                <div style={{fontSize:17,fontWeight:800,color:c}}>{v}</div>
              </div>
            ))}
          </div>
        </div>
        {/* Main content */}
        <div style={{overflow:'hidden',background:T.bg}}>{renderPage()}</div>
        {/* Right panel */}
        <div style={{background:T.surface,borderLeft:`1px solid ${T.border}`,display:'flex',flexDirection:'column',overflow:'hidden',boxShadow:'-1px 0 4px rgba(0,0,0,.04)'}}>
          <div style={{display:'flex',borderBottom:`1px solid ${T.border}`,flexShrink:0}}>
            {[['insights','Insights'],['chat','Unified AI']].map(([id,label])=>(
              <div key={id} onClick={()=>setRp(id)} style={{flex:1,textAlign:'center',padding:'11px 8px',fontSize:11,fontWeight:700,cursor:'pointer',color:rp===id?T.sem:T.m2,borderBottom:`2px solid ${rp===id?T.sem:'transparent'}`,background:T.surface}}>{label}</div>
            ))}
          </div>
          <div style={{flex:1,overflow:'hidden'}}>
            {rp==='insights'?<UnifiedInsights/>:<UnifiedAI/>}
          </div>
        </div>
      </div>
    </div>
  );
}
export default function App(){
  return(<AppProvider><AppShell/></AppProvider>);
}
