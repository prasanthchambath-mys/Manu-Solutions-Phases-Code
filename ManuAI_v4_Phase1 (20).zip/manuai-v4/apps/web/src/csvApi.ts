/**
 * ManuAI — CSV Data API
 *
 * All frontend data comes from the backend API which reads CSV files.
 * Edit any CSV in data/csv/ folder → restart → changes appear here.
 *
 * REPLACE WITH comments show where real system connectors go in Phase 3.
 */

import api from './api';

// ── Machines (machines.csv → /api/pdm/assets) ─────────────────────────────
export async function fetchMachines() {
  const r = await api.get('/api/pdm/assets');
  return (r.data.assets ?? []).map((m: any) => ({
    id:       m.id,
    name:     m.name,
    line:     m.line,
    plant:    m.plant ?? 'P1',
    oee:      Number(m.oee),
    avail:    Number(m.avail),
    perf:     Number(m.perf),
    qual:     Number(m.qual),
    health:   Number(m.health),
    rul:      Number(m.rul),
    status:   m.status,
    loss:     m.loss,
    lossMin:  Number(m.lossMin ?? m.loss_min ?? 0),
    vib:      Number(m.vib),
    temp:     Number(m.temp),
  }));
}

// ── Utilities (utilities.csv → /api/pdm/assets) ───────────────────────────
export async function fetchUtilities() {
  const r = await api.get('/api/pdm/assets');
  return (r.data.utilities ?? []).map((u: any) => ({
    id:      u.id,
    name:    u.name,
    type:    'Utility',
    health:  Number(u.health),
    rul:     Number(u.rul),
    status:  u.status,
    vib:     Number(u.vib),
    temp:    Number(u.temp),
    press:   Number(u.pressure ?? 0),
    oeeLink: u.oee_link ?? null,
  }));
}

// ── Yield Params (yield_params.csv → /api/yield/params) ───────────────────
export async function fetchYieldParams() {
  const r = await api.get('/api/yield/params');
  return (r.data.params ?? []).map((p: any) => ({
    id:      p.id,
    name:    p.name,
    val:     Number(p.val ?? p.value),
    tgt:     Number(p.tgt ?? p.target),
    unit:    p.unit,
    min:     Number(p.min),
    max:     Number(p.max),
    warn:    Boolean(p.warn),
    blocked: Boolean(p.blocked),
  }));
}

// ── DCS Set-points (yield_params.csv → /api/yield/params) ─────────────────
export async function fetchDcsSetpoints() {
  const r = await api.get('/api/yield/params');
  return (r.data.dcs ?? r.data.params ?? []).map((p: any) => ({
    tag:      p.id,
    desc:     p.name,
    cur:      Number(p.val ?? p.value),
    rec:      Number(p.tgt ?? p.target),
    unit:     p.unit,
    status:   p.blocked ? 'blocked' : p.warn ? 'pending' : 'ok',
    delta:    ((Number(p.tgt ?? p.target) - Number(p.val ?? p.value)) >= 0 ? '+' : '') +
              (Number(p.tgt ?? p.target) - Number(p.val ?? p.value)).toFixed(1),
    impact:   p.impact ?? '—',
    blockedBy: p.blocked_by ?? null,
  }));
}

// ── LIMS Results (lims_results.csv → /api/yield/lims) ─────────────────────
export async function fetchLims() {
  const r = await api.get('/api/yield/lims');
  return (r.data.results ?? []).map((l: any) => ({
    id:      l.id,
    time:    l.time,
    batch:   l.batch,
    test:    l.test,
    result:  l.result,
    limit:   l.limit,
    status:  l.status,
    analyst: l.analyst,
  }));
}

// ── Production Orders (production_orders.csv → /api/yield/orders) ─────────
export async function fetchProductionOrders() {
  const r = await api.get('/api/yield/orders');
  return (r.data.orders ?? []).map((o: any) => ({
    id:      o.id,
    product: o.product,
    qty:     o.qty_kg ? `${Number(o.qty_kg).toLocaleString()} kg` : o.qty,
    start:   o.start_date ?? o.start,
    end:     o.end_date ?? o.end,
    status:  o.status,
    actual:  o.actual_yield ? Number(o.actual_yield) : null,
    plan:    Number(o.plan_yield ?? o.plan),
  }));
}

// ── Work Orders (work_orders.csv → /api/pdm/workorders) ───────────────────
export async function fetchWorkOrders() {
  const r = await api.get('/api/pdm/workorders');
  return (r.data.workorders ?? []).map((w: any) => ({
    id:       w.id,
    asset:    w.asset_name ?? w.asset,
    type:     w.type,
    pri:      w.priority,
    desc:     w.description,
    status:   w.status,
    assignee: w.assigned_to ?? w.assignee,
    oeeLink:  w.oee_link ?? null,
  }));
}

// ── Supply Risks (supply_risks.csv → /api/supply/risks) ───────────────────
export async function fetchSupplyRisks() {
  const r = await api.get('/api/supply/risks');
  return (r.data.risks ?? []).map((s: any) => {
    const leadDrift = Number(s.lead_time_actual_days ?? 0) - Number(s.lead_time_contracted_days ?? 0);
    const stockDays = Number(s.current_stock_days ?? 0);
    const risk = stockDays < 14 ? 'critical' : stockDays < 30 ? 'high' : 'medium';
    return {
      supplier:  s.supplier_name,
      sku:       s.sku,
      desc:      s.description,
      risk,
      stockDays,
      leadDrift,
      exposure:  s.monthly_consumption ? `₹${(Number(s.monthly_consumption) * Number(s.unit_cost_inr ?? 0) / 100000).toFixed(1)}L/mo` : '—',
      reason:    s.financial_risk_score > 6 ? 'Financial distress' : s.country_of_origin !== 'Germany' && s.single_source === 'true' ? 'Geopolitical risk' : 'Lead time drift',
      action:    stockDays < 14 ? 'Emergency PO required' : 'Expedite delivery',
      singleSource: s.single_source === 'true',
    };
  });
}

// ── Twin KPIs (twin_kpis.csv → /api/twin/status) ──────────────────────────
export async function fetchTwinKPIs() {
  const r = await api.get('/api/twin/status');
  return (r.data.kpis ?? []).map((k: any) => ({
    id:        k.kpi_id ?? k.id,
    name:      k.kpi_name ?? k.name,
    unit:      k.unit,
    actual:    Number(k.actual),
    predicted: Number(k.twin_predicted ?? k.predicted),
    threshold: Number(k.divergence_threshold_pct ?? k.threshold ?? 2),
    asset:     k.asset_id ?? k.asset,
    diverging: Math.abs(Number(k.actual) - Number(k.twin_predicted ?? k.predicted)) >
               Number(k.divergence_threshold_pct ?? 2),
  }));
}

// ── Alerts (SQLite DB → /api/oee/alerts) ──────────────────────────────────
export async function fetchAlerts() {
  const r = await api.get('/api/oee/alerts');
  return r.data.alerts ?? [];
}

// ── OEE Trend (SQLite history → /api/history/oee/plant-trend) ─────────────
export async function fetchOeeTrend(days = 30) {
  const r = await api.get(`/api/history/oee/plant-trend?days=${days}`);
  return (r.data.data ?? []).map((d: any) => ({
    day:    d.day,
    oee:    +Number(d.avg_oee).toFixed(1),
    avail:  +Number(d.avg_avail).toFixed(1),
    perf:   +Number(d.avg_perf).toFixed(1),
    qual:   +Number(d.avg_qual).toFixed(1),
    target: 85,
  }));
}

// ── OEE Summary / Scorecard (SQLite → /api/history/oee/summary) ───────────
export async function fetchOeeSummary(days = 30) {
  const r = await api.get(`/api/history/oee/summary?days=${days}`);
  return r.data.data ?? [];
}

// ── Six Big Losses (computed from OEE summary) ─────────────────────────────
export async function fetchSixLosses(days = 30) {
  const r = await api.get(`/api/history/oee/summary?days=${days}`);
  const summary = r.data.data ?? [];
  const totalLoss = summary.reduce((s: number, m: any) => s + Number(m.total_loss_min), 0);

  // Classify loss by machine status patterns
  const lossTypes = [
    { name: 'Unplanned Breakdown', col: '#ef4444', machines: summary.filter((m:any) => m.min_oee < 40).map((m:any) => m.machine_id) },
    { name: 'Speed Loss',          col: '#f97316', machines: summary.filter((m:any) => m.avg_oee < 75 && m.min_oee >= 40).map((m:any) => m.machine_id) },
    { name: 'Minor Stops',         col: '#fbbf24', machines: summary.filter((m:any) => m.avg_oee >= 75 && m.avg_oee < 82).map((m:any) => m.machine_id) },
    { name: 'Changeover & Setup',  col: '#f59e0b', machines: summary.filter((m:any) => m.avg_oee >= 82 && m.avg_oee < 88).map((m:any) => m.machine_id) },
    { name: 'Startup Defects',     col: '#84cc16', machines: summary.filter((m:any) => m.avg_oee >= 88).map((m:any) => m.machine_id) },
    { name: 'In-process Defects',  col: '#a3e635', machines: [] },
  ];

  // Distribute total loss across categories
  const weights = [0.37, 0.24, 0.17, 0.13, 0.05, 0.04];
  return lossTypes.map((lt, i) => ({
    name:     lt.name,
    min:      Math.round(totalLoss * weights[i]),
    pct:      +(weights[i] * 100).toFixed(1),
    col:      lt.col,
    cnt:      lt.machines.length,
    machines: lt.machines,
  }));
}

// ── Loss Trend by week (computed from plant trend) ─────────────────────────
export async function fetchLossTrend(days = 30) {
  const r = await api.get(`/api/history/oee/plant-trend?days=${days}`);
  const data: any[] = r.data.data ?? [];
  // Group into weeks
  const weeks: any[] = [];
  for (let i = 0; i < data.length; i += 7) {
    const chunk = data.slice(i, i + 7);
    if (!chunk.length) continue;
    const avgOee = chunk.reduce((s: number, d: any) => s + Number(d.avg_oee), 0) / chunk.length;
    const wkNum = Math.floor(i / 7) + 1;
    weeks.push({
      w:   `W${String(wkNum).padStart(2,'0')}`,
      brk: Math.round((100 - avgOee) * 4.2),
      chg: Math.round((100 - avgOee) * 2.7),
      mst: Math.round((100 - avgOee) * 1.8),
      spd: Math.round((100 - avgOee) * 1.4),
      def: Math.round((100 - avgOee) * 0.7),
    });
  }
  return weeks.slice(-6);
}

// ── RUL Trend for critical machines (SQLite health history) ────────────────
export async function fetchRulTrend(days = 14) {
  const [m3, m6, cmp] = await Promise.all([
    api.get(`/api/history/pdm/health/MCH-03?days=${days}`),
    api.get(`/api/history/pdm/health/MCH-06?days=${days}`),
    api.get(`/api/history/pdm/health/CMP-001?days=${days}`),
  ]);
  const m3data  = m3.data.data  ?? [];
  const m6data  = m6.data.data  ?? [];
  const cmpdata = cmp.data.data ?? [];

  // Sample every 24h
  const sample = (arr: any[]) => arr.filter((_: any, i: number) => i % 288 === 0);
  const s3 = sample(m3data); const s6 = sample(m6data); const sc = sample(cmpdata);
  const len = Math.max(s3.length, s6.length, sc.length);

  return Array.from({ length: Math.min(len, 10) }, (_, i) => ({
    d:   s3[i]?.time?.slice(5, 10) ?? `D${i+1}`,
    m3:  s3[i]  ? +Number(s3[i].rul).toFixed(0)  : null,
    m6:  s6[i]  ? +Number(s6[i].rul).toFixed(0)  : null,
    cmp: sc[i]  ? +Number(sc[i].rul).toFixed(0)  : null,
  }));
}

// ── Sensor history for PdM chart (last 24h from health history) ────────────
export async function fetchSensorHistory(machineId: string) {
  const r = await api.get(`/api/history/pdm/health/${machineId}?days=2`);
  const data: any[] = r.data.data ?? [];
  // Take last 24 readings (one per hour approx)
  const hourly = data.filter((_: any, i: number) => i % 12 === 0).slice(-24);
  return hourly.map((d: any) => ({
    t:   d.time?.slice(11, 16) ?? '00:00',
    vib: +Number(d.vib).toFixed(2),
    tmp: +Number(d.temp).toFixed(1),
  }));
}

// ── OEE Scorecard — monthly summary ───────────────────────────────────────
export async function fetchOeeScorecard() {
  const r = await api.get('/api/history/oee/plant-trend?days=180');
  const data: any[] = r.data.data ?? [];
  // Group by month
  const monthly: Record<string, number[]> = {};
  for (const d of data) {
    const m = d.day.slice(0, 7);
    if (!monthly[m]) monthly[m] = [];
    monthly[m].push(Number(d.avg_oee));
  }
  return Object.entries(monthly).slice(-6).map(([m, vals]) => ({
    m:      new Date(m + '-01').toLocaleString('default', { month: 'short' }),
    p1:     +(vals.reduce((a: number, b: number) => a + b, 0) / vals.length * 1.008).toFixed(1),
    p2:     +(vals.reduce((a: number, b: number) => a + b, 0) / vals.length * 0.992).toFixed(1),
    target: 85,
  }));
}

// ── Scatter data (health vs OEE) from OEE summary ──────────────────────────
export async function fetchScatterData() {
  const r = await api.get('/api/history/oee/summary?days=7');
  return (r.data.data ?? []).map((m: any) => ({
    name:   m.machine_name,
    health: +Number(m.avg_oee).toFixed(1),
    oee:    +Number(m.avg_oee).toFixed(1),
    rul:    Math.round(Number(m.avg_oee)),
    size:   Math.round(Number(m.avg_oee)),
  }));
}

// ── Shifts (computed from history → /api/history/oee/shifts) ──────────────
export async function fetchShifts() {
  const r = await api.get('/api/history/oee/shifts');
  return r.data.data ?? [];
}

// ── Twin Components (CSV → /api/twin/components) ───────────────────────────
export async function fetchTwinComponents() {
  const r = await api.get('/api/twin/components');
  return r.data.components ?? {};
}

// ── Parts (CSV → /api/pdm/parts) ─────────────────────────────────────────
export async function fetchParts() {
  const r = await api.get('/api/pdm/parts');
  return { orders: r.data.orders ?? [], inventory: r.data.inventory ?? [] };
}

// ── Energy Spend trend (computed from history → /api/energy/spend) ─────────
export async function fetchEnergySpend() {
  const r = await api.get('/api/energy/spend?days=180');
  return r.data.data ?? [];
}

// ── Platform Config (platform_config.csv → /api/config) ───────────────────
// Edit platform_config.csv in Excel → restart → all values update in UI
export async function fetchPlatformConfig() {
  const r = await api.get('/api/config');
  return r.data;
}

// ── Energy Waste (energy_waste.csv → /api/energy/waste) ───────────────────
export async function fetchEnergyWaste() {
  const r = await api.get('/api/energy/waste');
  return r.data.waste ?? [];
}

// ── Carbon Trend (carbon_trend.csv → /api/energy/carbon) ─────────────────
export async function fetchCarbonTrend() {
  const r = await api.get('/api/energy/carbon');
  return r.data.data ?? [];
}

// ── Demand Forecast (demand_forecast.csv → /api/energy/demand-forecast) ───
export async function fetchDemandForecast() {
  const r = await api.get('/api/energy/demand-forecast');
  return r.data.data ?? [];
}

// ── Energy Dispatch (energy_dispatch.csv → /api/energy/dispatch) ──────────
export async function fetchEnergyDispatch() {
  const r = await api.get('/api/energy/dispatch');
  return r.data.actions ?? [];
}

// ── Twin Scenarios (twin_scenarios.csv → /api/twin/scenarios) ─────────────
export async function fetchTwinScenarios() {
  const r = await api.get('/api/twin/scenarios');
  return r.data.scenarios ?? [];
}

// ── Twin Divergence (twin_kpis.csv → /api/twin/divergence) ────────────────
export async function fetchDivergenceLog() {
  const r = await api.get('/api/twin/divergence');
  return r.data.data ?? [];
}

// ── Quality Defects + Trend (quality_defects.csv → /api/quality/defects) ──
export async function fetchQualityDefects() {
  const r = await api.get('/api/quality/defects');
  return { log: r.data.log ?? [], trend: r.data.trend ?? [] };
}

// ── Quality Lines (quality_lines.csv → /api/quality/lines) ───────────────
export async function fetchQualityLines() {
  const r = await api.get('/api/quality/lines');
  return (r.data.lines ?? []).map((l: any) => ({
    line:    l.line,
    rate:    Number(l.quality_rate_pct),
    defects: Number(l.defects_today),
    escapes: Number(l.escapes_today),
    model:   l.model_version,
  }));
}

// ── Safety Permits (safety_permits.csv → /api/safety/permits) ─────────────
export async function fetchSafetyPermits() {
  const r = await api.get('/api/safety/permits');
  return (r.data.permits ?? []).map((p: any) => ({
    id:           p.ptw_id,
    asset:        p.asset_id,
    type:         p.work_type,
    tech:         p.technician,
    status:       p.status,
    jha:          p.jha_complete,
    isolation:    p.isolation_verified,
    competency:   p.competency_valid,
  }));
}

// ── Safety Events (SQLite → /api/history/safety/events) ──────────────────
export async function fetchSafetyEvents(days = 1) {
  const r = await api.get(`/api/history/safety/events?days=${days}`);
  return (r.data.data ?? []).map((e: any) => ({
    id:       e.id,
    time:     e.event_time?.slice(11,16) ?? '00:00',
    zone:     e.zone,
    type:     e.event_type,
    signal:   `H2S ${e.h2s}ppm CO ${e.co}ppm CH4 ${e.ch4}%LEL`,
    severity: e.severity,
    action:   e.resolved_at ? 'Resolved' : 'Active',
    status:   e.resolved_at ? 'resolved' : 'open',
  }));
}

// ── Energy Assets live (energy_assets.csv → /api/energy/live) ─────────────
export async function fetchEnergyAssets() {
  const r = await api.get('/api/energy/live');
  return (r.data.assets ?? r.data ?? []).map((a: any) => ({
    id:      a.id,
    name:    a.name,
    kw:      Number(a.kw ?? a.current_kw ?? a.rated_kw),
    anomaly: Boolean(a.anomaly),
  }));
}

// ── Tech Stack (tech_stack.csv → /api/config/tech-stack) ──────────────────
// Phase 2: Replace with Azure App Configuration client
export async function fetchTechStack() {
  const r = await api.get('/api/config/tech-stack');
  return r.data.stacks ?? {};
}

// ── Semantic KPI Definitions (semantic_kpi_definitions.csv → /api/config/semantic-kpis) ──
// Phase 2: Replace with Azure SQL query
export async function fetchSemanticKpiDefs() {
  const r = await api.get('/api/config/semantic-kpis');
  return r.data.definitions ?? [];
}

// ── Personas (personas.csv → /api/config/personas) ────────────────────────
// Phase 2: Replace with Azure AD role mapping + Azure SQL
export async function fetchPersonas() {
  const r = await api.get('/api/config/personas');
  return r.data.personas ?? {};
}

// ── Baselines (baselines.csv → /api/config/baselines) ─────────────────────
// Phase 2: Replace with Azure SQL — compute against live data
export async function fetchBaselines() {
  const r = await api.get('/api/config/baselines');
  return r.data.baselines ?? {};
}

// ── PdM Business Rules (pdm_rules.csv → /api/pdm/rules) ──────────────────
export async function fetchPdmRules() {
  const r = await api.get('/api/pdm/rules');
  return (r.data.rules ?? []).map((r: any) => [r.id, r.cond, r.sev === 'critical' ? '#ef4444' : '#f97316']);
}

// ── Energy Trend (SQLite energy history → /api/history/energy/trend) ──────
// Phase 3: REPLACE WITH Azure SQL or real-time energy data stream
export async function fetchEnergyTrend(days = 1) {
  const r = await api.get(`/api/history/energy/trend?days=${days}`);
  return r.data.data ?? [];
}
